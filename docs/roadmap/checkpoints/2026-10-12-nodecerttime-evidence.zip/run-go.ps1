param([Parameter(Mandatory=$true)][string]$RunId, [Parameter(Mandatory=$true)][string[]]$GoArgs)
$ErrorActionPreference='Stop'
$certTimeRoot='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
$certTimeEvidence=Join-Path $certTimeRoot '.superpowers/sdd/2026-10-12-node-certificate-time-binding'
if ($RunId -notmatch '^[0-9]{3}-[a-z0-9-]+$') { throw 'invalid run id' }
$certTimeReceipt=Join-Path $certTimeEvidence ($RunId+'.json')
if ((Test-Path -LiteralPath $certTimeReceipt) -or (Test-Path -LiteralPath (Join-Path $certTimeEvidence ($RunId+'.started.json')))) { throw 'run receipt already exists' }
Set-Location -LiteralPath $certTimeRoot
$env:GOOS='windows'
$env:GOARCH='amd64'
$env:GOTOOLCHAIN='local'
$env:GOPROXY='off'
$env:GOSUMDB='off'
$env:GOAUTH='off'
$env:GOVCS='all:off'
$env:GOFLAGS='-mod=readonly'
$env:GOPATH='C:/Users/Lenovo/go'
$env:GOMODCACHE='C:/Users/Lenovo/go/pkg/mod'
$env:GOCACHE=Join-Path $certTimeEvidence 'go-cache'
$certTimeGo='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/go.exe'
function Get-CertTimeSourceHashes {
    @(rg --files internal/nodecontrol -g '*.go' | Where-Object { $_ -notmatch '[\\/]testdata[\\/]' } | Sort-Object | ForEach-Object {
        [pscustomobject]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}
    })
}
$certTimeBefore=Get-CertTimeSourceHashes
$certTimeStarted=[DateTime]::UtcNow.ToString('o')
$certTimeStdout=Join-Path $certTimeEvidence ($RunId+'.stdout.txt')
$certTimeStderr=Join-Path $certTimeEvidence ($RunId+'.stderr.txt')
[pscustomobject]@{RunId=$RunId;Executable=$certTimeGo;Arguments=$GoArgs;StartedUTC=$certTimeStarted;SourceBefore=$certTimeBefore;Status='started-not-completed'} | ConvertTo-Json -Depth 8 | Out-File -LiteralPath (Join-Path $certTimeEvidence ($RunId+'.started.json')) -Encoding utf8
Write-Output ('started: '+$RunId)
& $certTimeGo @GoArgs 1> $certTimeStdout 2> $certTimeStderr
$certTimeExit=$LASTEXITCODE
$certTimeEnded=[DateTime]::UtcNow.ToString('o')
$certTimeAfter=Get-CertTimeSourceHashes
[pscustomobject]@{RunId=$RunId;Executable=$certTimeGo;Arguments=$GoArgs;StartedUTC=$certTimeStarted;EndedUTC=$certTimeEnded;ExitCode=$certTimeExit;GOOS=$env:GOOS;GOARCH=$env:GOARCH;GOTOOLCHAIN=$env:GOTOOLCHAIN;GOPROXY=$env:GOPROXY;GOSUMDB=$env:GOSUMDB;GOAUTH=$env:GOAUTH;GOVCS=$env:GOVCS;GOFLAGS=$env:GOFLAGS;GODEBUG=$env:GODEBUG;GOEXPERIMENT=$env:GOEXPERIMENT;GOCACHE=$env:GOCACHE;SourceBefore=$certTimeBefore;SourceAfter=$certTimeAfter} | ConvertTo-Json -Depth 8 | Out-File -LiteralPath $certTimeReceipt -Encoding utf8
Write-Output ('receipt: '+$certTimeReceipt)
Get-Content -LiteralPath $certTimeStdout -Tail 35
Get-Content -LiteralPath $certTimeStderr -Tail 35
exit $certTimeExit

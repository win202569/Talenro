# Task 2 brief

BASE: f5d731bef9d767d57ca32f0f4c3a0f532a4bc322

Spec and Global Constraints binding; Task 1 local interfaces, no Git writes.

### Task 2: 完整 owned Input、时间规范化、摘要隔离和共享生命周期

**Files:** Create `owner.go`、`owned_certificate.go`、`owned_binding.go`、`owned_content.go`、`owned_table.go`、`owned_policy.go`、`owned_time.go`、`owned_summary.go`、`model.go`；Test 对应七个 owned_*_test.go 和 `model_test.go`。

**Interfaces:**
- Consumes: Task 1 的 Input/Summary/preflight；类型复制不消费 parser/Evaluate。
- Produces: `type owner struct { input Input; summary Summary; valid bool }`、`type Model struct { owned *owner }`；`ownInput(context.Context, Input) (*owner, error)`、`(*owner).clear()`、`copySlice[T any]([]T) []T`、`copyRaw([]byte) []byte`、`normalizeTime(time.Time) time.Time`、公开 Summary/Clear。
- Produces: `ownCertificate(context.Context, nodeissuer.Input) (nodeissuer.Input, error)` / `clearCertificate(*nodeissuer.Input)`；`ownBinding(context.Context, statebinding.Input) (statebinding.Input, error)` / `clearBinding(*statebinding.Input)`；`ownContent(context.Context, statecontract.MainStateContentModel) (statecontract.MainStateContentModel, error)` / `clearContent(*statecontract.MainStateContentModel)`；`ownTable(context.Context, statematerials.Input) (statematerials.Input, error)` / `clearTable(*statematerials.Input)`。
- Produces: `ownPolicy(context.Context, statepolicy.ModelInput) (statepolicy.ModelInput, error)` / `clearPolicy(*statepolicy.ModelInput)`；`ownPolicyBinding(context.Context, statepolicybinding.Input) (statepolicybinding.Input, error)` / `clearPolicyBinding(*statepolicybinding.Input)`；`ownTimeBinding(context.Context, statetimebinding.Input) (statetimebinding.Input, error)` / `clearTimeBinding(*statetimebinding.Input)`；`ownTimeSummary(statetimebinding.Summary) statetimebinding.Summary` / `clearTimeSummary(*statetimebinding.Summary)`。

- [ ] **Step 1: 写完整字段复制、别名及生命周期失败测试。** `TestCertTimeOwnedComplete` 用纯值输入填满十二域、Expected 嵌套集合、Target/Anchor、Batch/二维 rotations、Old/每 root keys/每 key、History、两信封和所有观测，逐字段断言复制后保留。`TestCertTimeOwnedAliasIsolation` 故意共享 raw/重叠 subslice/两个 Main 集合，修改 owned 一位置不改变原输入或另一个 owned 位置；两个独立 ownInput 不共享 backing。

```go
// TestCertTimeNormalizeTimes：同 instant 的 offset 表示与非零纳秒。
if got := normalizeTime(withOffset); got != withOffset.Round(0).UTC() { t.Fatal(got) }
if normalizeTime(time.Time{}) != (time.Time{}) { t.Fatal("missing time repaired") }
// TestCertTimeModelLifecycle：由本包测试直接构造私有有效 owner，不称真实 Evaluate。
m := &Model{owned: o}; copied := *m
first, second := m.Summary(), m.Summary()
// 修改 first.Time.Policy.Binding.Proposed.Target.Links/Coverage，second 与 o 均不变。
copied.Clear(); copied.Clear()
if !reflect.DeepEqual(m.Summary(), Summary{}) { t.Fatal("shared lifecycle") }
// retained owned raw/slice backing 全零；原输入、first、second 和另一个 owner 不变。
// nil/zero Model Summary 完整零值，Clear 不 panic。
```

各 `TestCertTimeOwnedCertificate/Binding/Content/Table/Policy/Time/Summary` 负责
该文件全部可变字段、empty→nil、原集合顺序；只有两表顶层按 Kind/P 排序。
时间字段清单为 Policy.Time.Now/Floor、Old.TimeFloor、Old.Keys[].Material.
NotBefore/NotAfter/RevokedAt、FirstRevokedAt/LastSnapshotUntil/LastCompositeDeadline、
History 两 deadline、外层 Time.Time.Time.Now/Floor；主状态整数时间不动。

- [ ] **Step 2: 运行取得 RED。** `& $certTimeGo test ./internal/nodecontrol/nodecerttime -run '^TestCertTime(Owned.*|NormalizeTimes|ModelLifecycle)$' -count=1 -p=1 -timeout=120s`；预期缺 owned/Model 接口，或明确复制/规范化断言失败。

- [ ] **Step 3: 在指定文件实现完整输入拥有与清理接口。** 每个 helper 先将借用的全部可变字段脱钩为 nil，再登记失败/panic 清理，再逐项克隆；二维外层先脱钩内层 raw，Old 新指针先脱钩 Roots/Keys/RevokedIDs，每 Root.Keys 也先脱钩。每次 context 回调前保护已复制部分；不清零仍借用的 input。`ownInput` 调用 preflight 并仅一次转移完整 owner；不在类型复制路径调用额外判定器。

- [ ] **Step 4: 实现受保护的摘要复制与包装生命周期。** `ownTimeSummary` 只深复制 Links/Coverage，并在第一次分配前登记清理；其余全部值原样复制。Model.Summary 仅对 valid owner 返回完整深复制 Summary；Model.Clear 经共享 owner.clear 清零 input/summary/valid，不仅切断当前包装指针。只有已拥有的 Old 可调用 Clear，不清理调用者输入。

- [ ] **Step 5: 重跑 Step 2 取得 GREEN 并运行 Task 1 的新包测试。** PASS/exit 0；记录可观察 backing 清零和原输入隔离。分配失败/不可返回 owner 的内存擦除不作运行证明，后续 Task 5 固定源码登记次序。



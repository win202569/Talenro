# Task 5 brief

BASE: f5d731bef9d767d57ca32f0f4c3a0f532a4bc322

Approved plan/spec; no Git writes; Tasks 1–4 complete.

### Task 5: 精确能力/所有权/消费者守卫、23 命令矩阵与 fresh 审查

**Files:** Create/Test `boundary_test.go`、`ownership_boundary_test.go`、`consumer_boundary_test.go`；只在发现本增量问题时修指定新文件/八旧测试，遵循相应修复 TDD；完成后如实更新本计划与本增量执行记录。

**Interfaces:**
- Consumes: 完整 35 文件库存、公开 API 和前四任务私有接口/实际源码；不改变产品接口。
- Produces test-only: `certTimeProductAllowed([]byte) bool`、`certTimeCapabilityAllowed(map[string][]byte) bool`、`certTimeOwnershipAllowed(map[string][]byte) bool`、`certTimeConsumerAllowed(path, pkg, imported string) bool`；测试辅助 `certTimeSources(testing.TB) map[string][]byte`、`certTimeMutation(t testing.TB, sources map[string][]byte, file, old, replacement string) map[string][]byte`。mutation 必须改变实际源码，否则控制本身失败。

- [ ] **Step 1: 写精确 guard 的正反失败测试并运行 RED。** `TestCertTimeProductBoundary/CapabilityBoundary/OwnershipBoundary/Consumers` 检查真实新包；正例含安全命名别名、Round(0).UTC()、同目录同包测试 import。负例逐项覆盖禁止能力/额外导出或全局 hook/Proof 改号/新文件子目录/对旧包的违规入口、时间方法参数绕过、方法值/判定器函数值逃逸、别名遮蔽、dot/blank/重复 import、goroutine/recover；消费者 subpath、外部测试包及其他根也拒绝。

所有权 mutation 逐项删除/后移完整输入 defer、部分 clone cleanup、lower
立即 Clear、可变 Time Summary 直接受保护捕获、Summary 两集合复制、最终
context/valid/transfer 顺序及 backing 清零，均须被拒绝。良性语法/格式/命名
别名仍接受；不把字符串扫描或单个 guard 声称为形式安全证明。
Run: `& $certTimeGo test ./internal/nodecontrol/nodecerttime -run '^TestCertTime(ProductBoundary|CapabilityBoundary|OwnershipBoundary|Consumers)$' -count=1 -p=1 -timeout=120s`；预期 guard 未定义或指定 mutation 未拒绝。

- [ ] **Step 2: 实现 AST/源码库存守卫并重跑 GREEN。** 产品 import/member 精确白名单为下表；测试源自身可用 AST/文件读取工具，仅作本机测试。最终守卫同时核对公开字段/签名、owner 三字段、六 sentinel 文字、无其他全局可变值/导出能力和 35 文件库存，不默认允许整包。

| import（本地前缀 talenro.local/platform/internal/nodecontrol/） | 产品允许的 package 成员 |
| --- | --- |
| context / errors / bytes / sort / time | Context / New / Clone,Compare / Slice / Time |
| nodeissuer | Input, Summary, Evaluate, NodeLeafDirectIssuerSignatureBound |
| statetimebinding | Input, Summary, Evaluate, ConditionalTimeEvidenceBound |
| statepolicybinding | Input |
| statebinding | Input |
| statecontract | MainStateContentModel |
| statematerials | Input, RootSet, RootRotation |
| statepolicy | ModelInput, StateModel |

不需要 contracts 的直接 import；若实现需要白名单以外的成员，先书面修订，
不放宽整包。明确拒绝 stateformat/statecomposition/stateverify/statetime/nodeca/
nodeleaf/nodeleafkeys 的直接 import（产品及新测试）；泛型推导其嵌套值。
方法只允许 context.Err、time.Time 的 Round(0)/UTC/IsZero/Year/Before、
用于节点 canonical 对比的 UUID.String、两个真实 lower 的 Summary/Clear、
已拥有 Old.Clear 及本包声明的私有生命周期 helper；不开放其他 method call。
两次 Evaluate 必须直接调用在 lower.go，UUID.String 仅 binding.go 节点等式，
时间规范化仅 normalizeTime；AST guard 对方法值、别名赋值及隐藏调用做反控制。
新包消费者唯一例外为 exact 当前根直接目录/package=nodecerttime 的 _test.go，
其产品文件、外部测试、子目录/子路径/sibling/其他根一律拒绝。

- [ ] **Step 3: 格式检查并执行 23 个独立最终命令。** `& $certTimeFmt -l` 加本增量 35 个新 Go 路径和八个旧测试路径，期望空输出/exit 0；需要格式化只限这些文件，不整仓重写。下列每行单独计数/留证，不使用 ./...、不把 store 记成已跑测试：

```powershell
& $certTimeGo test ./internal/nodecontrol/nodecerttime -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/nodeissuer -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/nodeca -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/nodeleaf -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/nodeleafkeys -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/contracts -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/serving -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statebinding -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statecomposition -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statecontract -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/stateformat -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statematerials -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statepolicy -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statepolicybinding -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/staterecovery -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statetime -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/statetimebinding -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/stateverify -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/readiness -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/authority -run '^(TestBoundRead|TestCoordinator)' -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/store -run '^$' -count=1 -p=1 -timeout=120s
& $certTimeGo test ./internal/nodecontrol/nodeissuer -run '^$' -fuzz '^FuzzIssuerEnvelope$' -fuzztime=5s -parallel=1 -p=1 -timeout=30s
& $certTimeGo test ./internal/nodecontrol/nodeissuer -run '^$' -fuzz '^FuzzIssuerPair$' -fuzztime=5s -parallel=1 -p=1 -timeout=30s
```

期望 23 个实际 exit code 全为 0；19 完整包与 authority 指定测试 PASS，
store 仅 compile/no tests to run，两 fuzz 完成原配置。记录 fuzz 基线/实际
时长和启动等待，不把 5s 说成整个进程只运行 5s。任何失败先按
systematic-debugging 查因；不能跳过变成通过、擅改 timeout 或扩展旧产品。

- [ ] **Step 4: 冻结增量并取得一次 fresh 只读质量/安全审查。** Native 执行完后按照该方法要求，派一位新上下文最强可用 reviewer，审本增量相对 f5d731be 的实际修改与新增未跟踪文件、已批准规格/计划、原始证据，不审旧提交为新贡献；这是执行方法的明确审查步骤，不是本轮已启动的代理。审查者不改文件/Git、不替作者补证、不跑扩展验收；发现问题修复并重测影响项及最终矩阵，报告未解决项，不能预填“零问题”。

- [ ] **Step 5: 仅在证据与审查完成后记录实际交付并请求下一授权。** 执行文档记逐任务 RED/GREEN、fixture 核对、格式、23 矩阵、源码前后 hash、最终审查真实结论和所有未认证责任；计划 checkbox 只标实际完成步骤。任何取消/失败/验收阻塞保留，不把有限测试/短 fuzz/AST/单审查扩称整仓、race/Linux、DB/Docker、TLS/provider、硬件/reboot/PITR 或 C12 权威验收。没有后续 Git 批准时停在本机修改与待保存状态，明确不能换电脑恢复新增进度。

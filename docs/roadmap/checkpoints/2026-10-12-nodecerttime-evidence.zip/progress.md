# SDD ledger — plan: docs/superpowers/plans/2026-10-12-node-certificate-time-binding.md

User approved plan and recommended Native execution in latest message. No Git write/push/merge/cleanup authority. BASE f5d731bef9d767d57ca32f0f4c3a0f532a4bc322; linked worktree confirmed, no superproject; only this spec/plan initially untracked.

## Pre-flight shared interfaces

| Producer → Consumer | Shared contract | Finding |
| --- | --- | --- |
| Task 1 → Task 2 | Input/Summary/preflight, all caps before empty | consistent |
| Task 2 → Task 3 | protected owner, owned Input, summary ownership | consistent; lower Time summary must capture directly |
| Tasks 1–3 → Task 4 | ownInput/lower/binding/stageError | consistent; new Proof/valid only after final context |
| Tasks 1–4 → Task 5 | exact API, 35 files, 8 consumer changes, flow | consistent; no extra imports/old changes |

Ruling: Use native PowerShell equivalents for Bash-only workspace/task-start/task-done/review packaging scripts — user's PowerShell-only constraint and evidence-preserving no-Git plan override defaults — cost if wrong: bookkeeping must be audited against actual command receipts.
Ruling: No dependency download/full-repo baseline, no commits or scratch deletion — approved plan explicitly freezes cached offline dependencies, limited matrix and evidence preservation — cost if wrong: broader integration/acceptance remains unverified.

## Tasks

- [x] Task 1: complete — contract/preflight/eight consumer exceptions; 011–020 GREEN.
- [x] Task 2: complete — complete owned input/shared lifecycle; 025/026 GREEN.
- [x] Task 3: complete — real frozen controls/lower/snapshot; 034/035 GREEN.
- [x] Task 4: complete — windows/deadline/Evaluate; 040/041 GREEN.
- [x] Task 5: complete — guards/23 valid matrix commands/one fresh review/author closeout; M1 deferred, no Git writes.

Task 1: started at unchanged BASE; brief task-1.md. Read full plan/spec/required skills. Test-first steps next; no product implementation yet.

Task 1: RED 001/002 new contract missing Input/errors/preflight, actual exit 1; 002 completes test-helper declaration before implementation. RED 003–010 each old consumer guard fails four exact new positive cases (and 7 old guards accept prohibited subpath), all actual exit 1. No fixture/semantic/control error asserted as acceptance.
Task 1: implemented contract/budget and eight exact consumer branches after observed RED; prior branches/cases unchanged. GREEN next, not yet complete.

Task 1: complete (BASE/HEAD unchanged f5d731be; no commits). 011 contract + 012–019 eight exact consumer commands exit 0; task-done 020 full new package `test ./internal/nodecontrol/nodecerttime -count=1 -p=1 -timeout=120s` exit 0. Actual outputs read; every named Task 1 test ran. No whole-repo acceptance claim.
Task 2: started at unchanged BASE, brief task-2.md read; no product implementation yet. Runner now preserves .started.json before Go to distinguish incomplete execution from final receipt.

Task 2: 021 expected missing owned/Model compile RED (exit 1); 022 named ownership/lifecycle suite GREEN (exit 0). Coverage inspection found identical table references did not distinguish sorting directions. 023 intentional reversed comparator control RED; comparators currently reversed and MUST be restored before completion. Additional literal order/empty controls and independent Kind/P branches run next; no final Task 2 claim yet.

Task 2: 024 both Kind/P comparator mutation controls actually fail (exit 1); original comparators restored. 025 all named owned/normalization/lifecycle plus order/empty controls GREEN (exit 0); task-done 026 full new package `test ./internal/nodecontrol/nodecerttime -count=1 -p=1 -timeout=120s` exit 0. All outputs read. Task 2: complete at unchanged BASE, no commits. Input/summary caller separation and reachable cleanup observed; no claim for inaccessible failure memory.
Task 3: started at unchanged BASE; task-3.md brief next. Frozen test generation only in this plan's scratch; ordinary new tests may not import the seven prohibited lower packages or re-sign.

Task 3: generation 027 initially failed on field names, corrected before 028 success. Independent checker 029/030 failed on checker schema/type names (not behavior RED); corrected checker 031 verified 34 packets, fresh DER/SPKI/TBS/signatures and real lower outcomes. Ordinary frozen controls 032 pass. Full Input JSON and manifest are losslessly gzip/base64 constants for source size, decoded per call to independent values; no re-signing or old fixture mutation.
Task 3: 033 expected missing lower/binding interface compile RED; 034 named suite GREEN; task-done 035 full new package exit 0. All outputs read. Original lower sentinel and typed PolicyFailure identity semantics preserved; helper synthetic snapshot mutations distinguished from real public evidence.
Task 4: started at unchanged BASE, task-4.md brief to read. No commits or cleanup.

Task 4: 036/037 compile RED missing new interfaces (036 also corrected Identity field); 038 corrected Coverage field compile issue; 039 priority control used leaf's 512 cap for CA declared key and failed as expected for wrong test limit, corrected control to approved 8192 cap without changing product. 040 all named tests pass; task-done 041 full new package exit 0. Observed nanosecond windows, min/ties, no containment, responsibility retention, alias lifecycle, every detectable counting-context cancel/deadline/panic point. No hard realtime or inaccessible failure-memory claim.
Task 4 author flow check also checks issuer Proof immediately before the second lower call, per spec §6, in addition to final combined proof check.
Task 5: started at unchanged BASE; brief task-5.md next. Version-locked AST structural schemas will supplement explicit import/call/API checks for flow/ownership; they are change controls, not a formal safety proof.

Task 5: 042 missing guard helpers compile RED; 043 schema initialization and legal deferred FuncLit false-negative diagnosed; 044 guard positives/active negative mutations GREEN. 045 independently rechecked JCS raw envelope/payload and material references; 046 expanded manifest controls actually fail against original manifest; 047 frozen independently verified expanded manifest and boundary/counting controls GREEN. Ordinary fixtures remain exact original generated packets, no re-signing. Guard schemas alpha-normalize bound locals and safe imports while locking API/flow; not generic proof or claimed formal assurance.
Task 5 steps 1–2 complete. Final format/matrix to execute now, followed by one fresh reviewer. No Git writes.

Task 5: 048 format actual exit 0, empty output, exact 43 paths. 047 counting control measured 602 observable Err callbacks and traversed every cancel/deadline/panic point. Final matrix 049–066 all actual exit 0. 067 setup failed (no tests started): approved plan used nonexistent internal/nodecontrol/readiness.
Ruling: Use actual ./internal/readiness and ./internal/store for the named readiness/full and store/compile-only validations — rg package declarations and directory checks prove both are at internal/, while spec names these packages without the mistaken nodecontrol prefix — cost if wrong: recorded command differs from plan typo; 067 failure stays preserved and does not count as passing. No source, timeout, dependency or test-selection expansion; store bad path is not needlessly attempted.

Task 5: final valid matrix 049–066/072/068–071 is 23 exit0 commands; actual attempts include 067 path failure (24 matrix executions total). evidence-audit.json verifies source-before/after and common377-source set for all23. 069 store: no tests to run. 070 Envelope110263 executions, 5 initial; 071 Pair8, 4 initial; configured5s short fuzz, actual times recorded. All actual outputs read.
Task 5 steps 1–3 complete; review-package.md prepared. Fresh final readonly reviewer next. Git readonly audit: HEAD/index/config unchanged, exactly8 old test modifications +35 new Go +own spec/plan. Spec hash unchanged. Execution/status docs not yet created; final review not yet claimed.

## Final review disposition

One fresh gpt-6-astra/xhigh read-only reviewer completed the approved increment review; exact returned report saved as final-review.md. Reviewer read all 17 product/18 test files (excluding encoded bodies), eight tracked diffs, approved requirements and raw evidence; independently hashed current377 nodecontrol Go sources and decoded both constants against this plan's fixed JSON. Reviewer ran no tests or writes. Root checked the API comments and actual lifecycle before grading: 0 Critical, 0 Important, 1 Minor. No fix pass or second reviewer is required; no Go source change follows this report.

Final: minor (deferred): M1 exported API comments should state fresh-observation reevaluation, ValidUntil's non-cache/non-authorization meaning, shared wrapper Clear invalidation and unsupported concurrent Clear/read — a genuine documentation gap, nonblocking for the presently isolated no-runtime-consumer increment; not an implementation defect. Must remain visible to future integration work. No product comment edit in this execution.

Each reviewer Declined-to-judge line is adjudicated below in report order. These decisions do not turn unknowns into verified guarantees or authorize new consumers.

Final: Ruling: R04 current-time authenticity and observation provenance — a user gets only a conditional caller-supplied observation, not a trusted clock/provider; the proof remains explicitly conditional — cost if wrong: untrusted time could be mistaken for real certificate validity.
Final: Ruling: R05 atomic external capture — independent owned copying protects the supplied values but does not make an external read atomic; no capture API is added — cost if wrong: mixed platform observations could be mistaken for one physical snapshot.
Final: Ruling: R06 TLS/transport authentication — no transport verifier is implemented or invoked; the result grants no channel trust — cost if wrong: unauthenticated transport could be accepted by a later consumer.
Final: Ruling: R07 atomic nonce consumption — comparison/evaluation does not consume a nonce; no transactional replay guarantee is supplied — cost if wrong: a later consumer could permit replay.
Final: Ruling: R08 durable checkpoint/physical commit — this pure evaluation performs no persistent advancement or commit; caller persistence remains separate — cost if wrong: restart could lose or reuse an observation.
Final: Ruling: R09 CA provenance/self-signature/parent-root-chain/path/deployment-purpose trust — direct issuer mathematics and inherited Pending are retained, not promoted to deployment trust — cost if wrong: an untrusted CA could be interpreted as authorized.
Final: Ruling: R10 trust-bundle authorization and rollback history — retain lower conditional policy checks without adding trusted bundle integration or durable complete-history evidence — cost if wrong: unauthorized bundles or rollback could be mistaken for trusted state.
Final: Ruling: R11 main-state selected leaf/issuer/serial/public-key/key-handle/epoch/lineage/row correspondence — those relations are not bound by this increment; existing Pending remain visible — cost if wrong: unrelated certificate material could be used for a main-state identity.
Final: Ruling: R12 certificate authority-epoch/metadata-domain authentication — no equality is invented without a signed transcript contract; these extra relations remain unproved — cost if wrong: mismatched authority/domain could be mistaken for authenticated association.
Final: Ruling: R13 time-signer authentication of certificate digests — the time transcript omits them; composition does not claim that they were signed — cost if wrong: a mathematical composition could be mistaken for a jointly signed certificate/time attestation.
Final: Ruling: R14 full issuance template/issuer-time/skew/whole-leaf-window containment — only the approved half-open observed-time windows and exact minimum are enforced; wider leaf windows are deliberately permitted — cost if wrong: a future deployment's additional certificate policy could be bypassed.
Final: Ruling: R15 private-key possession/hardware protection — no key operation or hardware evidence exists; public certificate evidence proves neither — cost if wrong: an unavailable or unprotected key could be treated as possessed/protected.
Final: Ruling: R16 State/Commit/Ready/Authorize/startup/recovery/connection permission — no runtime consumer or authorization route is added; the model is evidence only — cost if wrong: conditional evidence could trigger unsafe runtime authorization.
Final: Ruling: R17 fresh-install/missing-Desired/changed-root-metadata support — preserve the existing time-binding evaluator's supported shapes and rejection/error behavior — cost if wrong: unsupported installation or transition cases could be incorrectly advertised as supported.
Final: Ruling: R18 concurrent mutation/Model-Summary-Clear use — shared lifecycle is sequential and concurrency is unsupported; owned copies do not supply linearization — cost if wrong: a caller could race reads, mutation or Clear.
Final: Ruling: R19 hard-real-time cancellation/peak memory — only observable callback cancellation and declared raw caps are evidenced, not latency deadlines or total heap ceilings — cost if wrong: deployment resource or latency limits could be exceeded.
Final: Ruling: R20 strings/unreachable-runtime copies/fatal OOM-crash erasure — cleanup covers reachable owned mutable values under ordinary unwind, not full-process or crash-time erasure; inaccessible failure owners are source-supported, not directly observed — cost if wrong: secrets or evidence copies could remain outside the stated boundary.
Final: Ruling: R21 formal capability/heap-safety proof — finite AST version locks and mutation controls are regression barriers, not a formal sandbox — cost if wrong: future bypasses could evade the finite controls.
Final: Ruling: R22 exhaustive crypto-fixture coverage/fresh audit of every lower — 34 fixed controls and short fuzzing support this composition; inherited algorithms are not comprehensively re-audited — cost if wrong: untested cryptographic or lower-layer defects could remain.
Final: Ruling: R23 independent dynamic reproduction — reviewer source/hash/constant checks are independent, while every test outcome remains author-run evidence — cost if wrong: the reader could overestimate independent dynamic verification.
Final: Ruling: R24 whole-repo/race-Linux/DB-Docker/real TLS-provider/hardware-reboot-PITR — the finite native matrix supplies none of these broader acceptance claims; production/provider compatibility stays UNKNOWN — cost if wrong: environment or integration failures could remain undiscovered.
Final: Ruling: R25 remote recovery/merge-release/Task10-B01-C12-main blockers — local evidence and modifications are retained without Git writes or acceptance promotion; a separate save/push approval remains necessary — cost if wrong: progress could be unavailable on another computer or mistaken for release-ready.

Task 5: complete (BASE/HEAD unchanged f5d731be, no commits; task-done 073 `test ./internal/nodecontrol/nodecerttime -count=1 -p=1 -timeout=120s` actual exit0, Go reports21.708s). Full outputs read; 23 valid final matrix commands remain green on current377 Go sources; 067 setup/path failure preserved. pre-closeout-audit.json checked exact35 inventory, all23 source pairs/current hashes, 048 exact43 format paths, 073 source pairs, index/config/spec preservation, exact47 Git status entries and empty staged diff/diff-check exit0. One final review:0 Critical/0 Important/1 Minor deferred; all22 Declined lines receive root Rulings. Execution/current-status facts authored and read back, plan only actual checkboxes updated. Final closeout-audit follows this ledger record; no source/fuzz/consumer changes after review, no additional reviewer. All five task completion contracts met within finite Native scope; scratch/worktree preserved by original Ruling2, broader finishing-a-branch full-suite/integration/cleanup defaults not executed. Next Git evidence save/commit/development push requires separate authority; C12/main/production blockers remain.

## Authorized checkpoint save phase (historical closeout unchanged)

Human approved necessary evidence archive, commit and ordinary existing-development-branch push without main merge/PR/force/config/cleanup. checkpoint-authorization.md and checkpoint-baseline.json record the fresh authority and old review/HEAD/index boundary; no historical no-Git claim is retroactively rewritten.

074 checkpoint-format exact43 paths: exit0/empty. 075–097 checkpoint matrix all23 actual exit0:19 full packages, selected authority, store compile-only/no tests, two configured5s fuzz. Source before/after377 matches original reviewed source, command/whitelisted environment unchanged, all outputs read. 096 Envelope40 executions/9 cached initial entries/new0; Go8.261s. 097 Pair5,037/4 initial/new1(total5); Go7.996s. These finite runs do not replace prior110,263/8 evidence or imply exhaustive coverage. checkpoint-verification.json stores complete source hashes and actual timing/command/exit comparisons. M1 remains deferred, no source changes or second review.

Checkpoint archive will preserve this plan's original failures/diagnoses, complete reviewer report, all25 Rulings and M1, original/fresh command receipts and source hashes, fixed signed materials/manifest, briefs and scripts. Exclude go-cache/dependencies/credentials/other plans. Ordinary Git save is newly authorized, but main/C12/provider acceptance is unchanged. Staging/commit/push occur after the archive snapshot and therefore are not pretended to be inside that snapshot; final Git receipts/chat are the actual delivery evidence. Originals and worktree remain in place.

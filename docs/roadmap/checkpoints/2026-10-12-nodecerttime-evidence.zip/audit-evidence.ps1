$ErrorActionPreference='Stop'
$certTimeRoot='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
Set-Location -LiteralPath $certTimeRoot
$certTimeEvidence=Join-Path $certTimeRoot '.superpowers/sdd/2026-10-12-node-certificate-time-binding'
$certTimeIds=@('049-final-nodecerttime','050-final-nodeissuer','051-final-nodeca','052-final-nodeleaf','053-final-nodeleafkeys','054-final-contracts','055-final-serving','056-final-statebinding','057-final-statecomposition','058-final-statecontract','059-final-stateformat','060-final-statematerials','061-final-statepolicy','062-final-statepolicybinding','063-final-staterecovery','064-final-statetime','065-final-statetimebinding','066-final-stateverify','072-corrected-final-readiness','068-final-authority','069-final-store-compile','070-final-fuzz-envelope','071-final-fuzz-pair')
$certTimeReference=Get-Content -LiteralPath (Join-Path $certTimeEvidence '049-final-nodecerttime.json') -Raw|ConvertFrom-Json
$certTimeReferenceHashes=@($certTimeReference.SourceAfter|ForEach-Object{$_.Path+' '+$_.SHA256})
$certTimeAudit=@()
foreach($certTimeId in $certTimeIds){
 $certTimeRun=Get-Content -LiteralPath (Join-Path $certTimeEvidence ($certTimeId+'.json')) -Raw|ConvertFrom-Json
 $certTimeBefore=@($certTimeRun.SourceBefore|ForEach-Object{$_.Path+' '+$_.SHA256})
 $certTimeAfter=@($certTimeRun.SourceAfter|ForEach-Object{$_.Path+' '+$_.SHA256})
 $certTimeFrozen=(@(Compare-Object $certTimeBefore $certTimeAfter).Count -eq 0)
 $certTimeSame=(@(Compare-Object $certTimeReferenceHashes $certTimeAfter).Count -eq 0)
 $certTimeAudit+=[pscustomobject]@{RunId=$certTimeId;Arguments=$certTimeRun.Arguments;ExitCode=$certTimeRun.ExitCode;DurationSeconds=([DateTime]$certTimeRun.EndedUTC-[DateTime]$certTimeRun.StartedUTC).TotalSeconds;SourceFrozen=$certTimeFrozen;SameSourceSet=$certTimeSame;SourceCount=$certTimeAfter.Count}
}
$certTimeAll=@(Get-ChildItem -LiteralPath $certTimeEvidence -Filter '*.json' -File|Where-Object{$_.Name -match '^[0-9]{3}-.+(?<!started)\.json$' -and $_.Name -notlike '*.started.json' -and $_.Name -ne '048-format.json'}|ForEach-Object{$certTimeRun=Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json;[pscustomobject]@{RunId=$certTimeRun.RunId;ExitCode=$certTimeRun.ExitCode;Arguments=$certTimeRun.Arguments}})
$certTimeResult=[pscustomobject]@{Matrix=$certTimeAudit;MatrixCount=$certTimeAudit.Count;AllMatrixPass=(@($certTimeAudit|Where-Object{$_.ExitCode -ne 0 -or !$_.SourceFrozen -or !$_.SameSourceSet}).Count -eq 0);AllGoReceipts=$certTimeAll}
$certTimeResult|ConvertTo-Json -Depth 8|Out-File -LiteralPath (Join-Path $certTimeEvidence 'evidence-audit.json') -Encoding utf8
$certTimeAudit|ConvertTo-Json -Depth 4
Write-Output ('matrix '+$certTimeResult.MatrixCount+', all pass/frozen '+$certTimeResult.AllMatrixPass+', all Go receipts '+$certTimeAll.Count)
if(!$certTimeResult.AllMatrixPass){exit 1}

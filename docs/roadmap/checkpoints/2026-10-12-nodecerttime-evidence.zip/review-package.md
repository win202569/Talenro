# Fresh readonly whole-increment review package
Workspace: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
BASE = HEAD = f5d731bef9d767d57ca32f0f4c3a0f532a4bc322.
No commit made for this increment. Review actual working diff plus all new/untracked files; git diff BASE..HEAD alone is empty and NOT the implementation.
Approved plan: docs/superpowers/plans/2026-10-12-node-certificate-time-binding.md
Approved spec: docs/superpowers/specs/2026-10-12-node-certificate-time-binding-design.md
Spec SHA256: 595A4471C642727AE60D8C816BDEDAA65FD3B9F21EF812B503CDD12F91CE694B
Historical planning headers remain unchanged; user approved implementation and Native execution in latest message.
Scope: exact internal/nodecontrol/nodecerttime 35 Go (17 product +18 tests), 8 existing boundary tests consumer exceptions only. No old product/testdata/module/config/SQL changes.
Ledger/rulings: .superpowers/sdd/2026-10-12-node-certificate-time-binding/progress.md
Evidence: same directory, run-go.ps1, numbered *.json and full stdout/stderr. 001–072 contain every compile RED, controls and final verification. 048-format actual 43-path clean. 049–066 +072 +068–071 are 23 valid final commands, all exit 0; 067 nonexistent readiness path failed before tests, retained. Correct readiness/store paths ./internal/readiness and ./internal/store are ledgered plan-typo ruling.
evidence-audit.json: confirms 23 receipts source-before=after and same 377 internal/nodecontrol Go source set throughout. This is not a hash of entire repo or all readiness/store code; tracked diff and status verify old products unchanged.
Fuzz Envelope config5s, initial5, executions110263, 7.116s Go test output, 56.684s Go-process elapsed including first instrumentation build. Pair config5s, initial4, executions8, Go test8.747s, Go-process11.122s. Finite short fuzz, not exhaustive.
047 counting context measured602 observable Err callbacks; every point cancellation, deadline, normal panic controls tested. Public failure owner unreturned cleanup supported by source/AST and observable reachable owner backing tests, not inaccessible memory read.
Generation: ignored generator/generate_test.go once-only local independent test helper construction; frozen-inputs.json(+gz) complete34 packets. Root Ed seed32x01, metadata/time32x02; P256 scalar1/2. Fresh checker generator/verify_test.go independently verifies x509 leaf signature, exact DER/SPKI/TBS/IDs, JCS bytes/Ed signatures/material refs and both actual lower results. Failures 027/029/030 are construction/checker errors, not behavior RED; corrected controls031/032 pass; expanded045/046/047 manifest check.
Ordinary fixtures_test.go uses two losslessly gzip/base64 encoded full fixed JSON constants, independently decoded per call. No random generation/signing or old fixture reads in ordinary tests. Read helper code without printing the long encoded constants; raw JSON/manifest in THIS plan evidence can be selectively inspected readonly.
Guards explicitly check import members/calls/inventory, plus frozen canonical AST schemas of current implementation. Safe imports/bound local renames normalize. Ownership source mutation controls lock defer/clone/lower/summary/transfer. These are finite implementation-version schemas, not generalized formal safety/heap proof.
Read actual files/requirements, weigh ledger rulings, do not take author claims as a review verdict. No reviewer source edits, Git writes, tests/caches, new worktrees, dependent acceptance, or subagents. Read-only commands only; GIT_OPTIONAL_LOCKS=0 and git -c core.fsmonitor=false for any Git reads. No native Bash on this user machine.
Review whole increment yourself in passes. Return strengths; Critical/Important/Minor issues with file:line, impact and proposed fix; explicit Declined to judge list (one reason per behavior); assessment of scoped partial increment readiness, not C12/main/full release approval. Be alert to behavior reasonable users expect even if spec silent.

## Review Focus

- 空锚与后半输入同时超限：Task 1 `TestCertTimePreflightPriority` 固定所有容量先于必需非空，不照搬旧 bindingBudget 的提前空锚返回。
- 输入共享底层切片、半途清理误伤调用者：Task 2 `TestCertTimeOwnedAliasIsolation` 与 Task 5 `TestCertTimeOwnershipBoundary` 分别证明可观察隔离及清理登记源码结构。
- 跨节点负例实际上坏在签名/下层时间：Task 3 `TestCertTimeCrossNodeControls` 先证明两份下层各自成立，再断言新绑定错误。
- 纳秒与合法 Go 零时刻的证书端点混淆：Task 4 `TestCertTimeWindowEdges`、`TestCertTimeYearOneEndpoints` 区分半开窗口、合法端点和缺失观测。
- 取消或 panic 出现在摘要捕获/移交附近：Task 4 `TestCertTimeCancellationAndPanic` 与 Task 5 所有权 mutation controls 固定最终 context、失败 nil、原输入不变和受保护捕获；不伪称观测不可返回 owner 的擦除。

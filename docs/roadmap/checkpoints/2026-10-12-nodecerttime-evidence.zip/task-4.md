# Task 4 brief

BASE: f5d731bef9d767d57ca32f0f4c3a0f532a4bc322

Approved plan/spec; no Git writes; Tasks 1–3 complete; protected owner and real lower controls available.

### Task 4: 半开窗、最小期限、取消/正常 panic 和公共 Evaluate

**Files:** Create `window.go`、`evaluate.go`；Test `window_test.go`、`evaluate_test.go`。

**Interfaces:**
- Consumes: Task 1–3 的 preflight/ownInput/evaluateLower/bindSnapshots/stageError 和真实 fixture 控制。
- Produces: `certificateWindow(now, start, end time.Time) error`、`checkWindows(Summary) (time.Time, error)`；公开 `Evaluate(context.Context, Input) (*Model, error)`。checkWindows 返回唯一最小 ValidUntil，不读取时钟或独立 Now。

- [ ] **Step 1: 写窗口与必要时间失败测试。** `TestCertTimeWindowEdges` 对 CA/leaf 的 start-1ns/start/start+1ns、end-1ns/end/end+1ns 分别先跑真实 lower 正控制，期望如下；unit helper 与完整 Evaluate 两类分开标记：

```go
// 每个端点使用 fixtures_test.go 冻结的相应自洽 Input，不事后改签名 raw。
// start-1ns -> ErrNotYetValid; start/start+1ns -> nil。
// end-1ns -> nil; end/end+1ns -> ErrExpired。
if got := certificateWindow(start.Add(-time.Nanosecond), start, end); got != ErrNotYetValid { t.Fatal(got) }
if got := certificateWindow(start, start, end); got != nil { t.Fatal(got) }
if got := certificateWindow(end.Add(-time.Nanosecond), start, end); got != nil { t.Fatal(got) }
if got := certificateWindow(end, start, end); got != ErrExpired { t.Fatal(got) }
// TestCertTimeYearOneEndpoints：合法 start=time.Time{}、end>start，不误判缺失端点。
if got := certificateWindow(yearOneNonzeroNow, time.Time{}, yearOneEnd); got != nil { t.Fatal(got) }
// TestCertTimeNecessaryTimes：Now/Time.ValidUntil zero，UTC year 0/10000，
// Now>=Time.ValidUntil，证书 start>=end/超年界 -> ErrInvalidEvidence。
// TestCertTimeDeadlineMinimum：time/CA/leaf 最早和每种并列，got == exact min。
// CA expired + leaf future -> ErrExpired；CA future + leaf expired -> ErrNotYetValid。
```

`TestCertTimeNonContainingLeafWindow` 真实两 lower 均成功且 Now 同时有效，
leaf 全窗不包含于 CA 仍接受，期限取较早者。`TestCertTimeFreshObservation`
改变 Now 1ns 后重新完整 Evaluate，ObservedAt 保留 ns；原 owner 摘要不被新
调用改写，不声称旧结果为新观测提供认证。

- [ ] **Step 2: 写完整流程与责任保留失败测试并运行 RED。** `TestCertTimeEvaluateGolden` 比较新 Proof、ObservedAt、最小期限及两个完整真实下层 Summary；`TestCertTimeObligationsRetained` 用 reflect.DeepEqual 比较所有嵌套责任，原两张 Pending 各六项保留。`TestCertTimeUnboundIdentity` 仅改变下层不认证的 Identity 引用、CA 自身签名/未认证来源，先证明 lower 控制再检查相同条件结果与未完成责任，不伪造 full-main-state 授权。

`TestCertTimeEvaluatePriority` 固定容量>空值>issuer>time>新绑定>CA>leaf；
`TestCertTimeIndependentLifecycle` 两次真实 Evaluate、两次 Summary、包装 Clear
不互相误伤。`TestCertTimeCancellationAndPanic` 用 test-only counting context
先量测真实 successful Err 调用点，再逐点检测取消/DeadlineExceeded/正常
panic，断言取消时 nil Model+原 context 错误、panic 原值传播、原输入不变。
test-only defer/recover 可用，产品不得 recover；保存能取得的 owned backing
控制，公共 Evaluate 的不可返回 owner 清理只以 Task 5 AST 控制支持。

Run: `& $certTimeGo test ./internal/nodecontrol/nodecerttime -run '^TestCertTime(Window.*|YearOneEndpoints|NecessaryTimes|DeadlineMinimum|NonContainingLeafWindow|FreshObservation|Evaluate.*|ObligationsRetained|UnboundIdentity|IndependentLifecycle|CancellationAndPanic)$' -count=1 -p=1 -timeout=120s`；预期缺接口或明确窗口/移交断言失败，不把 fixture 失败作 RED。

- [ ] **Step 3: 实现 window.go 两个接口。** checkWindows 验证必要 observation 时间和证书 start/end 年范围及严格升序；观察零值无效，但证书起点零时刻可有效。按 CA 后 leaf 调用 certificateWindow，仅用 Before/Year/IsZero；返回 min 三个 exact time.Time，不通过 Unix/Seconds/Duration 舍入、Add 延长或叶全窗包含判断。

- [ ] **Step 4: 实现 evaluate.go 的完整 Evaluate。** `ownInput` 返回后在下一 context 回调前登记 owner.clear；经 stageError 处理每阶段，运行两个 lower、绑定、窗口，写 ObservedAt/ValidUntil，最后 context 成功才设置新 Proof、valid 并转移包装。任何失败返回 nil；正常 panic unwind 不吞错，外部输入始终未改。

- [ ] **Step 5: 重跑 Step 2 取得 GREEN，并执行新包完整测试。** `& $certTimeGo test ./internal/nodecontrol/nodecerttime -count=1 -p=1 -timeout=120s`；所有测试 PASS/exit 0。标明计数 context 测的是可检测取消，不是硬实时取消/平台原子快照保证。

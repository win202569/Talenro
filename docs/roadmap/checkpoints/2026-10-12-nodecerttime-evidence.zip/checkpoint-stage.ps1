$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
$env:GIT_OPTIONAL_LOCKS='0'
$certTimeEvidence='.superpowers/sdd/2026-10-12-node-certificate-time-binding'
function Invoke-CertTimeGit([string[]]$arguments) {
 $certTimeOutput=@(& git -c core.fsmonitor=false @arguments)
 $certTimeCode=$LASTEXITCODE
 if($certTimeCode -ne 0){throw ('Git failed '+($arguments -join ' '))}
 [pscustomobject]@{Arguments=$arguments;ExitCode=$certTimeCode;Output=$certTimeOutput}
}
$certTimeBaseline=Get-Content -LiteralPath (Join-Path $certTimeEvidence 'checkpoint-baseline.json') -Raw | ConvertFrom-Json
$certTimePaths=@($certTimeBaseline.GitStatus.Output | ForEach-Object { $_.Substring(3) })
$certTimePaths+=@('docs/roadmap/2026-10-12-nodecerttime-checkpoint.md','docs/roadmap/checkpoints/2026-10-12-nodecerttime-evidence.zip','docs/roadmap/checkpoints/2026-10-12-nodecerttime-evidence-manifest.json')
if($certTimePaths.Count -ne 50 -or @($certTimePaths | Select-Object -Unique).Count -ne 50){throw 'expected50 path count'}
foreach($certTimePath in $certTimePaths) { if(!(Test-Path -LiteralPath $certTimePath -PathType Leaf)){throw ('missing checkpoint path '+$certTimePath)} }
$certTimeHead=Invoke-CertTimeGit @('rev-parse','HEAD')
$certTimeBranch=Invoke-CertTimeGit @('branch','--show-current')
$certTimeRemote=Invoke-CertTimeGit @('remote','get-url','--push','origin')
if($certTimeHead.Output[0] -ne 'f5d731bef9d767d57ca32f0f4c3a0f532a4bc322' -or $certTimeBranch.Output[0] -ne 'codex/c12-b01-task9-coordinator' -or $certTimeRemote.Output[0] -ne 'https://github.com/win202569/Talenro.git'){throw 'save HEAD/branch/remote changed'}
$certTimeEmptyIndex=Invoke-CertTimeGit @('diff','--exit-code','--cached')
$certTimeBefore=Invoke-CertTimeGit @('status','--porcelain=v1','--untracked-files=all')
if(@(Compare-Object $certTimePaths @($certTimeBefore.Output | ForEach-Object { $_.Substring(3) })).Count -ne 0){throw 'unapproved path in status'}
if((Get-FileHash -LiteralPath 'D:/Projects/Talenro/.git/config' -Algorithm SHA256).Hash -ne 'D6886A65FF6AD1EF560A526C23D99203DBC652BDA14A19E1CCD3EC603983285D'){throw 'config changed'}
$certTimeVerify=& (Join-Path $certTimeEvidence 'checkpoint-verify.ps1') | ConvertFrom-Json
if($LASTEXITCODE -ne 0 -or !$certTimeVerify.AllPass -or !$certTimeVerify.MatchesReviewedSource){throw 'checkpoint verification failed'}
$certTimeManifest=Get-Content -LiteralPath 'docs/roadmap/checkpoints/2026-10-12-nodecerttime-evidence-manifest.json' -Raw | ConvertFrom-Json
if((Get-FileHash -LiteralPath $certTimeManifest.Archive -Algorithm SHA256).Hash -ne $certTimeManifest.ArchiveSHA256){throw 'archive hash mismatch'}
$certTimeRawHashes=@($certTimePaths | ForEach-Object { [pscustomobject]@{Path=$_;Length=(Get-Item -LiteralPath $_).Length;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash} })
$certTimeAdd=Invoke-CertTimeGit (@('add','--')+$certTimePaths)
$certTimeNames=Invoke-CertTimeGit @('diff','--cached','--name-only')
if(@(Compare-Object $certTimePaths $certTimeNames.Output).Count -ne 0){throw 'staged path mismatch; preserve index for inspection'}
$certTimeCheck=Invoke-CertTimeGit @('diff','--cached','--check')
$certTimeBlobChecks=@()
foreach($certTimePath in $certTimePaths) {
 $certTimeExpected=Invoke-CertTimeGit @('hash-object',('--path='+$certTimePath),$certTimePath)
 $certTimeActual=Invoke-CertTimeGit @('rev-parse',(':'+ $certTimePath))
 if($certTimeExpected.Output[0] -ne $certTimeActual.Output[0]){throw ('staged content mismatch '+$certTimePath)}
 $certTimeBlobChecks+=[pscustomobject]@{Path=$certTimePath;ExpectedNormalizedBlob=$certTimeExpected.Output[0];StagedBlob=$certTimeActual.Output[0];Match=$true}
}
$certTimeUnstaged=Invoke-CertTimeGit @('diff','--exit-code')
if((Get-FileHash -LiteralPath 'D:/Projects/Talenro/.git/config' -Algorithm SHA256).Hash -ne 'D6886A65FF6AD1EF560A526C23D99203DBC652BDA14A19E1CCD3EC603983285D'){throw 'Git config changed during stage'}
[pscustomobject]@{CheckedUTC=[DateTime]::UtcNow.ToString('o');AuthorizedPaths=$certTimePaths;PathCount=50;HeadBefore=$certTimeHead;Branch=$certTimeBranch;Remote=$certTimeRemote;Add=$certTimeAdd;StagedDiffCheck=$certTimeCheck;UnstagedDiff=$certTimeUnstaged;BlobChecks=$certTimeBlobChecks;RawWorkingHashes=$certTimeRawHashes;ConfigUnchanged=$true;ReviewedGoSourceUnchanged=$true} | ConvertTo-Json -Depth 8


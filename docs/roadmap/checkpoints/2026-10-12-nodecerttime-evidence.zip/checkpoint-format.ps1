$ErrorActionPreference='Stop'
$certTimeRoot='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
Set-Location -LiteralPath $certTimeRoot
$certTimeEvidence=Join-Path $certTimeRoot '.superpowers/sdd/2026-10-12-node-certificate-time-binding'
$certTimeReceipt=Join-Path $certTimeEvidence '074-checkpoint-format.json'
if(Test-Path -LiteralPath $certTimeReceipt){throw 'receipt already exists'}
$certTimeFiles=@(rg --files internal/nodecontrol/nodecerttime -g '*.go')
$certTimeFiles+=@('nodeissuer','statetimebinding','statepolicybinding','statebinding','statecontract','statematerials','statepolicy','stateverify') | ForEach-Object {'internal/nodecontrol/'+$_+'/boundary_test.go'}
if($certTimeFiles.Count -ne 43){throw 'unexpected format inventory'}
$certTimeBefore=@($certTimeFiles|Sort-Object|ForEach-Object{[pscustomobject]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}})
$certTimeStart=[DateTime]::UtcNow.ToString('o')
$certTimeFmt='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/gofmt.exe'
& $certTimeFmt -l @certTimeFiles 1>(Join-Path $certTimeEvidence '074-checkpoint-format.stdout.txt') 2>(Join-Path $certTimeEvidence '074-checkpoint-format.stderr.txt')
$certTimeExit=$LASTEXITCODE
$certTimeEnd=[DateTime]::UtcNow.ToString('o')
$certTimeAfter=@($certTimeFiles|Sort-Object|ForEach-Object{[pscustomobject]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}})
$certTimeClean=((Get-Item -LiteralPath (Join-Path $certTimeEvidence '074-checkpoint-format.stdout.txt')).Length -eq 0)
[pscustomobject]@{RunId='074-checkpoint-format';Executable=$certTimeFmt;Arguments=@('-l')+$certTimeFiles;StartedUTC=$certTimeStart;EndedUTC=$certTimeEnd;ExitCode=$certTimeExit;Clean=$certTimeClean;SourceBefore=$certTimeBefore;SourceAfter=$certTimeAfter}|ConvertTo-Json -Depth 8|Out-File -LiteralPath $certTimeReceipt -Encoding utf8
Write-Output ('format: exit '+$certTimeExit+', clean '+$certTimeClean+', files '+$certTimeFiles.Count)
Get-Content -LiteralPath (Join-Path $certTimeEvidence '074-checkpoint-format.stdout.txt')
Get-Content -LiteralPath (Join-Path $certTimeEvidence '074-checkpoint-format.stderr.txt')
if(!$certTimeClean){exit 1}
exit $certTimeExit

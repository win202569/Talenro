$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
$certTimeEvidence='.superpowers/sdd/2026-10-12-node-certificate-time-binding'
function Get-CertTimeLines($entries) { @($entries | ForEach-Object { ($_.Path -replace '\\','/')+' '+$_.SHA256 } | Sort-Object) }
$certTimeCurrent=@(rg --files internal/nodecontrol -g '*.go' | Where-Object { $_ -notmatch '[\\/]testdata[\\/]' } | Sort-Object | ForEach-Object { [pscustomobject]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash} })
$certTimeLines=Get-CertTimeLines $certTimeCurrent
$certTimeReviewed=Get-Content -LiteralPath (Join-Path $certTimeEvidence '049-final-nodecerttime.json') -Raw | ConvertFrom-Json
if($certTimeCurrent.Count -ne 377 -or @(Compare-Object $certTimeLines (Get-CertTimeLines $certTimeReviewed.SourceAfter)).Count -ne 0){throw 'reviewed source mismatch'}
$certTimeNames=@('nodecerttime','nodeissuer','nodeca','nodeleaf','nodeleafkeys','contracts','serving','statebinding','statecomposition','statecontract','stateformat','statematerials','statepolicy','statepolicybinding','staterecovery','statetime','statetimebinding','stateverify','readiness','authority','store-compile','fuzz-envelope','fuzz-pair')
$certTimeOriginal=@('049-final-nodecerttime','050-final-nodeissuer','051-final-nodeca','052-final-nodeleaf','053-final-nodeleafkeys','054-final-contracts','055-final-serving','056-final-statebinding','057-final-statecomposition','058-final-statecontract','059-final-stateformat','060-final-statematerials','061-final-statepolicy','062-final-statepolicybinding','063-final-staterecovery','064-final-statetime','065-final-statetimebinding','066-final-stateverify','072-corrected-final-readiness','068-final-authority','069-final-store-compile','070-final-fuzz-envelope','071-final-fuzz-pair')
$certTimeRows=@()
for($certTimeIndex=0;$certTimeIndex -lt 23;$certTimeIndex++) {
 $certTimeId=('{0:D3}' -f (75+$certTimeIndex))+'-checkpoint-'+$certTimeNames[$certTimeIndex]
 $certTimeRun=Get-Content -LiteralPath (Join-Path $certTimeEvidence ($certTimeId+'.json')) -Raw | ConvertFrom-Json
 $certTimeOld=Get-Content -LiteralPath (Join-Path $certTimeEvidence ($certTimeOriginal[$certTimeIndex]+'.json')) -Raw | ConvertFrom-Json
 if($certTimeRun.ExitCode -ne 0 -or ($certTimeRun.Arguments -join [char]0) -ne ($certTimeOld.Arguments -join [char]0)){throw ('verification exit/command mismatch '+$certTimeId)}
 if(@(Compare-Object $certTimeLines (Get-CertTimeLines $certTimeRun.SourceBefore)).Count -ne 0 -or @(Compare-Object $certTimeLines (Get-CertTimeLines $certTimeRun.SourceAfter)).Count -ne 0){throw ('verification source mismatch '+$certTimeId)}
 foreach($certTimeEnvName in @('GOOS','GOARCH','GOTOOLCHAIN','GOPROXY','GOSUMDB','GOAUTH','GOVCS','GOFLAGS','GODEBUG','GOEXPERIMENT','GOCACHE')) { if($certTimeRun.$certTimeEnvName -ne $certTimeOld.$certTimeEnvName){throw ('environment changed '+$certTimeEnvName)} }
 $certTimeRows+=[pscustomobject]@{RunId=$certTimeId;Arguments=$certTimeRun.Arguments;ExitCode=$certTimeRun.ExitCode;StartedUTC=$certTimeRun.StartedUTC;EndedUTC=$certTimeRun.EndedUTC;DurationSeconds=([DateTime]$certTimeRun.EndedUTC-[DateTime]$certTimeRun.StartedUTC).TotalSeconds;BeforeAfterMatchCurrent=$true;SameArgumentsAndEnvironment=$true}
}
$certTimeFormat=Get-Content -LiteralPath (Join-Path $certTimeEvidence '074-checkpoint-format.json') -Raw | ConvertFrom-Json
if($certTimeFormat.ExitCode -ne 0 -or !$certTimeFormat.Clean -or $certTimeFormat.SourceAfter.Count -ne 43){throw 'format not clean'}
$certTimeCurrentMap=@{}
foreach($certTimeSource in $certTimeCurrent){$certTimeCurrentMap[($certTimeSource.Path -replace '\\','/')]=$certTimeSource.SHA256}
foreach($certTimeSource in @($certTimeFormat.SourceBefore)+@($certTimeFormat.SourceAfter)){if($certTimeCurrentMap[($certTimeSource.Path -replace '\\','/')] -ne $certTimeSource.SHA256){throw 'format source changed'}}
$certTimeSpec=(Get-FileHash -LiteralPath 'docs/superpowers/specs/2026-10-12-node-certificate-time-binding-design.md' -Algorithm SHA256).Hash
if($certTimeSpec -ne '595A4471C642727AE60D8C816BDEDAA65FD3B9F21EF812B503CDD12F91CE694B'){throw 'approved spec changed'}
$certTimeIncomplete=@(Get-ChildItem -LiteralPath $certTimeEvidence -File -Filter '*.started.json' | Where-Object { !(Test-Path -LiteralPath ($_.FullName -replace '\.started\.json$','.json')) })
if($certTimeIncomplete.Count -ne 0){throw 'incomplete Go process'}
[pscustomobject]@{CheckedUTC=[DateTime]::UtcNow.ToString('o');CurrentSourceCount=377;MatchesReviewedSource=$true;Format=@{RunId='074-checkpoint-format';ExitCode=0;Clean=$true;PathCount=43;MatchesCurrentSource=$true};Matrix=$certTimeRows;MatrixCount=23;AllPass=$true;SpecSHA256=$certTimeSpec;IncompleteProcessCount=0;SourceHashes=$certTimeCurrent} | ConvertTo-Json -Depth 8


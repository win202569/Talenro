# Task 1 brief

BASE: f5d731bef9d767d57ca32f0f4c3a0f532a4bc322

Read approved plan Global Constraints and spec; both binding. PowerShell-only, no Git writes. Eight exact old exceptions only.

### Task 1: 冻结公开合同、完整预复制预算与八处消费范围

**Files:** Create `doc.go`、`input.go`、`errors.go`、`budget.go`；Test `input_test.go`、`budget_test.go`；Modify 上表八份旧 boundary_test.go，仅指定 helper 的新例外和新增测试。

**Interfaces:**
- Consumes: `nodeissuer.Input/Summary`、`statetimebinding.Input/Summary`，上述完整预算，不调用判定器。
- Produces: 公开 Input/Proof/Summary；`preflight(context.Context, Input) error`、`certificateBudget(nodeissuer.Input) (int, error)`、`bindingBudget(statebinding.Input) (int, error)`、`contentBudget(statecontract.MainStateContentModel) bool`、`timeBudget(statetimebinding.Input) (int, error)`、`addRaw(total, size, limit int) (int, bool)`。预算 helper 只做容量，无空值/语义修补。

- [ ] **Step 1: 写合同、容量和顺序失败测试。** `TestCertTimePublicContract` 固定字段/枚举；`TestCertTimeFixedErrors` 逐项比较下面文字且六个 sentinel 独立：

```go
// None == 0; NodeCertificateConditionalTimeBound == 1; Proof 为 uint8。
// ErrInvalidInput.Error() == "nodecerttime: invalid input"
// ErrLimitExceeded.Error() == "nodecerttime: limit exceeded"
// ErrInvalidEvidence.Error() == "nodecerttime: invalid evidence"
// ErrBindingMismatch.Error() == "nodecerttime: binding mismatch"
// ErrNotYetValid.Error() == "nodecerttime: certificate not yet valid"
// ErrExpired.Error() == "nodecerttime: certificate expired"
if preflight(nil, Input{}) != ErrInvalidInput { t.Fatal("nil context") }
// TestCertTimePreflightPriority：五个必需 raw 逐个置空 + 后半 History 4097。
if got := preflight(context.Background(), overLimitAndEmpty); got != ErrLimitExceeded { t.Fatal(got) }
// 去掉超限，五个空值逐个返回 ErrInvalidInput；预取消返回 context.Canceled。
if total, ok := addRaw(43917823, 1, 43917824); !ok || total != 43917824 { t.Fatal("total edge") }
if _, ok := addRaw(43917823, 2, 43917824); ok { t.Fatal("total overflow accepted") }
```

`TestCertTimeBudgetEdges` 对 Global Constraints 每项两位置、每个嵌套元素做
等长与 +1：等长容量 helper 成功，+1 恰 ErrLimitExceeded；等长 raw 用共享
backing 重复填充，断言仍按位置累计。`TestCertTimeBudgetTotals` 固定
139776、16*1024*1024、32*1024*1024+262144、36*262144、32*1024*1024+37*262144、
524288、43778048、43917824；对 addRaw 做 total==limit/size==0 成功、
size==limit-total 成功、size==limit-total+1 失败，及整数最大值附近不溢出。
完整输入 +1 可能先触发分项上限，不能声称隔离到不可独立超过的总预算。
未知 kind 使用其他 raw 容量分类，不在 preflight 中拒绝；空但非必需值仍通过容量。

- [ ] **Step 2: 分别取得新包与旧消费案例的真实 RED。** 新包运行 `& $certTimeGo test ./internal/nodecontrol/nodecerttime -run '^TestCertTime(PublicContract|FixedErrors|Budget.*|PreflightPriority)$' -count=1 -p=1 -timeout=120s`；预期缺接口编译失败。八个旧文件各新增 `TestNodeCertTimeConsumerException`，逐包运行 `& $certTimeGo test ./internal/nodecontrol/<package> -run '^TestNodeCertTimeConsumerException$' -count=1 -p=1 -timeout=120s`；预期只在新 exact 消费正例失败，保留全部旧案例。

- [ ] **Step 3: 在四个产品文件实现上述类型、六错误和容量接口。** `addRaw` 拒绝负 total/size/limit、total>limit 或 size>limit-total 后才相加；全部预算扫描结束才做五项非空。全量 scan 的 context 检测不能改掉已检测取消优先规则；不调用旧私有预算或照搬旧空锚提前退出。

- [ ] **Step 4: 在八个旧 helper 加精确例外。** 同一测试名分别覆盖相对/当前根绝对路径、产品/同包测试允许；nested、相似前缀、else 后缀、另一个根、外部、wrong package、nodecerttime_test、sibling、目标 import/child 拒绝。目标 import 恰为该旧包，唯 stateverify 文件新目标恰为 statepolicy；stateverify 自身 import 明确仍拒绝。绝对/相对均先归一到当前仓库根，再比较直接目录和 package，不用宽泛前缀。

- [ ] **Step 5: 重跑 Step 2 九条局部命令取得 GREEN。** 所有命名测试 PASS/exit 0；保存预复制预算等长不是下层接受的说明。检查旧八文件只增加新例外及案例，无其他旧源码变化。



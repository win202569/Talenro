$ErrorActionPreference='Stop'
$certTimeRoot='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
$certTimeEvidence=Join-Path $certTimeRoot '.superpowers/sdd/2026-10-12-node-certificate-time-binding'
$certTimeArchive=Join-Path $certTimeRoot 'docs/roadmap/checkpoints/2026-10-12-nodecerttime-evidence.zip'
$certTimeManifest=Join-Path $certTimeRoot 'docs/roadmap/checkpoints/2026-10-12-nodecerttime-evidence-manifest.json'
if((Test-Path -LiteralPath $certTimeArchive) -or (Test-Path -LiteralPath $certTimeManifest)){throw 'checkpoint archive or manifest already exists; never overwrite'}
$certTimeFiles=@(Get-ChildItem -LiteralPath $certTimeEvidence -File -Recurse | Where-Object { $_.FullName -notmatch '[\\/]go-cache[\\/]' })
if($certTimeFiles.Count -lt 292){throw 'evidence unexpectedly incomplete'}
$certTimeMap=@{}
foreach($certTimeFile in $certTimeFiles) {
 if(($certTimeFile.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'evidence reparse file rejected'}
 $certTimeEntry=$certTimeFile.FullName.Substring($certTimeEvidence.Length+1).Replace('\','/')
 if($certTimeEntry -notmatch '^[a-zA-Z0-9._/-]+$' -or $certTimeEntry.StartsWith('/') -or @($certTimeEntry.Split('/') | Where-Object { $_ -in @('','..','.') }).Count -gt 0){throw 'unsafe ZIP entry path'}
 if($certTimeMap.ContainsKey($certTimeEntry)){throw 'duplicate ZIP entry'}
 $certTimeMap[$certTimeEntry]=$certTimeFile
}
$certTimeNames=[string[]]@($certTimeMap.Keys)
[Array]::Sort($certTimeNames,[StringComparer]::Ordinal)
$certTimeHighConfidence='(?i)(github_pat_[a-z0-9_]{20,}|gh[pousr]_[a-z0-9]{30,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----|sk-(?:proj-)?[a-z0-9_-]{32,})'
$certTimeSecretScanCount=0
foreach($certTimeName in $certTimeNames) {
 $certTimeFile=$certTimeMap[$certTimeName]
 if($certTimeFile.Extension -in @('.md','.go','.ps1','.json','.txt') -or $certTimeName -eq 'plan-path') {
  $certTimeSecretScanCount++
  if([regex]::IsMatch([IO.File]::ReadAllText($certTimeFile.FullName),$certTimeHighConfidence)){throw ('high-confidence credential candidate; stop without printing content: '+$certTimeName)}
 }
}
$certTimeCaptured=[DateTime]::UtcNow.ToString('o')
$certTimeEntries=@()
$certTimeZipStream=[IO.File]::Open($certTimeArchive,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try {
 $certTimeZip=[IO.Compression.ZipArchive]::new($certTimeZipStream,[IO.Compression.ZipArchiveMode]::Create,$true)
 try {
  foreach($certTimeName in $certTimeNames) {
   $certTimeFile=$certTimeMap[$certTimeName]
   $certTimeOriginalHash=(Get-FileHash -LiteralPath $certTimeFile.FullName -Algorithm SHA256).Hash
   $certTimeEntry=$certTimeZip.CreateEntry($certTimeName,[IO.Compression.CompressionLevel]::Optimal)
   $certTimeOut=$certTimeEntry.Open()
   $certTimeIn=[IO.File]::OpenRead($certTimeFile.FullName)
   try{$certTimeIn.CopyTo($certTimeOut)}finally{$certTimeIn.Dispose();$certTimeOut.Dispose()}
   $certTimeEntries+=[pscustomobject]@{Path=$certTimeName;Length=$certTimeFile.Length;SHA256=$certTimeOriginalHash}
  }
 }finally{$certTimeZip.Dispose()}
}finally{$certTimeZipStream.Dispose()}
$certTimeVerify=[IO.Compression.ZipFile]::OpenRead($certTimeArchive)
try {
 if($certTimeVerify.Entries.Count -ne $certTimeEntries.Count){throw 'archive entry count mismatch'}
 foreach($certTimeExpected in $certTimeEntries) {
  $certTimeEntry=$certTimeVerify.GetEntry($certTimeExpected.Path)
  if($null -eq $certTimeEntry -or $certTimeEntry.Length -ne $certTimeExpected.Length){throw 'archive entry missing/length mismatch'}
  $certTimeStream=$certTimeEntry.Open()
  $certTimeSHA=[Security.Cryptography.SHA256]::Create()
  try{$certTimeActual=[Convert]::ToHexString($certTimeSHA.ComputeHash($certTimeStream))}finally{$certTimeSHA.Dispose();$certTimeStream.Dispose()}
  if($certTimeActual -ne $certTimeExpected.SHA256){throw 'archive entry hash mismatch'}
  $certTimeSource=$certTimeMap[$certTimeExpected.Path]
  if((Get-FileHash -LiteralPath $certTimeSource.FullName -Algorithm SHA256).Hash -ne $certTimeExpected.SHA256){throw 'evidence changed while archiving'}
 }
}finally{$certTimeVerify.Dispose()}
$certTimeArchiveHash=(Get-FileHash -LiteralPath $certTimeArchive -Algorithm SHA256).Hash
$certTimeArchiveLength=(Get-Item -LiteralPath $certTimeArchive).Length
$certTimeManifestObject=[pscustomobject]@{SchemaVersion=1;Plan='docs/superpowers/plans/2026-10-12-node-certificate-time-binding.md';CapturedUTC=$certTimeCaptured;EvidenceRoot='.superpowers/sdd/2026-10-12-node-certificate-time-binding';Archive='docs/roadmap/checkpoints/2026-10-12-nodecerttime-evidence.zip';ArchiveSHA256=$certTimeArchiveHash;ArchiveLength=$certTimeArchiveLength;EntryCount=$certTimeEntries.Count;Excluded=@('go-cache/**','dependencies','credentials','databases/Docker state','other plans scratch','chat history','post-archive stage/commit/push receipts');HighConfidenceCredentialScan=@{ScannedTextCount=$certTimeSecretScanCount;Findings=0;FormalProof=$false};Entries=$certTimeEntries}
$certTimeManifestBytes=[Text.UTF8Encoding]::new($false).GetBytes(($certTimeManifestObject | ConvertTo-Json -Depth 8)+[Environment]::NewLine)
$certTimeManifestStream=[IO.File]::Open($certTimeManifest,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
try{$certTimeManifestStream.Write($certTimeManifestBytes)}finally{$certTimeManifestStream.Dispose()}
[pscustomobject]@{CapturedUTC=$certTimeCaptured;EntryCount=$certTimeEntries.Count;ArchiveLength=$certTimeArchiveLength;ArchiveSHA256=$certTimeArchiveHash;ManifestSHA256=(Get-FileHash -LiteralPath $certTimeManifest -Algorithm SHA256).Hash;AllEntriesVerified=$true;HighConfidenceCredentialScanCount=$certTimeSecretScanCount;CredentialFindings=0} | ConvertTo-Json -Depth 4


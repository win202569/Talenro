# Task 3 brief

BASE: f5d731bef9d767d57ca32f0f4c3a0f532a4bc322

Approved plan/spec binding; no Git writes; complete owned interfaces from Tasks 1–2 available.

### Task 3: 固定真实签名材料、两次 lower 判定及同快照绑定

**Files:** Create `lower.go`、`binding.go`；Test `fixtures_test.go`、`lower_test.go`、`binding_test.go`。一次性生成/独立核对源码仅放专属忽略证据目录，不进新包 inventory；旧 fixture/testdata 不改。

**Interfaces:**
- Consumes: Task 2 `owner`、owned/clear 接口；`nodeissuer.Evaluate(context.Context, nodeissuer.Input) (*nodeissuer.Material, error)`、`statetimebinding.Evaluate(context.Context, statetimebinding.Input) (*statetimebinding.Model, error)`，以及它们的 Summary/Clear。
- Produces: `stageError(context.Context, error) error`、`evaluateLower(context.Context, *owner) error`、`checkLowerProofs(Summary) error`、`bindSnapshots(context.Context, Input, Summary) error`。
- Produces test-only: `certTimeFixture(testing.TB, string) Input` 从固定完整 Input 常量解码独立值；`assertCertTimeLowerControls(testing.TB, Input) Summary` 实际调用两下层、立即 defer Clear 后返回独立摘要。`certTimeFixture` 的名字列表与逐份 raw/摘要 hash manifest 一并冻结，不随机签发。

- [ ] **Step 1: 生成并独立核对冻结材料，建立真实 lower 正控制。** 参考 statetimebinding/fixtures_test.go 的 compositionFixture/declarationFor/policyBindingFixture/attachTime 签名与引用关系，但在专属生成器构建自洽新材料，不调用其他包私有测试函数。基础 node=`12345678-1234-4234-8234-123456789abc`、TrustDomain=`node.test`、authority epoch=19、Now=`2020-01-01T01:00:00Z`；基础 CA=`2019-01-01T00:00:00Z` 至 `2030-01-01T00:00:00Z`，leaf=`2020-01-01T00:55:00Z` 至 `2020-01-02T00:55:00Z`，time attestation=`01:00:00Z` 至 `01:05:00Z`。

基础选择既有一段历史 root rotation（Old.Roots 两项、Target.Links 一项），
但 Main.RootTransition 为空、完整旧新 Root/Metadata 相同；另冻结 0/32 段
既有历史正控制，确保非空 Links 的真实摘要隔离也被动态测试。
使用固定测试 P-256 标量 1/2（CA/leaf），Ed25519 root seed 为 32 个 0x01、
metadata/time signer seed 为 32 个 0x02；这些只用于生成测试材料。签名可在
一次性生成阶段产生后冻结，不把生产钥匙/生成器或随机重签放进普通测试。
生成器自行计算并冻结 exact DER、SPKI、TBS 和 JSON/JCS transcript 的摘要，
独立核对者重新检查字节、签名、references/Expected/Old/Main 坐标及所有 raw
hash；共享同一摘要函数输出不称独立核对。普通测试仅解码冻结材料并做
明确的输入 mutation，不重新签名。test-only 可用 JSON/crypto/hash/reflect；
产品及新测试都不直接 import 规格禁止新增例外的七包。

冻结病例包括基础、另一节点（全部时间/desired/声明自洽）、CA/leaf 端点
前后 1ns 六点各自可成立的时间证据、两种双窗故障、三者最早和并列、
leaf 跨 CA 全窗但 Now 同时有效、CA year-1 起点与 leaf year-1 起点的真实
issuer 正控制、坏签名/nonce/metadata、rollback/缺失观测/PolicyFailure。
每个 joint window 病例的 attestation 在三点 Now 下都有效；所需 metadata/key/
desired/window/floor 随病例自洽冻结，不拿过期 time attestation 冒充新窗错误。
year-1 的 issuer-only 控制不冒称完整时间组合已接受。`TestCertTimeFixtureControls`
逐例证明标明应通过的真实 lower，并核对 manifest；fixture 不成立先修 fixture。

- [ ] **Step 2: 写 lower/snapshot 失败测试并运行取得 RED。** `TestCertTimeLowerErrorIdentity` 对同一坏输入分别取得真实下层错误再调用 evaluateLower，断言 sentinel `got==want`；PolicyFailure 用 errors.As 核对同型 Code/Reason/unwrap 链，不要求两次独立调用分配的 error 指针相等。`TestCertTimeStageError` 固定 nil context、Canceled/DeadlineExceeded 优先与正常原错误透传。`TestCertTimeCrossNodeControls` 先取得真实两 lower 成功摘要，然后：

```go
if got := bindSnapshots(context.Background(), crossNodeInput, checkedSummary); got != ErrBindingMismatch { t.Fatal(got) }
// TestCertTimeSnapshotRelations：逐改证书摘要 node、time node、输入三组 node/Main 两 Scope。
// 逐改 ProviderID/ObservationID/Now(1ns)/ObservedFloor，对应关系恰 ErrBindingMismatch。
// TestCertTimeLowerProofs：错误 issuer.Proof 或 time.Status -> ErrInvalidEvidence。
// TestCertTimeTimeTupleLowerControls：输入 tuple 不一致时真实 timebinding 自身拒绝。
```

Run: `& $certTimeGo test ./internal/nodecontrol/nodecerttime -run '^TestCertTime(FixtureControls|Lower.*|StageError|CrossNodeControls|SnapshotRelations|TimeTupleLowerControls)$' -count=1 -p=1 -timeout=120s`；预期尚缺新接口或新绑定断言失败，FixtureControls 本身必须通过才归类行为 RED。

- [ ] **Step 3: 实现 lower.go 的四个接口中前三个。** `evaluateLower` 输入只能是已保护 owner：真实 issuer 调用后立即 defer Clear，再 context/error、非 nil 检查、写 owner.summary.Certificate；真实 timebinding 调用后同样立即 defer Clear，再 context/error、非 nil 检查，**直接** `o.summary.Time = timeModel.Summary()`，然后检查恰有旧 Proof/Status。禁止临时未保护可变 Time 摘要、替换函数/别名/回调和其他下层入口。此步骤不设置 o.valid 或新 Proof。

- [ ] **Step 4: 在 binding.go 实现 bindSnapshots。** 等式逐项按规格 §6：Certificate.Leaf.Leaf.NodeID=owned Certificate.Leaf.NodeID=Time.Time.NodeID；time node 对应 Metadata/Request/Checkpoint.NodeID 和 Main 两 Scope 的 canonical UUID.String。Time.Policy.Time 的 ProviderID/ObservationID/Now/ObservedFloor 对应 Time.Time.Time 与 Policy.Policy.Time 的 tuple；time.Time 均已规范，用值相等保留 ns。其他字段只沿用真实下层，不新增域=metadata、provider=CA digest、epoch 签入证书等判断。

- [ ] **Step 5: 重跑 Step 2 取得 GREEN。** 全部 PASS/exit 0；真实 lower 错误与新 snapshot helper 人为摘要 mutation 控制分别标明，不把 caller-built Summary 视为公开输入或产品信任路径。



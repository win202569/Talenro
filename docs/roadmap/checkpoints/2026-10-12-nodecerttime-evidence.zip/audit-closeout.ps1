param([switch]$RequireCompletedPlan)
$ErrorActionPreference='Stop'
$certTimeRoot='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
Set-Location -LiteralPath $certTimeRoot
$env:GIT_OPTIONAL_LOCKS='0'
$certTimeEvidence=Join-Path $certTimeRoot '.superpowers/sdd/2026-10-12-node-certificate-time-binding'
function Assert-CertTime([bool]$condition,[string]$message) { if(!$condition) { throw $message } }
function Get-CertTimeHashLines($entries) {
 @($entries | ForEach-Object { ($_.Path -replace '\\','/')+' '+$_.SHA256 } | Sort-Object)
}
function Get-CertTimeGit([string[]]$arguments) {
 $certTimeOutput=@(& git -c core.fsmonitor=false @arguments)
 $certTimeCode=$LASTEXITCODE
 Assert-CertTime ($certTimeCode -eq 0) ('readonly Git failed: '+($arguments -join ' '))
 [pscustomobject]@{Arguments=$arguments;ExitCode=$certTimeCode;Output=$certTimeOutput}
}
$certTimeCurrent=@(rg --files internal/nodecontrol -g '*.go' | Where-Object { $_ -notmatch '[\\/]testdata[\\/]' } | Sort-Object | ForEach-Object { [pscustomobject]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash} })
$certTimeCurrentLines=Get-CertTimeHashLines $certTimeCurrent
Assert-CertTime ($certTimeCurrent.Count -eq 377) 'current source count drift'
$certTimeAudit=Get-Content -LiteralPath (Join-Path $certTimeEvidence 'evidence-audit.json') -Raw | ConvertFrom-Json
Assert-CertTime ($certTimeAudit.Matrix.Count -eq 23) 'matrix count drift'
$certTimeMatrix=@()
foreach($certTimeEntry in $certTimeAudit.Matrix) {
 $certTimeRun=Get-Content -LiteralPath (Join-Path $certTimeEvidence ($certTimeEntry.RunId+'.json')) -Raw | ConvertFrom-Json
 $certTimeBefore=Get-CertTimeHashLines $certTimeRun.SourceBefore
 $certTimeAfter=Get-CertTimeHashLines $certTimeRun.SourceAfter
 $certTimeMatch=(@(Compare-Object $certTimeCurrentLines $certTimeBefore).Count -eq 0 -and @(Compare-Object $certTimeCurrentLines $certTimeAfter).Count -eq 0)
 Assert-CertTime ($certTimeRun.ExitCode -eq 0 -and $certTimeMatch) ('matrix source/exit mismatch '+$certTimeEntry.RunId)
 $certTimeMatrix+=[pscustomobject]@{RunId=$certTimeEntry.RunId;ExitCode=$certTimeRun.ExitCode;MatchesCurrentSource=$certTimeMatch}
}
$certTimeDone=Get-Content -LiteralPath (Join-Path $certTimeEvidence '073-task5-done.json') -Raw | ConvertFrom-Json
Assert-CertTime ($certTimeDone.ExitCode -eq 0) 'task-done failed'
Assert-CertTime (@(Compare-Object $certTimeCurrentLines (Get-CertTimeHashLines $certTimeDone.SourceBefore)).Count -eq 0) 'task-done before drift'
Assert-CertTime (@(Compare-Object $certTimeCurrentLines (Get-CertTimeHashLines $certTimeDone.SourceAfter)).Count -eq 0) 'task-done after drift'
$certTimeFormat=Get-Content -LiteralPath (Join-Path $certTimeEvidence '048-format.json') -Raw | ConvertFrom-Json
Assert-CertTime ($certTimeFormat.ExitCode -eq 0 -and $certTimeFormat.Clean -and $certTimeFormat.SourceAfter.Count -eq 43) 'format record mismatch'
$certTimeCurrentMap=@{}
foreach($certTimeSource in $certTimeCurrent) { $certTimeCurrentMap[($certTimeSource.Path -replace '\\','/')]=$certTimeSource.SHA256 }
foreach($certTimeSource in @($certTimeFormat.SourceBefore)+@($certTimeFormat.SourceAfter)) { Assert-CertTime ($certTimeCurrentMap[($certTimeSource.Path -replace '\\','/')] -eq $certTimeSource.SHA256) 'format source drift' }
$certTimeExpectedFiles=@('doc.go','input.go','errors.go','budget.go','owner.go','owned_certificate.go','owned_binding.go','owned_content.go','owned_table.go','owned_policy.go','owned_time.go','owned_summary.go','model.go','lower.go','binding.go','window.go','evaluate.go','input_test.go','budget_test.go','owned_certificate_test.go','owned_binding_test.go','owned_content_test.go','owned_table_test.go','owned_policy_test.go','owned_time_test.go','owned_summary_test.go','model_test.go','fixtures_test.go','lower_test.go','binding_test.go','window_test.go','evaluate_test.go','boundary_test.go','ownership_boundary_test.go','consumer_boundary_test.go')
$certTimeNewFiles=@(rg --files internal/nodecontrol/nodecerttime | ForEach-Object { $_ -replace '^internal[\\/]nodecontrol[\\/]nodecerttime[\\/]','' })
Assert-CertTime (@(Compare-Object $certTimeExpectedFiles $certTimeNewFiles).Count -eq 0) 'exact35 inventory mismatch'
$certTimeHashTargets=@(
 [pscustomobject]@{Path='docs/superpowers/specs/2026-10-12-node-certificate-time-binding-design.md';Expected='595A4471C642727AE60D8C816BDEDAA65FD3B9F21EF812B503CDD12F91CE694B'},
 [pscustomobject]@{Path='D:/Projects/Talenro/.git/worktrees/c12-b01-task9-coordinator/index';Expected='15ADFA44B16BB2020BE7623FC44CC334F2B50D88AA2D9341152A7421C2312DE1'},
 [pscustomobject]@{Path='D:/Projects/Talenro/.git/config';Expected='D6886A65FF6AD1EF560A526C23D99203DBC652BDA14A19E1CCD3EC603983285D'}
)
$certTimeHashResults=@()
foreach($certTimeTarget in $certTimeHashTargets) {
 $certTimeHash=(Get-FileHash -LiteralPath $certTimeTarget.Path -Algorithm SHA256).Hash
 Assert-CertTime ($certTimeHash -eq $certTimeTarget.Expected) ('preservation mismatch '+$certTimeTarget.Path)
 $certTimeHashResults+=[pscustomobject]@{Path=$certTimeTarget.Path;SHA256=$certTimeHash;Unchanged=$true}
}
$certTimeHead=Get-CertTimeGit @('rev-parse','HEAD')
$certTimeBranch=Get-CertTimeGit @('branch','--show-current')
Assert-CertTime ($certTimeHead.Output[0] -eq 'f5d731bef9d767d57ca32f0f4c3a0f532a4bc322') 'HEAD drift'
Assert-CertTime ($certTimeBranch.Output[0] -eq 'codex/c12-b01-task9-coordinator') 'branch drift'
$certTimeStatus=Get-CertTimeGit @('status','--porcelain=v1','--untracked-files=all')
$certTimeExpectedChanges=@(
 ' M docs/roadmap/current-status.md',
 '?? docs/roadmap/2026-10-12-node-certificate-time-binding-execution.md',
 '?? docs/superpowers/plans/2026-10-12-node-certificate-time-binding.md',
 '?? docs/superpowers/specs/2026-10-12-node-certificate-time-binding-design.md'
)
$certTimeExpectedChanges+=@('nodeissuer','statetimebinding','statepolicybinding','statebinding','statecontract','statematerials','statepolicy','stateverify') | ForEach-Object { ' M internal/nodecontrol/'+$_+'/boundary_test.go' }
$certTimeExpectedChanges+=$certTimeExpectedFiles | ForEach-Object { '?? internal/nodecontrol/nodecerttime/'+$_ }
Assert-CertTime (@(Compare-Object $certTimeExpectedChanges $certTimeStatus.Output).Count -eq 0) 'Git status scope mismatch'
$certTimeDiffCheck=Get-CertTimeGit @('diff','--check')
$certTimeStaged=Get-CertTimeGit @('diff','--exit-code','--cached')
$certTimeProgress=Get-Content -LiteralPath (Join-Path $certTimeEvidence 'progress.md') -Raw
$certTimeRulings=@($certTimeProgress -split '\r?\n' | Where-Object { $_ -match '^(Ruling:|Final: Ruling:)' })
Assert-CertTime ($certTimeRulings.Count -eq 25) 'ruling count mismatch'
$certTimeExecution=Get-Content -LiteralPath 'docs/roadmap/2026-10-12-node-certificate-time-binding-execution.md' -Raw
foreach($certTimeRuling in $certTimeRulings) { Assert-CertTime ($certTimeExecution.Contains($certTimeRuling)) 'execution ruling omitted' }
$certTimeReview=Get-Content -LiteralPath (Join-Path $certTimeEvidence 'final-review.md') -Raw
$certTimeDeclined=$certTimeReview.Split('## Declined to judge')[1].Split('## Scoped assessment')[0]
Assert-CertTime ([regex]::Matches($certTimeDeclined,'(?m)^- \*\*').Count -eq 22) 'declined-to-judge count mismatch'
Assert-CertTime (@($certTimeProgress -split '\r?\n' | Where-Object { $_ -match '^Final: minor \(deferred\):' }).Count -eq 1) 'minor count mismatch'
$certTimePlan=Get-Content -LiteralPath 'docs/superpowers/plans/2026-10-12-node-certificate-time-binding.md' -Raw
$certTimeRemaining=[regex]::Matches($certTimePlan,'(?m)^- \[ \] \*\*Step').Count
if($RequireCompletedPlan) {
 Assert-CertTime ($certTimeRemaining -eq 0) 'plan steps not complete'
 Assert-CertTime ($certTimeProgress -match '(?m)^- \[x\] Task 5: complete') 'task5 ledger not complete'
 Assert-CertTime ($certTimeProgress -match '(?m)^Task 5: complete \(BASE/HEAD unchanged') 'task5 completion receipt not ledgered'
}
$certTimeIncomplete=@(Get-ChildItem -LiteralPath $certTimeEvidence -File -Filter '*.started.json' | Where-Object { !(Test-Path -LiteralPath ($_.FullName -replace '\.started\.json$','.json')) })
Assert-CertTime ($certTimeIncomplete.Count -eq 0) 'incomplete Go execution'
$certTimeReceipts=@(Get-ChildItem -LiteralPath $certTimeEvidence -File -Filter '*.json' | Where-Object { $_.Name -match '^[0-9]{3}-.+\.json$' -and $_.Name -notlike '*.started.json' })
Assert-CertTime ($certTimeReceipts.Count -eq 73) 'numbered receipt count mismatch'
$certTimeDocHashes=@('docs/superpowers/plans/2026-10-12-node-certificate-time-binding.md','docs/roadmap/current-status.md','docs/roadmap/2026-10-12-node-certificate-time-binding-execution.md','.superpowers/sdd/2026-10-12-node-certificate-time-binding/progress.md','.superpowers/sdd/2026-10-12-node-certificate-time-binding/final-review.md') | ForEach-Object { [pscustomobject]@{Path=$_;SHA256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash} }
[pscustomobject]@{
 CheckedUTC=[DateTime]::UtcNow.ToString('o');RequireCompletedPlan=[bool]$RequireCompletedPlan;CurrentNodecontrolGoCount=$certTimeCurrent.Count;NewProductCount=17;NewTestCount=18;FormatPathCount=43;FinalMatrix=$certTimeMatrix;TaskDone=@{RunId=$certTimeDone.RunId;ExitCode=$certTimeDone.ExitCode;MatchesCurrentSource=$true};PreservedHashes=$certTimeHashResults;Head=$certTimeHead;Branch=$certTimeBranch;GitStatus=$certTimeStatus;DiffCheck=$certTimeDiffCheck;StagedDiff=$certTimeStaged;RulingCount=25;ReviewDeclinedCount=22;DeferredMinorCount=1;RemainingPlanStepCount=$certTimeRemaining;NumberedReceiptCount=$certTimeReceipts.Count;GoReceiptCount=72;IncompleteGoCount=$certTimeIncomplete.Count;AuthorDocHashes=$certTimeDocHashes
} | ConvertTo-Json -Depth 8


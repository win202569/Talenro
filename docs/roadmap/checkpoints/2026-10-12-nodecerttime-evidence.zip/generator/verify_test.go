package certtimegeneration

import (
 "bytes"
 "context"
 "crypto/ed25519"
 "crypto/sha256"
 "crypto/x509"
 "encoding/base64"
 "encoding/hex"
 "encoding/json"
 "os"
 "path/filepath"
 "reflect"
 "strings"
 "testing"
 "talenro.local/platform/internal/nodecontrol/nodeissuer"
 "talenro.local/platform/internal/nodecontrol/statetimebinding"
 "talenro.local/platform/internal/nodecontrol/statematerials"
 "errors"
 "github.com/gowebpki/jcs"
)

type Manifest struct { Input string; Raw map[string]string; Certificate,Time string; CertificateError,TimeError string }
func independentHash(raw []byte) string { d:=sha256.Sum256(raw);return hex.EncodeToString(d[:]) }
func independentRaw(v reflect.Value, path string, out map[string]string) {
 if v.Kind()==reflect.Pointer {if !v.IsNil(){independentRaw(v.Elem(),path,out)};return}
 if v.Kind()==reflect.Struct {for i:=0;i<v.NumField();i++ {independentRaw(v.Field(i),path+"."+v.Type().Field(i).Name,out)};return}
 if v.Kind()==reflect.Slice {
  if v.Type().Elem().Kind()==reflect.Uint8 {out[path]=independentHash(v.Bytes());return}
  for i:=0;i<v.Len();i++ {independentRaw(v.Index(i),path+"["+fmtIndex(i)+"]",out)}
 }
}
func fmtIndex(i int) string { if i<10{return string(rune('0'+i))};return string(rune('0'+i/10))+string(rune('0'+i%10)) }
func independentEnvelope(t *testing.T, raw []byte, root bool) {
 t.Helper()
 var env struct {Payload string `json:"payload_b64url"`;Digest string `json:"payload_sha256"`;KeyID string `json:"key_id"`;Signature string `json:"signature"`;Current,New,Signatures []struct {KeyID string `json:"key_id"`;Signature string `json:"signature"`}}
 var keys map[string]json.RawMessage
 if e:=json.Unmarshal(raw,&keys);e!=nil{t.Fatal(e)}
 if _,ok:=keys["payload_b64url"];!ok{return}
 if e:=json.Unmarshal(raw,&env);e!=nil{t.Fatal(e)}
 p,e:=base64.RawURLEncoding.DecodeString(env.Payload);if e!=nil || independentHash(p)!=env.Digest{t.Fatal("payload bytes/hash")}
 var payload struct{Schema string `json:"schema_version"`}
 if e=json.Unmarshal(p,&payload);e!=nil{t.Fatal(e)}
 canonical,e:=jcs.Transform(p);if e!=nil||!bytes.Equal(canonical,p){t.Fatal("independent JCS payload")}
 canonical,e=jcs.Transform(raw);if e!=nil||!bytes.Equal(canonical,raw){t.Fatal("independent JCS envelope")}
 domain:=""
 switch payload.Schema {case "node-state-root-set.v1":return;case "node-state-root-rotation.v1":domain="TALENRO-NODE-STATE-ROOT-ROTATION-V1";case "node-state-trust-metadata.v1":domain="TALENRO-NODE-STATE-METADATA-V1";case "node-desired-state.v1":domain="TALENRO-NODE-DESIRED-STATE-V1";case "node-time-attestation.v1":domain="TALENRO-NODE-TIME-ATTESTATION-V1";default:t.Fatal("unknown schema",payload.Schema)}
 seed:=bytes.Repeat([]byte{2},32);if root{seed=bytes.Repeat([]byte{1},32)}
 pub:=ed25519.NewKeyFromSeed(seed).Public().(ed25519.PublicKey)
 verify:=func(id,s string){b,e:=base64.RawURLEncoding.DecodeString(s);if e!=nil || id!=independentHash(pub)||!ed25519.Verify(pub,append([]byte(domain+"\x00"),p...),b){t.Fatal("independent Ed25519 transcript/signature")}}
 if env.Signature!="" {verify(env.KeyID,env.Signature)}
 for _,k:=range []string{"current_signatures","new_signatures","signatures"} {
  if b:=keys[k];len(b)>0 {var shares []struct {KeyID string `json:"key_id"`;Signature string `json:"signature"`};if e=json.Unmarshal(b,&shares);e!=nil{t.Fatal(e)};for _,s:=range shares{verify(s.KeyID,s.Signature)}}
 }
}
func TestVerifyFrozenCertTime(t *testing.T) {
 raw,e:=os.ReadFile(filepath.Join(root,".superpowers/sdd/2026-10-12-node-certificate-time-binding/frozen-inputs.json"));if e!=nil{t.Fatal(e)}
 var packets map[string]Packet;if e=json.Unmarshal(raw,&packets);e!=nil{t.Fatal(e)}
 manifest:=map[string]Manifest{}
 for name,in:=range packets {t.Run(name,func(t *testing.T){
  ca,e:=x509.ParseCertificate(in.Certificate.CA.DER);if e!=nil{t.Fatal(e)}
  leaf,e:=x509.ParseCertificate(in.Certificate.Leaf.DER);if e!=nil{t.Fatal(e)}
  if !bytes.Equal(ca.RawSubjectPublicKeyInfo,in.Certificate.CA.DeclaredSPKI)||!bytes.Equal(leaf.RawSubjectPublicKeyInfo,in.Certificate.Leaf.ExpectedSPKI){t.Fatal("SPKI")}
  sig:=ca.CheckSignature(leaf.SignatureAlgorithm,leaf.RawTBSCertificate,leaf.Signature)
  if (sig!=nil)!=(name=="bad-signature"){t.Fatal("independent certificate signature",sig)}
  if len(leaf.SubjectKeyId)!=32 || independentHash(leaf.RawSubjectPublicKeyInfo)!=hex.EncodeToString(leaf.SubjectKeyId)||!bytes.Equal(leaf.AuthorityKeyId,ca.SubjectKeyId)||independentHash(ca.RawSubjectPublicKeyInfo)!=hex.EncodeToString(ca.SubjectKeyId){t.Fatal("exact key identifiers")}
  for _,table:=range [][]byte{in.Time.Policy.Policy.Batch.AnchorEnvelope,in.Time.Policy.Policy.Batch.ActiveRootEnvelope,in.Time.Policy.Policy.Batch.MetadataEnvelope,in.Time.Policy.Policy.Batch.DesiredEnvelope,in.Time.Time.AttestationEnvelope} {
   var env map[string]any;if e=json.Unmarshal(table,&env);e!=nil{t.Fatal(e)}
   var payload struct{Schema string `json:"schema_version"`};p,_:=base64.RawURLEncoding.DecodeString(env["payload_b64url"].(string));json.Unmarshal(p,&payload)
   independentEnvelope(t,table,strings.Contains(payload.Schema,"root-")||strings.Contains(payload.Schema,"metadata"))
  }
  b,_:=json.Marshal(in);m:=Manifest{Input:independentHash(b),Raw:map[string]string{}}
  independentRaw(reflect.ValueOf(in),"Input",m.Raw)
  for _,table:=range []struct{name string;rows []statematerials.Material}{
   {"Previous",in.Time.Policy.Binding.Previous.Materials},{"Proposed",in.Time.Policy.Binding.Proposed.Materials.Materials},
  }{for i,row:=range table.rows{
   pr:=row.Raw;var env map[string]any
   if e:=json.Unmarshal(pr,&env);e!=nil{t.Fatal(e)}
   if p,ok:=env["payload_b64url"].(string);ok{pr,e=base64.RawURLEncoding.DecodeString(p);if e!=nil{t.Fatal(e)};if independentHash(row.Raw)!=hex.EncodeToString(row.Ref.Envelope[:]){t.Fatal("independent envelope reference")}}
   if independentHash(pr)!=hex.EncodeToString(row.Ref.Payload[:]){t.Fatal("independent payload reference")}
   m.Raw[table.name+"["+fmtIndex(i)+"].Payload"]=independentHash(pr)
  }}
  m.Raw["Certificate.Leaf.TBS"]=independentHash(leaf.RawTBSCertificate)
  m.Raw["Certificate.CA.TBS"]=independentHash(ca.RawTBSCertificate)
  cm,ce:=nodeissuer.Evaluate(context.Background(),in.Certificate);if cm!=nil{defer cm.Clear()}
  tm,te:=statetimebinding.Evaluate(context.Background(),in.Time);if tm!=nil{defer tm.Clear()}
  if ce!=nil {m.CertificateError=ce.Error()}else {s:=cm.Summary();b,_:=json.Marshal(s);m.Certificate=independentHash(b);if s.Proof!=nodeissuer.NodeLeafDirectIssuerSignatureBound{t.Fatal("issuer proof")}}
  if te!=nil {m.TimeError=te.Error()}else{s:=tm.Summary();b,_:=json.Marshal(s);m.Time=independentHash(b);if s.Status!=statetimebinding.ConditionalTimeEvidenceBound{t.Fatal("time proof")}}
  certBad:=name=="bad-signature";timeBad:=name=="bad-nonce"||name=="bad-metadata"||name=="rollback"||name=="missing-observation"||name=="policy-failure"
  if (ce!=nil)!=certBad || (te!=nil)!=timeBad{t.Fatal("fixture control",ce,te)}
  if name=="policy-failure" {var f *statetimebinding.PolicyFailure;if !errors.As(te,&f){t.Fatal("not typed PolicyFailure",te)}}
  manifest[name]=m
 })}
 b,e:=json.Marshal(manifest);if e!=nil{t.Fatal(e)};if e=os.WriteFile(filepath.Join(root,".superpowers/sdd/2026-10-12-node-certificate-time-binding/frozen-manifest.json"),b,0600);e!=nil{t.Fatal(e)}
}

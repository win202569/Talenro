package certtimegeneration

import (
	"context"
	"crypto/ed25519"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"compress/gzip"
	"math/big"
	"net/url"
	"path/filepath"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"github.com/google/uuid"
	"github.com/gowebpki/jcs"
	"os"
	"strconv"
	"talenro.local/platform/internal/nodecontrol/contracts"
	"talenro.local/platform/internal/nodecontrol/statebinding"
	"talenro.local/platform/internal/nodecontrol/statecomposition"
	"talenro.local/platform/internal/nodecontrol/statecontract"
	"talenro.local/platform/internal/nodecontrol/stateformat"
	"talenro.local/platform/internal/nodecontrol/statematerials"
	"talenro.local/platform/internal/nodecontrol/statepolicy"
	"talenro.local/platform/internal/nodecontrol/statepolicybinding"
	"talenro.local/platform/internal/nodecontrol/statetime"
	"testing"
	"talenro.local/platform/internal/nodecontrol/nodeissuer"
	"talenro.local/platform/internal/nodecontrol/statetimebinding"
	"time"
)

func baseFrozen(t *testing.T, name string) []byte {
	t.Helper()
	raw, e := os.ReadFile(filepath.Join(root, "internal/nodecontrol/stateverify/testdata", name))
	if e != nil {
		t.Fatal(e)
	}
	return raw
}
func object(t *testing.T, raw []byte) map[string]any {
	t.Helper()
	var o map[string]any
	if e := json.Unmarshal(raw, &o); e != nil {
		t.Fatal(e)
	}
	return o
}
func encode(t *testing.T, o any) []byte {
	t.Helper()
	raw, e := json.Marshal(o)
	if e != nil {
		t.Fatal(e)
	}
	return raw
}
func payload(t *testing.T, raw []byte) []byte {
	t.Helper()
	o := object(t, raw)
	p, e := base64.RawURLEncoding.DecodeString(o["payload_b64url"].(string))
	if e != nil {
		t.Fatal(e)
	}
	return p
}
func digest(t *testing.T, s string) (d contracts.Digest) {
	t.Helper()
	b, e := hex.DecodeString(s)
	if e != nil || len(b) != 32 {
		t.Fatal("digest")
	}
	copy(d[:], b)
	return
}
func number(t *testing.T, o map[string]any, k string) uint64 {
	t.Helper()
	n, e := strconv.ParseUint(o[k].(string), 10, 64)
	if e != nil {
		t.Fatal(e)
	}
	return n
}
func window(t *testing.T, o map[string]any) statematerials.Window {
	t.Helper()
	a, e := time.Parse(time.RFC3339, o["issued_at"].(string))
	if e != nil {
		t.Fatal(e)
	}
	b, e := time.Parse(time.RFC3339, o["valid_until"].(string))
	if e != nil {
		t.Fatal(e)
	}
	return statematerials.Window{Issued: a.Unix(), Until: b.Unix()}
}
func private(n byte) ed25519.PrivateKey {
	seed := make([]byte, 32)
	for i := range seed { seed[i] = n }
	return ed25519.NewKeyFromSeed(seed)
}
func wireKey(n byte) map[string]any {
	p := private(n).Public().(ed25519.PublicKey)
	id := sha256.Sum256(p)
	return map[string]any{"algorithm": "ed25519", "key_id": hex.EncodeToString(id[:]), "public_key": base64.RawURLEncoding.EncodeToString(p)}
}
func mint(t *testing.T, name string, p map[string]any, key ed25519.PrivateKey) []byte {
	t.Helper()
	raw := encode(t, p)
	pd := sha256.Sum256(raw)
	e := object(t, baseFrozen(t, name+".envelope.json"))
	e["payload_b64url"] = base64.RawURLEncoding.EncodeToString(raw)
	e["payload_sha256"] = hex.EncodeToString(pd[:])
	if name != "desired" {
		e["control_plane_authority_epoch"] = p["control_plane_authority_epoch"]
		e["authority_sequence"] = p["authority_sequence"]
		e["root_version"] = p["root_version"]
	}
	if name == "rotation" {
		e["previous_root_version"] = p["previous_root_version"]
		e["root_version"] = p["new_root_set"].(map[string]any)["root_version"]
	}
	if name != "anchor" {
		domain := map[string]string{"rotation": "TALENRO-NODE-STATE-ROOT-ROTATION-V1", "metadata": "TALENRO-NODE-STATE-METADATA-V1", "desired": "TALENRO-NODE-DESIRED-STATE-V1"}[name]
		pub := key.Public().(ed25519.PublicKey)
		id := sha256.Sum256(pub)
		sig := ed25519.Sign(key, append([]byte(domain+"\x00"), raw...))
		share := map[string]any{"key_id": hex.EncodeToString(id[:]), "signature": base64.RawURLEncoding.EncodeToString(sig)}
		switch name {
		case "rotation":
			e["current_signatures"] = []any{share}
			e["new_signatures"] = []any{share}
		case "metadata":
			e["signatures"] = []any{share}
		case "desired":
			e["key_id"] = share["key_id"]
			e["signature"] = share["signature"]
		}
	}
	return encode(t, e)
}
func addRoot(t *testing.T, in *statecomposition.Input, raw []byte) statematerials.MaterialRef {
	t.Helper()
	p := object(t, raw)
	ref := statematerials.MaterialRef{Kind: statematerials.RootSet, Payload: sha256.Sum256(raw)}
	ids := []contracts.Digest{}
	for _, k := range p["keys"].([]any) {
		ids = append(ids, digest(t, k.(map[string]any)["key_id"].(string)))
	}
	in.Materials.Materials = append(in.Materials.Materials, statematerials.Material{Ref: ref, Raw: raw})
	in.Materials.Expected = append(in.Materials.Expected, statematerials.Expectation{Ref: ref, Epoch: number(t, p, "control_plane_authority_epoch"), Sequence: number(t, p, "authority_sequence"), Root: statematerials.RootExpectation{Version: number(t, p, "root_version"), Threshold: number(t, p, "threshold"), KeyIDs: ids}})
	return ref
}
func addEnvelope(t *testing.T, in *statecomposition.Input, kind statematerials.MaterialKind, raw []byte, old, newRoot, meta statematerials.MaterialRef) statematerials.MaterialRef {
	t.Helper()
	pr := payload(t, raw)
	p := object(t, pr)
	env := object(t, raw)
	ref := statematerials.MaterialRef{Kind: kind, Payload: sha256.Sum256(pr), Envelope: sha256.Sum256(raw)}
	e := statematerials.Expectation{Ref: ref, Epoch: number(t, p, "control_plane_authority_epoch"), Sequence: number(t, p, "authority_sequence")}
	switch kind {
	case statematerials.RootRotation:
		e.Rotation = statematerials.RotationExpectation{PreviousVersion: number(t, p, "previous_root_version"), NewVersion: number(t, p["new_root_set"].(map[string]any), "root_version"), OldRootPayload: old.Payload, NewRootPayload: newRoot.Payload, Window: window(t, p)}
	case statematerials.Metadata:
		ids := []contracts.Digest{}
		rev := []contracts.Digest{}
		for _, k := range p["keys"].([]any) {
			ids = append(ids, digest(t, k.(map[string]any)["key_id"].(string)))
		}
		for _, k := range p["revoked_key_ids"].([]any) {
			rev = append(rev, digest(t, k.(string)))
		}
		e.Metadata = statematerials.MetadataExpectation{Version: number(t, p, "metadata_version"), RootVersion: number(t, p, "root_version"), RootPayload: newRoot.Payload, KeyIDs: ids, RevokedIDs: rev, Window: window(t, p)}
	case statematerials.Desired:
		slots := []string{}
		for _, proc := range p["processes"].([]any) {
			slots = append(slots, proc.(map[string]any)["slot_id"].(string))
		}
		e.Desired = statematerials.DesiredExpectation{NodeID: p["node_id"].(string), Generation: number(t, p, "generation"), InventoryVersion: number(t, p, "inventory_version"), ResourceVersion: number(t, p, "node_resource_envelope_version"), ResourcePayload: digest(t, p["node_resource_envelope_digest"].(string)), RootPayload: newRoot.Payload, MetadataPayload: meta.Payload, SigningKeyID: digest(t, env["key_id"].(string)), Window: window(t, p), SlotIDs: slots}
	}
	in.Materials.Materials = append(in.Materials.Materials, statematerials.Material{Ref: ref, Raw: raw})
	in.Materials.Expected = append(in.Materials.Expected, e)
	return ref
}
func embedded(t *testing.T, raw []byte) []byte {
	t.Helper()
	var p struct {
		Root json.RawMessage `json:"new_root_set"`
	}
	if e := json.Unmarshal(payload(t, raw), &p); e != nil {
		t.Fatal(e)
	}
	return p.Root
}
func compositionFixture(t *testing.T, n int) statecomposition.Input {
	t.Helper()
	in := statecomposition.Input{Materials: statematerials.Input{Scope: statematerials.Scope{NodeID: fixtureNode, Epoch: 19}}}
	a := frozen(t, "anchor.envelope.json")
	in.Anchor = statecomposition.AnchorInput{Scope: in.Materials.Scope, Raw: a, Payload: sha256.Sum256(frozen(t, "anchor.payload.json")), Envelope: sha256.Sum256(a)}
	in.Target.AnchorRoot = addRoot(t, &in, frozen(t, "anchor.payload.json"))
	tail := in.Target.AnchorRoot
	for i := 0; i < n; i++ {
		raw := frozen(t, "rotation.envelope.json")
		if n != 1 {
			p := object(t, frozen(t, "rotation.payload.json"))
			p["authority_sequence"] = strconv.Itoa(i + 4)
			p["previous_root_version"] = strconv.Itoa(i + 1)
			r := p["new_root_set"].(map[string]any)
			r["root_version"] = strconv.Itoa(i + 2)
			r["authority_sequence"] = strconv.Itoa(i + 4)
			raw = mint(t, "rotation", p, private(1))
		}
		nr := addRoot(t, &in, embedded(t, raw))
		rr := addEnvelope(t, &in, statematerials.RootRotation, raw, tail, nr, statematerials.MaterialRef{})
		in.Target.Links = append(in.Target.Links, statecomposition.RotationLink{Rotation: rr, NewRoot: nr})
		tail = nr
	}
	raw := frozen(t, "metadata.envelope.json")
	if n != 1 {
		p := object(t, frozen(t, "metadata.payload.json"))
		p["root_version"] = strconv.Itoa(n + 1)
		raw = mint(t, "metadata", p, private(1))
	}
	in.Target.Metadata = addEnvelope(t, &in, statematerials.Metadata, raw, statematerials.MaterialRef{}, tail, statematerials.MaterialRef{})
	in.Target.Desired = addEnvelope(t, &in, statematerials.Desired, frozen(t, "desired.envelope.json"), statematerials.MaterialRef{}, tail, in.Target.Metadata)
	return in
}
func material(in *statecomposition.Input, ref statematerials.MaterialRef) *statematerials.Material {
	for i := range in.Materials.Materials {
		if in.Materials.Materials[i].Ref == ref {
			return &in.Materials.Materials[i]
		}
	}
	return nil
}
func expected(in *statecomposition.Input, ref statematerials.MaterialRef) *statematerials.Expectation {
	for i := range in.Materials.Expected {
		if in.Materials.Expected[i].Ref == ref {
			return &in.Materials.Expected[i]
		}
	}
	return nil
}
func tailRef(in statecomposition.Input) statematerials.MaterialRef {
	if len(in.Target.Links) == 0 {
		return in.Target.AnchorRoot
	}
	return in.Target.Links[len(in.Target.Links)-1].NewRoot
}
func d(n byte) contracts.Digest { return contracts.Digest{n} }
func declRef(k statecontract.ArtifactKind, n byte) statecontract.ArtifactRef {
	r := statecontract.ArtifactRef{Kind: k, Payload: d(n)}
	switch k {
	case statecontract.RootRotation, statecontract.Metadata, statecontract.TrustBundle, statecontract.ResourceEnvelope, statecontract.HostMemoryPolicy, statecontract.DesiredSnapshot, statecontract.RecoverySnapshot:
		r.Envelope = d(n + 1)
	}
	return r
}
func declarationFixture() statecontract.MainStateContentModel {
	h := func(d statecontract.Domain) statecontract.SectionHeader {
		return statecontract.SectionHeader{d, statecontract.Present}
	}
	mark := func(k statecontract.ArtifactKind, n byte) statecontract.StreamMark {
		return statecontract.StreamMark{1, 1, declRef(k, n)}
	}
	scope := statecontract.MainStateScope{NodeID: "12345678-1234-4234-8234-123456789abc", AuthorityEpoch: 1, DeploymentID: d(1), TrustAnchorID: d(2), DeploymentKeySetID: d(3), TimeProviderID: d(4), Main: statecontract.GuardBinding{d(5), d(6)}, Supervisor: statecontract.GuardBinding{d(7), d(8)}, Latch: statecontract.GuardBinding{d(9), d(10)}}
	desired := statecontract.DesiredBinding{1, 1, d(40)}
	bundle := func(p statecontract.BundlePurpose, n byte) statecontract.BundleRef {
		return statecontract.BundleRef{Purpose: p, TrustDomain: "example.test", AuthorityEpoch: 1, Mark: mark(statecontract.TrustBundle, n), DeploymentKeyID: d(11), DeauthorizedSetDigest: d(12)}
	}
	return statecontract.MainStateContentModel{
		ModelVersion: 1, Scope: scope,
		Checkpoint:  statecontract.CheckpointSection{h(statecontract.DomainCheckpoint), scope.NodeID, 1, 100},
		Root:        statecontract.RootSection{h(statecontract.DomainRoot), mark(statecontract.RootPayload, 20), 1, []contracts.Digest{d(1)}},
		Metadata:    statecontract.MetadataSection{h(statecontract.DomainMetadata), mark(statecontract.Metadata, 22), 1, d(20), []contracts.Digest{d(2)}, nil, d(23), declRef(statecontract.MetadataHistory, 24), statecontract.TimeWindow{0, 100}},
		Identity:    statecontract.IdentitySection{h(statecontract.DomainIdentity), 1, scope.NodeID, 200, d(1), d(2), d(3), d(4), declRef(statecontract.CertificateDER, 25), declRef(statecontract.IdentityHistory, 26), statecontract.TimeWindow{0, 100}},
		ServerTrust: statecontract.ServerTrustSection{h(statecontract.DomainServerTrust), bundle(statecontract.BootstrapServer, 27), bundle(statecontract.AgentServer, 29)},
		Releases:    statecontract.ReleaseSection{h(statecontract.DomainReleases), d(30), statecontract.VersionMark{1, declRef(statecontract.ApprovedManifest, 31)}, statecontract.VersionMark{1, declRef(statecontract.InstalledMap, 32)}},
		Resources:   statecontract.ResourceSection{h(statecontract.DomainResources), mark(statecontract.ResourceEnvelope, 33), scope.NodeID, 1, d(11)},
		HostPolicy:  statecontract.HostPolicySection{h(statecontract.DomainHostPolicy), mark(statecontract.HostMemoryPolicy, 35), scope.NodeID, 1, d(11)},
		Desired:     statecontract.DesiredSection{h(statecontract.DomainDesired), mark(statecontract.DesiredSnapshot, 40), 1, 1, d(33), d(20), d(22), d(2), statecontract.TimeWindow{0, 100}, []string{"slot"}},
		Recovery:    statecontract.RecoverySection{Header: statecontract.SectionHeader{statecontract.DomainRecovery, statecontract.NeverEstablished}},
		Supervisor:  statecontract.SupervisorSection{h(statecontract.DomainSupervisor), d(45), scope.Supervisor, declRef(statecontract.SupervisorState, 46), statecontract.AppliedRecord{statecontract.Present, desired}, statecontract.AppliedRecord{statecontract.Present, desired}, statecontract.TransitionRef{Coverage: statecontract.NeverEstablished}},
		LKG:         statecontract.LKGSection{h(statecontract.DomainLKG), desired, declRef(statecontract.LKGHistory, 47), []statecontract.LKGEntry{{"slot", desired, declRef(statecontract.ProcessSpec, 48), declRef(statecontract.ConfigMaterial, 49), declRef(statecontract.ReleaseMaterial, 50), d(20), d(22), d(2), 100}}},
	}
}

func artifact(ref statematerials.MaterialRef) statecontract.ArtifactRef {
	kind := statecontract.ArtifactUnknown
	switch ref.Kind {
	case statematerials.RootSet:
		kind = statecontract.RootPayload
	case statematerials.RootRotation:
		kind = statecontract.RootRotation
	case statematerials.Metadata:
		kind = statecontract.Metadata
	case statematerials.Desired:
		kind = statecontract.DesiredSnapshot
	}
	return statecontract.ArtifactRef{Kind: kind, Payload: ref.Payload, Envelope: ref.Envelope}
}
func declarationFor(t *testing.T, comp statecomposition.Input) statecontract.MainStateContentModel {
	x := declarationFixture()
	root := expected(&comp, tailRef(comp))
	meta := expected(&comp, comp.Target.Metadata)
	des := expected(&comp, comp.Target.Desired)
	x.Scope.NodeID = comp.Materials.Scope.NodeID
	x.Scope.AuthorityEpoch = comp.Materials.Scope.Epoch
	x.Checkpoint.NodeID = x.Scope.NodeID
	x.Checkpoint.AuthorityEpoch = x.Scope.AuthorityEpoch
	x.Resources.NodeID = x.Scope.NodeID
	x.Resources.AuthorityEpoch = x.Scope.AuthorityEpoch
	x.HostPolicy.NodeID = x.Scope.NodeID
	x.HostPolicy.AuthorityEpoch = x.Scope.AuthorityEpoch
	x.ServerTrust.Bootstrap.AuthorityEpoch = x.Scope.AuthorityEpoch
	x.ServerTrust.Agent.AuthorityEpoch = x.Scope.AuthorityEpoch
	x.Root.Mark = statecontract.StreamMark{Version: root.Root.Version, Sequence: root.Sequence, Material: artifact(root.Ref)}
	x.Root.Threshold = uint8(root.Root.Threshold)
	x.Root.KeyIDs = append([]contracts.Digest(nil), root.Root.KeyIDs...)
	x.Metadata.Mark = statecontract.StreamMark{Version: meta.Metadata.Version, Sequence: meta.Sequence, Material: artifact(meta.Ref)}
	x.Metadata.RootVersion = meta.Metadata.RootVersion
	x.Metadata.RootPayload = meta.Metadata.RootPayload
	x.Metadata.KeyIDs = append([]contracts.Digest(nil), meta.Metadata.KeyIDs...)
	x.Metadata.RevokedIDs = append([]contracts.Digest(nil), meta.Metadata.RevokedIDs...)
	x.Metadata.Window = statecontract.TimeWindow{Issued: meta.Metadata.Window.Issued, Until: meta.Metadata.Window.Until}
	x.Desired.Mark = statecontract.StreamMark{Version: des.Desired.Generation, Sequence: des.Sequence, Material: artifact(des.Ref)}
	x.Desired.InventoryVersion = des.Desired.InventoryVersion
	x.Desired.ResourceVersion = des.Desired.ResourceVersion
	x.Desired.ResourcePayload = des.Desired.ResourcePayload
	x.Desired.RootPayload = des.Desired.RootPayload
	x.Desired.MetadataPayload = des.Desired.MetadataPayload
	x.Desired.SigningKeyID = des.Desired.SigningKeyID
	x.Desired.Window = statecontract.TimeWindow{Issued: des.Desired.Window.Issued, Until: des.Desired.Window.Until}
	x.Desired.SlotIDs = append([]string(nil), des.Desired.SlotIDs...)
	x.Resources.Mark.Version = des.Desired.ResourceVersion
	x.Resources.Mark.Material.Payload = des.Desired.ResourcePayload
	accepted := statecontract.DesiredBinding{Generation: des.Desired.Generation, Sequence: des.Sequence, Payload: des.Ref.Payload}
	x.Supervisor.Verified.Desired = accepted
	x.Supervisor.Applied.Desired = accepted
	x.LKG.HighestAccepted = accepted
	x.LKG.Entries[0].Desired = accepted
	x.LKG.Entries[0].RootPayload = des.Desired.RootPayload
	x.LKG.Entries[0].MetadataPayload = des.Desired.MetadataPayload
	x.LKG.Entries[0].SigningKeyID = des.Desired.SigningKeyID
	return x
}

func fixtureTime(t *testing.T, s string) time.Time {
	t.Helper()
	v, e := time.Parse(time.RFC3339, s)
	if e != nil {
		t.Fatal(e)
	}
	return v
}
func fixturePublic(t *testing.T, k map[string]any) stateformat.PublicKeyMaterial {
	t.Helper()
	r := stateformat.PublicKeyMaterial{KeyID: digest(t, k["key_id"].(string))}
	raw, e := base64.RawURLEncoding.DecodeString(k["public_key"].(string))
	if e != nil || len(raw) != 32 {
		t.Fatal("fixture key")
	}
	copy(r.PublicKey[:], raw)
	return r
}
func fixtureRoot(t *testing.T, raw []byte, source contracts.Digest) statepolicy.RootRecord {
	t.Helper()
	p := object(t, raw)
	r := statepolicy.RootRecord{Mark: statepolicy.HighWater{Version: number(t, p, "root_version"), Sequence: number(t, p, "authority_sequence"), Payload: source}}
	r.Root.Version = r.Mark.Version
	r.Root.Threshold = number(t, p, "threshold")
	for _, k := range p["keys"].([]any) {
		r.Root.Keys = append(r.Root.Keys, fixturePublic(t, k.(map[string]any)))
	}
	return r
}
func fixtureMetadataKeys(t *testing.T, raw []byte) []statepolicy.KeyRecord {
	t.Helper()
	p := object(t, payload(t, raw))
	var keys []statepolicy.KeyRecord
	for _, item := range p["keys"].([]any) {
		k := item.(map[string]any)
		m := stateformat.MetadataKeyMaterial{PublicKeyMaterial: fixturePublic(t, k), Status: k["status"].(string), NotBefore: fixtureTime(t, k["not_before"].(string)), NotAfter: fixtureTime(t, k["not_after"].(string))}
		r := statepolicy.KeyRecord{Material: m}
		if k["revoked_at"] != nil {
			r.Material.HasRevocation = true
			r.Material.RevokedAt = fixtureTime(t, k["revoked_at"].(string))
			r.Material.RevocationReason = k["revocation_reason"].(string)
			r.FirstRevokedAt = r.Material.RevokedAt
		}
		if k["incident_id"] != nil {
			r.Material.HasIncident = true
			id, e := uuid.Parse(k["incident_id"].(string))
			if e != nil {
				t.Fatal(e)
			}
			r.Material.IncidentID = id
		}
		keys = append(keys, r)
	}
	return keys
}
func policyBindingFixture(t *testing.T, rotations, previousRotations int) statepolicybinding.Input {
	t.Helper()
	if previousRotations < 0 || rotations < previousRotations || rotations > 32 {
		t.Fatal("fixture rotations")
	}
	previous := compositionFixture(t, previousRotations)
	next := compositionFixture(t, rotations)
	if rotations > previousRotations {
		m := object(t, payload(t, material(&next, next.Target.Metadata).Raw))
		m["metadata_version"] = "7"
		m["authority_sequence"] = "6"
		next.Target.Metadata = addEnvelope(t, &next, statematerials.Metadata, mint(t, "metadata", m, private(1)), statematerials.MaterialRef{}, tailRef(next), statematerials.MaterialRef{})
		des := object(t, frozen(t, "desired.payload.json"))
		des["generation"] = "8"
		des["authority_sequence"] = "10"
		next.Target.Desired = addEnvelope(t, &next, statematerials.Desired, mint(t, "desired", des, private(2)), statematerials.MaterialRef{}, tailRef(next), next.Target.Metadata)
	}
	a := declarationFor(t, previous)
	b := declarationFor(t, next)
	in := statepolicybinding.Input{Binding: statebinding.Input{Main: statecontract.ModelInput{Previous: a, Proposed: b}, Previous: previous.Materials, Proposed: next}}
	for i := previousRotations; i < len(next.Target.Links); i++ {
		l := next.Target.Links[i]
		e := expected(&next, l.Rotation)
		in.Binding.Main.RootTransition = append(in.Binding.Main.RootTransition, statecontract.RotationRef{PreviousVersion: e.Rotation.PreviousVersion, NewVersion: e.Rotation.NewVersion, Sequence: e.Sequence, OldRootPayload: e.Rotation.OldRootPayload, NewRootPayload: e.Rotation.NewRootPayload, Material: artifact(l.Rotation)})
	}
	node, e := uuid.Parse(a.Scope.NodeID)
	if e != nil {
		t.Fatal(e)
	}
	old := &statepolicy.StateModel{Status: statepolicy.Available, StateID: d(80), CounterID: d(81), StateEpoch: 82, NodeID: node, Epoch: 19, AnchorPayload: next.Anchor.Payload, DeploymentSourceID: d(83), TimeProviderID: a.Scope.TimeProviderID, TimeFloor: fixtureTime(t, "2019-12-31T00:00:00Z")}
	old.Roots = append(old.Roots, fixtureRoot(t, frozen(t, "anchor.payload.json"), next.Anchor.Payload))
	for _, l := range previous.Target.Links {
		old.Roots = append(old.Roots, fixtureRoot(t, material(&previous, l.NewRoot).Raw, l.Rotation.Payload))
	}
	old.Metadata = statepolicy.HighWater{Version: a.Metadata.Mark.Version, Sequence: a.Metadata.Mark.Sequence, Payload: a.Metadata.Mark.Material.Payload}
	old.Desired = statepolicy.HighWater{Version: a.Desired.Mark.Version, Sequence: a.Desired.Mark.Sequence, Payload: a.Desired.Mark.Material.Payload}
	old.Keys = fixtureMetadataKeys(t, material(&previous, previous.Target.Metadata).Raw)
	old.RevokedIDs = append([]contracts.Digest(nil), a.Metadata.RevokedIDs...)
	in.Policy.Old = old
	in.Policy.Deployment = statepolicy.DeploymentObservation{Status: statepolicy.Available, SourceID: old.DeploymentSourceID, ObservationID: d(84), NodeID: node, Epoch: 19, AnchorPayload: next.Anchor.Payload}
	in.Policy.Time = statepolicy.TimeObservation{Status: statepolicy.Available, ProviderID: old.TimeProviderID, ObservationID: d(85), Now: fixtureTime(t, "2020-01-01T01:00:00Z"), Floor: old.TimeFloor}
	in.Policy.Batch.ExpectedNodeID = next.Materials.Scope.NodeID
	in.Policy.Batch.ExpectedEpoch = 19
	in.Policy.Batch.AnchorEnvelope = next.Anchor.Raw
	for _, l := range next.Target.Links {
		in.Policy.Batch.Rotations = append(in.Policy.Batch.Rotations, material(&next, l.Rotation).Raw)
	}
	in.Policy.Batch.ActiveRootEnvelope = next.Anchor.Raw
	if len(in.Policy.Batch.Rotations) > 0 {
		in.Policy.Batch.ActiveRootEnvelope = in.Policy.Batch.Rotations[len(in.Policy.Batch.Rotations)-1]
	}
	in.Policy.Batch.MetadataEnvelope = material(&next, next.Target.Metadata).Raw
	in.Policy.Batch.DesiredEnvelope = material(&next, next.Target.Desired).Raw
	return copyPolicyBindingInput(t, in)
}
func copyPolicyBindingInput(t *testing.T, in statepolicybinding.Input) statepolicybinding.Input {
	t.Helper()
	raw, e := json.Marshal(in)
	if e != nil {
		t.Fatal(e)
	}
	var out statepolicybinding.Input
	if e = json.Unmarshal(raw, &out); e != nil {
		t.Fatal(e)
	}
	return out
}
func checkBindingInput(t *testing.T, in statepolicybinding.Input) statebinding.Summary {
	t.Helper()
	m, e := statebinding.Evaluate(context.Background(), in.Binding)
	if e != nil {
		t.Fatal("binding fixture", e)
	}
	defer m.Clear()
	return m.Summary()
}
func checkPolicyInput(t *testing.T, in statepolicybinding.Input) {
	t.Helper()
	c, e := statepolicy.EvaluateModel(context.Background(), in.Policy)
	if e != nil {
		t.Fatal("policy fixture", e)
	}
	defer c.Clear()
}
func timeBindingFixture(t *testing.T, rotations int, proposedCheckpoint uint64) Input {
	t.Helper()
	return attachTime(t, policyBindingFixture(t, rotations, rotations), proposedCheckpoint)
}
func attachTime(t *testing.T, policy statepolicybinding.Input, proposedCheckpoint uint64) Input {
	t.Helper()
	policy.Binding.Main.Proposed.Checkpoint.Sequence = proposedCheckpoint
	in := Input{Policy: policy}
	old := policy.Policy.Old
	mark := policy.Binding.Main.Previous.Metadata.Mark
	in.Time = statetime.ModelInput{
		MetadataEnvelope: policy.Policy.Batch.MetadataEnvelope,
		Metadata:         statetime.CurrentMetadataObservation{Status: statetime.Available, SourceID: d(90), ObservationID: d(91), StateID: old.StateID, NodeID: old.NodeID, Epoch: old.Epoch, Version: mark.Version, Payload: mark.Material.Payload, Envelope: mark.Material.Envelope},
		Time:             statetime.TimeObservation{Status: statetime.Available, ProviderID: policy.Policy.Time.ProviderID, ObservationID: policy.Policy.Time.ObservationID, Now: policy.Policy.Time.Now, Floor: policy.Policy.Time.Floor},
		Request:          statetime.RequestObservation{Status: statetime.Available, RequestID: d(92), ObservationID: d(93), NodeID: old.NodeID, Epoch: old.Epoch},
		Checkpoint:       statetime.CheckpointObservation{Status: statetime.Available, SourceID: d(94), ObservationID: d(95), StateID: old.StateID, NodeID: old.NodeID, Epoch: old.Epoch, Sequence: policy.Binding.Main.Previous.Checkpoint.Sequence},
	}
	signAttestation(t, &in, proposedCheckpoint, [32]byte{})
	return in
}
func canon(t *testing.T, in any) []byte {
	t.Helper()
	raw := encode(t, in)
	raw, e := jcs.Transform(raw)
	if e != nil {
		t.Fatal(e)
	}
	return raw
}
func signAttestation(t *testing.T, in *Input, sequence uint64, nonce [32]byte) {
	t.Helper()
	now := in.Time.Time.Now
	p := map[string]any{"schema_version": "node-time-attestation.v1", "control_plane_authority_epoch": strconv.FormatUint(in.Time.Request.Epoch, 10), "node_authority_checkpoint_sequence": strconv.FormatUint(sequence, 10), "node_id": in.Time.Request.NodeID.String(), "request_nonce": base64.RawURLEncoding.EncodeToString(nonce[:]), "issued_at": now.Format(time.RFC3339), "valid_until": now.Add(5 * time.Minute).Format(time.RFC3339)}
	raw := canon(t, p)
	pd := sha256.Sum256(raw)
	key := private(2)
	id := sha256.Sum256(key.Public().(ed25519.PublicKey))
	sig := ed25519.Sign(key, append([]byte("TALENRO-NODE-TIME-ATTESTATION-V1\x00"), raw...))
	in.Time.AttestationEnvelope = canon(t, map[string]any{"schema_version": "talenro-node-time-attestation/v1", "payload_b64url": base64.RawURLEncoding.EncodeToString(raw), "payload_sha256": hex.EncodeToString(pd[:]), "key_id": hex.EncodeToString(id[:]), "signature": base64.RawURLEncoding.EncodeToString(sig)})
}

type Input = statetimebinding.Input
type Packet struct { Certificate nodeissuer.Input; Time Input }
const root = "D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator"
var fixtureNode = "12345678-1234-4234-8234-123456789abc"

func frozen(t *testing.T, name string) []byte {
 if name == "anchor.payload.json" || name == "rotation.payload.json" || name == "metadata.payload.json" || name == "desired.payload.json" {
  p := object(t, baseFrozen(t, name))
  switch name {
  case "anchor.payload.json": p["keys"] = []any{wireKey(1)}
  case "rotation.payload.json": p["new_root_set"].(map[string]any)["keys"] = []any{wireKey(1)}
  case "metadata.payload.json":
   old := p["keys"].([]any)[0].(map[string]any)
   for k,v := range wireKey(2) {old[k]=v}
  case "desired.payload.json": p["node_id"] = fixtureNode
  }
  return encode(t,p)
 }
 for _, n := range []string{"anchor","rotation","metadata","desired"} {
  if name == n+".envelope.json" {
   signer := private(1); if n=="desired" {signer=private(2)}
   return mint(t,n,object(t,frozen(t,n+".payload.json")),signer)
  }
 }
 t.Fatal("unexpected template",name); return nil
}
func scalar(n int64) *ecdsa.PrivateKey {
 k:=new(ecdsa.PrivateKey);k.Curve=elliptic.P256();k.D=big.NewInt(n);k.X,k.Y=k.Curve.ScalarBaseMult(k.D.Bytes());return k
}
func certificate(t *testing.T, node string, caStart,caEnd,leafStart,leafEnd time.Time) nodeissuer.Input {
 caKey,leafKey:=scalar(1),scalar(2)
 caSPKI,e:=x509.MarshalPKIXPublicKey(&caKey.PublicKey);if e!=nil {t.Fatal(e)}
 leafSPKI,e:=x509.MarshalPKIXPublicKey(&leafKey.PublicKey);if e!=nil {t.Fatal(e)}
 caID,leafID:=sha256.Sum256(caSPKI),sha256.Sum256(leafSPKI)
 ca:=&x509.Certificate{SerialNumber:big.NewInt(1),Subject:pkix.Name{CommonName:"fixed-test-ca"},NotBefore:caStart,NotAfter:caEnd,BasicConstraintsValid:true,IsCA:true,KeyUsage:x509.KeyUsageCertSign,SubjectKeyId:caID[:],AuthorityKeyId:caID[:]}
 caDER,e:=x509.CreateCertificate(rand.Reader,ca,ca,&caKey.PublicKey,caKey);if e!=nil{t.Fatal(e)}
 uri,e:=url.Parse("spiffe://node.test/node/"+node);if e!=nil{t.Fatal(e)}
 leaf:=&x509.Certificate{SerialNumber:big.NewInt(128),NotBefore:leafStart,NotAfter:leafEnd,BasicConstraintsValid:true,KeyUsage:x509.KeyUsageDigitalSignature,ExtKeyUsage:[]x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth},URIs:[]*url.URL{uri},SubjectKeyId:leafID[:],AuthorityKeyId:caID[:]}
 leafDER,e:=x509.CreateCertificate(rand.Reader,leaf,ca,&leafKey.PublicKey,caKey);if e!=nil{t.Fatal(e)}
 var out nodeissuer.Input
 out.Leaf.DER=leafDER;out.Leaf.ExpectedSPKI=leafSPKI;out.Leaf.NodeID=uuid.MustParse(node);out.Leaf.TrustDomain="node.test"
 out.CA.DER=caDER;out.CA.DeclaredSPKI=caSPKI
 return out
}
func TestGenerateCertTime(t *testing.T) {
 now:=fixtureTime(t,"2020-01-01T01:00:00Z")
 caStart,caEnd:=fixtureTime(t,"2019-01-01T00:00:00Z"),fixtureTime(t,"2030-01-01T00:00:00Z")
 leafStart:=now.Add(-5*time.Minute);leafEnd:=leafStart.Add(24*time.Hour)
 base:=Packet{Certificate:certificate(t,fixtureNode,caStart,caEnd,leafStart,leafEnd),Time:timeBindingFixture(t,1,101)}
 fixtures:=map[string]Packet{"base":base}
 clone:=func(p Packet)Packet{var q Packet;if e:=json.Unmarshal(encode(t,p),&q);e!=nil{t.Fatal(e)};return q}
 fixtures["history-0"]=Packet{Certificate:base.Certificate,Time:timeBindingFixture(t,0,101)}
 fixtures["history-32"]=Packet{Certificate:base.Certificate,Time:timeBindingFixture(t,32,101)}
 fixtureNode="22345678-1234-4234-8234-123456789abc"
 fixtures["other-node"]=Packet{Certificate:certificate(t,fixtureNode,caStart,caEnd,leafStart,leafEnd),Time:timeBindingFixture(t,1,101)}
 fixtureNode="12345678-1234-4234-8234-123456789abc"
 put:=func(name string, a,b,c,d time.Time, observed time.Time){
  p:=clone(base);p.Certificate=certificate(t,fixtureNode,a,b,c,d)
  p.Time.Policy.Policy.Time.Now=observed;p.Time.Time.Time.Now=observed
  // Fixed wider attestation remains valid on both sides of a nanosecond edge.
  p.Time.Time.Time.Now=now.Add(-time.Minute);signAttestation(t,&p.Time,101,[32]byte{});p.Time.Time.Time.Now=observed
  fixtures[name]=p
 }
 for _, edge:=range []string{"ca-start","ca-end","leaf-start","leaf-end"} {
  a,b,c,d:=caStart,caEnd,now.Add(-time.Hour),now.Add(23*time.Hour)
  switch edge {case "ca-start":a=now;case "ca-end":b=now;case "leaf-start":c=now;d=now.Add(24*time.Hour);case "leaf-end":c=now.Add(-24*time.Hour);d=now}
  for _, point:=range []struct{label string;delta time.Duration}{{"before",-time.Nanosecond},{"exact",0},{"after",time.Nanosecond}} {put(edge+"-"+point.label,a,b,c,d,now.Add(point.delta))}
 }
 put("ca-expired-leaf-future",caStart,now,now.Add(time.Minute),now.Add(time.Minute+24*time.Hour),now)
 put("ca-future-leaf-expired",now.Add(time.Minute),caEnd,now.Add(-24*time.Hour),now,now)
 put("ca-first",caStart,now.Add(time.Minute),now.Add(-24*time.Hour+2*time.Minute),now.Add(2*time.Minute),now)
 put("leaf-first",caStart,now.Add(10*time.Minute),now.Add(-24*time.Hour+2*time.Minute),now.Add(2*time.Minute),now)
 // Deadline controls use base attestation until now+5m (not the wider edge packet).
 for _, v:=range []struct{name string;ca,leaf time.Duration}{{"ca-first",time.Minute,2*time.Minute},{"leaf-first",10*time.Minute,2*time.Minute},{"time-first",10*time.Minute,10*time.Minute},{"ca-leaf-tie",2*time.Minute,2*time.Minute},{"ca-time-tie",5*time.Minute,10*time.Minute},{"leaf-time-tie",10*time.Minute,5*time.Minute},{"all-tie",5*time.Minute,5*time.Minute}} {
  p:=clone(base);p.Certificate=certificate(t,fixtureNode,caStart,now.Add(v.ca),now.Add(v.leaf-24*time.Hour),now.Add(v.leaf));fixtures[v.name]=p
 }
 put("leaf-crosses-ca",now.Add(-30*time.Second),now.Add(30*time.Second),now.Add(-24*time.Hour+time.Minute),now.Add(time.Minute),now)
 put("ca-year-1",time.Date(1,1,1,0,0,0,0,time.UTC),caEnd,leafStart,leafEnd,now)
 put("leaf-year-1",caStart,caEnd,time.Date(1,1,1,0,0,0,0,time.UTC),time.Date(1,1,2,0,0,0,0,time.UTC),now)
 p:=clone(base);p.Certificate.Leaf.DER[len(p.Certificate.Leaf.DER)-1]^=1;fixtures["bad-signature"]=p
 p=clone(base);p.Time.Time.Request.ExpectedNonce[0]=1;fixtures["bad-nonce"]=p
 p=clone(base);p.Time.Time.MetadataEnvelope[0]='!';fixtures["bad-metadata"]=p
 p=clone(base);p.Time.Time.Checkpoint.Sequence=101;fixtures["rollback"]=p
 p=clone(base);p.Time.Time.Request.Status=0;fixtures["missing-observation"]=p
 p=clone(base);p.Time.Policy.Policy.Old.TimeFloor=now.Add(time.Hour);fixtures["policy-failure"]=p
 outdir:=filepath.Join(root,".superpowers/sdd/2026-10-12-node-certificate-time-binding")
 raw:=encode(t,fixtures)
 if e:=os.WriteFile(filepath.Join(outdir,"frozen-inputs.json"),raw,0600);e!=nil{t.Fatal(e)}
 f,e:=os.Create(filepath.Join(outdir,"frozen-inputs.json.gz"));if e!=nil{t.Fatal(e)};w:=gzip.NewWriter(f);if _,e=w.Write(raw);e!=nil{t.Fatal(e)};if e=w.Close();e!=nil{t.Fatal(e)};if e=f.Close();e!=nil{t.Fatal(e)}
 t.Log("generated",len(fixtures),"fixed packets; no ordinary test re-signing")
}

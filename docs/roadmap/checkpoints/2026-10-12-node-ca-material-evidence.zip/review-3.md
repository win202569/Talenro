# Fresh read-only review 3 — report and counterexamples

Reviewer: /root/ca_material_final_review_3, gpt-6-astra/xhigh, fresh context, read-only.
This is an author transcription of the returned findings/evidence (the original report is retained in the conversation), not a new independent verdict.

All24sources, fullspec/plan, fivebriefs, priorreviews, baseline/progress and all52receipts read. All735priorhashes and24freezehashes independently matched except allowed spec/plan state. HEAD/branch/index unchanged, +24 dirtyfiles. Prior two fixes and oracle correction confirmed sound. Current format0047 emptyexit0/final0048–0052exit0 are author evidence, not reviewer-executed tests.

Result:0 Critical /3 Important /0 Minor; current increment needs fixes, not merge/C12 approval.

I1 spki.go:19: Unsupported-key return bypasses complete declared-SPKI consumption.
Counterexample DeclaredSPKI:
302c300506032b6570032100d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a0500
Go ParsePKIXPublicKey asn1.Unmarshal struct ignores unmatched trailing SEQUENCE elements and returns Ed25519. CurrentcanonicalSPKI returns Unsupported before validatingtail. ExpectedInvalidInput. ValidnonP256 control staysUnsupported. Fixcomplete structural/canonical consumption before unsupported classification, no algorithmscope expansion.

I2 raw_certificate.go:133: UID rejection skips malformed implicit BIT STRING and remaining TBS.
Insert810108 aftersubjectSPKI beforeextensions:Go justskipsoptionalUID; rawscannerreturnsUnsupported early. ExpectedInvalidMaterial becauseunusedbits8. ValidforbiddenUID staysUnsupported. Alsotest malformedTBSaftervalidUID, complete rawstructscan beforeUnsupported.

I3 extensions.go:105/111: genericwalker skips known IMPLICIT AKI serial INTEGER minimality.
CounterexampleinnerAKI:
302680205cd252fb0ce8932436faf8ccd1040981b89ee4ad6b9fe9e2a2b7e71aacb27cd382020001
Added82020001 isknown authorityCertSerialNumber[2] nonminimalINTEGER; pinnedparserignoresafterkeyID, walker onlychecks universalINTEGER, currentUnsupported expectedInvalidMaterial. Empty8200 similarly. Existingvalid820101 excludedUnsupported mustremain. No parentbinding/schema-unknownsigner semantics needed.

Evidence:52receiptsparsed/fullwrappers/UTC/output/exit/hashesconsistent; historical freezesmatchtheirownreceipts.0046 posthash and0047–0052 prepostmatchfreeze3.0044 failure retained, correction justified. DERfuzz5seeds/10executions;SPKI53cachedseeds/62,009/11new. No tests/network/format/writes byreviewer.28nestedtestdata and16root-leveltestdata unchanged; no newpackage testdata. Independent golden/RFCdigests correct. Specbodyhash andnormalizedfivebriefs match.

Declined domains1–14 same asreview2; allneedauthorrulings:
1 signature/signerpolicy Pending
2 parent/chain/root/AKIparent/selfsign/pathconstraints noauthenticatedparent
3 trustedcurrenttime/maxlifetime/backdating deferred
4 deploymentprovenance/trustdomain/namingauthorization/purpose/auth outsidelayer
5 bundle/revocation/compromise/versionshighwater/rollback Pending
6 CAleaf issuer/signature/AKI/privatekey/install/runtime nocorrespondinginputs
7 providercompatibility/migration unpromised
8 concurrentmutation/Clearread unsupported
9 fatalOOM/crash/unreachablecopies/hardrealtime excluded
10 formalASTcompleteness notproved
11 exhaustivefuzz/resources/Linux/race/DBDocker/fullrepo unrun
12 historicdirtychanges/Task10/B01/C12/main incrementonly
13 opaqueunknownsignerprimitivecontentsemantics outsideparseraccepted/minimalTLV
14 opaqueSETvsSETOFcanonicalorder unknowableschema, knownDNSETOF stillrequired
15 globalserialuniqueness expresslyunproved
16 DNtextnormalization/semanticequivalence exactrawpreservednotnormalized.

Recommendations:focusregressions/validunsupportedcontrols, fixwithouttrust/algorithmbroadening, exactformat/fivefinalcommands/freeze/freshreview; onlythenstatusdoccloseout.

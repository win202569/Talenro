# Final independent review 6 — author transcription

Original complete report returned by /root/ca_material_final_review_6 (fresh gpt-6-astra/xhigh) is retained in the conversation. This file is an author transcription, NOT a verbatim report or author test reproduction. Reviewer was strictly read-only and performed no tests, formatting, networking or writes.

## Strengths
Partial-result boundary sound: subject key separate from parent authentication; arbitrary shape-valid AKI not subject-derived; all six Pending fixed. Ownership/shared Clear/cancellation handoff/exact-byte hashes/pathLen absence-vs-zero clear. Earlier counterexamples retained; opaque OID cap removed. Independently verified all735 old files (only allowed spec/plan state changes),44 unchanged testdata, exact759 inventory/364 status (+24), no consumers or new testdata.

## Issues and verdict
0 Critical /2 Important /0 Minor. Needs fixes; not merge/main/C12 authorization.

### Important1: rejected directoryName bypasses pinned Name AttributeValue interpretation
raw_certificate.go:64 reached from extensions.go:169. checkNameSyntax(...,true) calls generic checkGeneralValue on AttributeValue; permits NULL, INTEGER, OCTET STRING, constructed containers where pinned Name parser requires supported string representation.
Source-derived AKI issuer suffix after existing golden primitive keyIdentifier:
a10fa40d300b3109300706035504030500
Known commonName2.5.4.3 has NULL value; reaches Unsupported instead of InvalidMaterial. Same path accepts empty OCTET/SEQUENCE or minimal INTEGER020101.
Not new CN/OID subtype policy: reviewer independently read pinned x509.parseName→parseASN1String; accepted tags T61(20), Printable(19), UTF8(12), BMP(30), IA5(22), Numeric(18).
Fix single Name AttributeValue using pinned Name string interpretation/encoding checks; preserve allowances, valid excluded controls, representation-only opaque OIDs; no naming authorization/bounded OID conversion.
Impact fixed malformed/uninterpretable vs interpretable excluded error distinction; no accepted material/trust bypass asserted.

### Important2: extension ANY misses universal payload/container grammar
extensions.go:230, limited walker der.go:136. Selected strings plus generic tag/length/form checks omit universally defined grammar, distinct from vendor-schema semantics.
Source-derived AKI issuer suffixes:
- a10aa00806012aa0031a01ff — otherName ANY VisibleString ff outside repertoire
- a10aa00806012aa0030d0180 — unterminated RELATIVE-OID
- a109a00706012aa0021700 — empty UTCTime
- a109a00706012aa0021800 — empty GeneralizedTime
- a109a00706012aa0022800 — EXTERNAL missing required encoding choice
Each reaches Unsupported instead of InvalidMaterial. Unknown X400 extension explicit ANY shares path.
Valid excluded controls retain Unsupported:1a0161,0d0101,valid times,2804a0020500.
Fix extension-specific known universal encoding/required-container grammar with negative/control pairs; preserve separate unknown-signer exclusion/no vendor schema or signer-policy expansion.
No accepted material/trust bypass asserted.

## Recommendations
Fix both together using focused Name value-tag and extension ANY payload/container matrices. Keep valid excluded controls and partial boundaries. After any source edit: exact formatting/check, all five final commands, freeze, fresh review. Task5/docs pending until gate.

## Every declined-to-judge domain and reason (reviewer order)
1. Signature authenticity/signer-policy — Pending.
2. Parent/chain/root/AKI-parent/self-sign/actual path — no authenticated parent input.
3. Current validity/max lifetime/backdate — deferred time responsibilities.
4. Deployment provenance/trust domain/naming authorization/purpose/authorization — outside material layer.
5. Bundle/revocation/compromise/version/highwater/rollback — Pending.
6. CA-leaf issuer/signature/AKI/privatekey/install/runtime — no input or authorized consumer.
7. Production provider/migration — no acceptance commitment.
8. Concurrent input mutation/Clear/read — unsupported.
9. Fatal OOM/crash/unreachable copies/hard real-time — excluded.
10. Formal AST completeness — finite source checks, not proof.
11. Exhaustive fuzz/total resources/Linux/race/DBDocker/fullrepo — outside native evidence.
12. Unrelated dirty history/Task10/B01/C12/main — increment only.
13. Full universal primitive semantics in opaque unknown signer parameters — prior signer-specific limitation, not excuse for recognized extension defects.
14. Unknown schema SET/SETOF order — needs schema; known RDN/X400 order inspected.
15. Global serial uniqueness — unproved.
16. DN normalization/equivalence — raw exact, not normalized.
17. Full excluded-GeneralName naming/routing/length/range/subtype policy — no fullRFC/provider claim, not waiver of encoding/container grammar.
18. Vendor meaning behind otherName unknown OID/X400 unknown type — no schema, universal encodings remain checkable.
19. Full legacy charset repertoire beyond pinned compatibility — no independent repertoire-table validation in no-network review; T61/GeneralString and broader Videotex/GraphicString semantics not certified.

## Evidence and limits
Complete spec/plan/five original briefs/all24 files/baseline/progress/five prior saved reports/all82 raw receipts/six freezes/revision6 consistency reviewed. Reports3–5 explicitly author transcriptions;2 exact returned;1 saved summary. Normalized task sections match all briefs. Spec bodySHA256557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF unchanged.
Every historical freeze matches corresponding final receipts. Current freeze6 matches current24/0076post/0077–0082prepost. Format0077 empty/exit0 and final0078–0082 exit0 are AUTHOR evidence; fuzz only7DER/174SPKI inputs, not exhaustive. Freeze6 during0082; later exit0 and paired hashes present.
Final read-only HEAD6752b9612a00b9d6b0bf87ae8dd95063f6b056ee; branchcodex/c12-b01-task9-coordinator; indexSHA2561CBA46BEF4C1AFDC9AE7938146909F0D2D641A0D712CE18036B60FE5B8673D12 unchanged.
All findings SOURCE-DERIVED including pinned-parser inspection, not runtime reproduction. Architecture/evidence consistent, known-type encoding/error gaps prevent revision6 completion.

# Node CA Material — fresh read-only review package 6

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Approved complete spec: docs/superpowers/specs/2026-10-11-node-ca-material-design.md
Approved Native five-task plan: docs/superpowers/plans/2026-10-11-node-ca-material.md
Evidence directory: .superpowers/sdd/2026-10-11-node-ca-material/

Review the whole exact 24-file increment (12 product, 12 tests) in frozen-sources-6.json. Base = HEAD = 6752b9612a00b9d6b0bf87ae8dd95063f6b056ee; branch codex/c12-b01-task9-coordinator. All new sources are untracked; an empty commit range is not the increment. Do not review unrelated historical dirty work as if introduced here.

Read complete approved spec/plan, five original task briefs, all 24 current files, baseline/progress, all five prior reports, all 82 continuous raw attempt receipts, historical freezes 1–5 and current freeze 6, pre-review-6-baseline-check.json and candidate-6-consistency.json. Original reports 3/4/5 are retained in conversation; their saved files explicitly are author transcriptions, not verbatim. Prior review 2 is the exact returned report.

Baseline: 735 old nonignored files and 340 old dirty entries. Independently verify all baseline hashes (only permitted spec/plan state edits), all 44 old testdata paths (28 nested +16 root), no new testdata/consumers, HEAD/branch/index, inventories and exact +24 dirty/new files. Index SHA256 remains 1CBA46BEF4C1AFDC9AE7938146909F0D2D641A0D712CE18036B60FE5B8673D12.
Requirement body SHA256: 557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF. Normalize checkbox status when comparing five task sections with original briefs. Status/execution closeout documents have NOT been changed yet.

Prior review corrections:
1: 0 Critical /3 Important /1 Minor: known DN SET OF order, universal form bits, BC complete consumption, RFC full literal coverage. 0033 assertion RED (RFC coverage already passed) →0034 GREEN.
2: 0/2/0: remove schema-unknown opaque SET OF assumption (keep known DN order); validate nested AKI structure. 0042 RED →0043/0045 GREEN. 0044 failed new oracle, not GREEN: original zero-filled constructed[0] stays InvalidMaterial; separate well-formed OCTET representation stays Unsupported.
3: 0/3/0: outer SPKI consumption before unsupported key; UID BIT STRING and full TBS scan before profile return; AKI [2] implicit INTEGER minimality. 0053 RED →0054/0055/0056 GREEN.
4: 0/2/0: RSA known BIT STRING payload tail discarded by Go before Unsupported; AKI issuer GeneralName registeredID [8] implicit OID minimality. 0064 genuine RED also reproduced DSA payload/parameter tails and four malformed OID controls. 0065 focused GREEN. Valid RSA, DSA and registeredID controls retained.

5: 0/2/0: incomplete known GeneralNames encoding/container grammar and unapproved bounded-integer cap for valid opaque OID parameters. 0073 genuine RED for all supplied GeneralNames and large-OID examples; 0074 supplements known X400 attribute type/container counterexamples, also genuine RED. Valid excluded controls passed. 0075 all three focused suites GREEN.

Current correction only changes der.go, extensions.go, raw_certificate.go and parse_test.go from freeze5; spki.go is unchanged:
- Generic opaque-value OID checks require nonempty, minimal, terminated base128 representation, not Go-int numeric conversion. Actual certificate Name/algorithm/extension OID conversions retain the pinned parser boundary.
- Rejected issuer-bearing AKI GeneralNames validate IA5 fields, single Name / RDN SET OF / ATV complete consumption and string encodings, otherName single explicit ANY, EDI required partyName, ORAddress typed/order/required/consumed boundaries.
- X400 built-in fields, domain pairs, extension SET OF and known extension types1–23 encoding/container forms, presentation selectors and addresses are checked together. Unknown type schema meaning is not resolved.
- New suites TestCAReviewGeneralNamesGrammar, TestCAReviewOpaqueOIDRepresentation, TestCAReviewX400TypedAttributes retain valid excluded controls; six Pending and P256 supported profile unchanged.
- Explicit rulings25/26 in progress.md are interpretation limits, NOT permission to waive actual malformed-encoding/fixed error contract. Do grade them against the approved spec; report all remaining verified typed-payload issues in one pass. No full-RFC/provider/subtype value-policy claim or vendor-schema claim.

CURRENT acceptance receipts:
0076 exact24-source format post-hashes match freeze6;
0077 exact format check pre/post match, empty output/exit0;
0078 full nodeca exit0,5.537s;
0079 existing nodeleaf exit0,4.193s;
0080 existing nodeleafkeys exit0,4.804s;
0081 FuzzCADER exit0:5 seeds/7 executions/no new interesting or crash;
0082 FuzzCASPKI exit0:64 cached seeds/174 executions/no new interesting or crash.
All0077–0082 pre/post hashes and current match freeze6;0076 post matches. Freeze actual UTC 2026-10-11T20:15:08.8251490Z; froze while0082 was running, whose eventual exit0 receipt and paired matching hashes are preserved, not assumed. All82 raw receipts/historical freezes1–5 retained. Native pinned Go1.26.5 windows/amd64 process-only offline settings and fixed120s/5s+30s flags unchanged. Wall-clock delays cause unestablished. Evidence timestamps UTC2026-10-11 can be localOct12(UTC+4), retain approval/filedates.

Review Focus (verbatim from plan):
- 声明 CA subject key 被误当 parent key：Task 4 的 TestCAPartialProofParentRoles 必须证明任意合形状 AKI 不执行 subject 派生，实际 parent/签名仍未认证。
- pathLen 省略被折叠为零：Task 3 的 TestCAPathLenPresence 固定 HasPathLen=false/0 与 true/0 的不同结果。
- parser 接受但 raw 值未完整消费：Task 2 的 TestCARawNestedTails 与 Task 3 的 TestCAExtensionCanonicality 覆盖 DN、BC、KU、SKI、AKI 的嵌套尾随/非最小表示。
- Go 前置拒绝被改写成后置 profile 类别：Task 4 的 TestCAParserPriority 与 TestCACombinedFailurePriority 固定完整检查顺序及不泄露动态错误。
- 清理/包装别名与取消产生旧有效结果：Task 1 的 TestCAMaterialLifecycle 及 Task 4 的 TestCACancellation 固定 shared owner、detached 值及失败无半成品。

The six fixed Pending obligations and partial-only owned CA shape, caller-declared subject P256 binding and full exact SPKI SHA256 SKI remain. No parent/signature/trust/time/deployment/bundle/leaf/runtime/provider capability. No old product/test/guard relaxations, new dependency/I/O/privatekey/clock/random/goroutine, or consumers.

All 16 prior declined domains plus rulings25/26 have explicit author rulings/costs in progress.md. Opaque unknown signer primitive semantics and schema-dependent SET vs SET OF ordering are NOT certified; known DN SET OF order remains checked. Those opaque-signer exclusions do not waive known SPKI or recognized extension grammar. Global serial uniqueness / DN equivalence remain unproved.

Strictly read-only PowerShell. No tests, formatting, cache/file/Git/config/index/HEAD/branch writes, network, worktree/cleanup or subagents. Read-only Git may use GIT_OPTIONAL_LOCKS=0/core.fsmonitor=false and escalation for ownership; never safe.directory. Do all review yourself. Verify raw receipt evidence honestly; do not claim tests you ran.
Return Strengths; Critical/Important/Minor exact file:line with counterexample/impact/fix; Recommendations; every declined-to-judge domain+reason; evidence limits; clear CURRENT partial-increment verdict, not merge/main/C12 authorization. Return report in final only; no disk writes.

# Node CA Material — fresh read-only review package 5

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Approved complete spec: docs/superpowers/specs/2026-10-11-node-ca-material-design.md
Approved Native five-task plan: docs/superpowers/plans/2026-10-11-node-ca-material.md
Evidence directory: .superpowers/sdd/2026-10-11-node-ca-material/

Review the whole exact 24-file increment (12 product, 12 tests) in frozen-sources-5.json. Base = HEAD = 6752b9612a00b9d6b0bf87ae8dd95063f6b056ee; branch codex/c12-b01-task9-coordinator. All new sources are untracked; an empty commit range is not the increment. Do not review unrelated historical dirty work as if introduced here.

Read complete approved spec/plan, five original task briefs, all 24 current files, baseline/progress, all four prior reports, all 72 continuous raw attempt receipts, historical freezes 1–4 and current freeze 5, pre-review-5-baseline-check.json and candidate-5-consistency.json. Original reports 3/4 are retained in conversation; their saved files explicitly are author transcriptions, not verbatim. Prior review 2 is the exact returned report.

Baseline: 735 old nonignored files and 340 old dirty entries. Independently verify all baseline hashes (only permitted spec/plan state edits), all 44 old testdata paths (28 nested +16 root), no new testdata/consumers, HEAD/branch/index, inventories and exact +24 dirty/new files. Index SHA256 remains 1CBA46BEF4C1AFDC9AE7938146909F0D2D641A0D712CE18036B60FE5B8673D12.
Requirement body SHA256: 557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF. Normalize checkbox status when comparing five task sections with original briefs. Status/execution closeout documents have NOT been changed yet.

Prior review corrections:
1: 0 Critical /3 Important /1 Minor: known DN SET OF order, universal form bits, BC complete consumption, RFC full literal coverage. 0033 assertion RED (RFC coverage already passed) →0034 GREEN.
2: 0/2/0: remove schema-unknown opaque SET OF assumption (keep known DN order); validate nested AKI structure. 0042 RED →0043/0045 GREEN. 0044 failed new oracle, not GREEN: original zero-filled constructed[0] stays InvalidMaterial; separate well-formed OCTET representation stays Unsupported.
3: 0/3/0: outer SPKI consumption before unsupported key; UID BIT STRING and full TBS scan before profile return; AKI [2] implicit INTEGER minimality. 0053 RED →0054/0055/0056 GREEN.
4: 0/2/0: RSA known BIT STRING payload tail discarded by Go before Unsupported; AKI issuer GeneralName registeredID [8] implicit OID minimality. 0064 genuine RED also reproduced DSA payload/parameter tails and four malformed OID controls. 0065 focused GREEN. Valid RSA, DSA and registeredID controls retained.

Current correction only changes spki.go, extensions.go and parse_test.go from freeze 4:
- Exact MarshalPKIXPublicKey comparison now precedes unsupported-key classification for Go-marshalable key types. Pinned Go parses DSA but cannot marshal it: explicit complete DSA parameter (three INTEGER) and public INTEGER payload consumption/minimality plus zero unused bits precede Go parse and Unsupported. No new supported algorithms.
- AKI authorityCertIssuer GeneralNames registeredID primitive content is nonempty, minimally base-128 encoded and terminated. No new OID numeric-size/range policy, parent interpretation or trust claim.
- Public malformed/valid-unsupported RSA/DSA/registeredID regressions, including shared CA-wire malformed sentinel controls; all prior cases preserved. Review remaining known typed payload boundaries together, not just outer TLVs. Return all verified issues in this pass.

CURRENT acceptance receipts:
0066 exact 24-file format: post hashes match freeze5;
0067 exact format check: both sides match, empty output, exit0;
0068 full nodeca exit0 (5.974s);
0069 existing nodeleaf exit0 (10.620s);
0070 existing nodeleafkeys exit0 (4.828s);
0071 FuzzCADER exit0: 5 seeds /6 executions /no new interesting or crash;
0072 FuzzCASPKI exit0: 64 cached seeds /79 executions /no new interesting or crash.
Both sides of 0067–0072 and current hashes match freeze5. Historical freezes/receipts remain preserved. Native pinned Go1.26.5 windows/amd64 process-only, offline settings and ordinary120s/fuzz5s+30s flags unchanged. Recent startup/wall-clock delays have no established cause; no hard-real-time claim. Late Get-Process diagnostic in prior candidate had exit1/no matching process and no in-process UTC: NOT passing evidence, not reconstructed.

Review Focus (verbatim from plan):
- 声明 CA subject key 被误当 parent key：Task 4 的 TestCAPartialProofParentRoles 必须证明任意合形状 AKI 不执行 subject 派生，实际 parent/签名仍未认证。
- pathLen 省略被折叠为零：Task 3 的 TestCAPathLenPresence 固定 HasPathLen=false/0 与 true/0 的不同结果。
- parser 接受但 raw 值未完整消费：Task 2 的 TestCARawNestedTails 与 Task 3 的 TestCAExtensionCanonicality 覆盖 DN、BC、KU、SKI、AKI 的嵌套尾随/非最小表示。
- Go 前置拒绝被改写成后置 profile 类别：Task 4 的 TestCAParserPriority 与 TestCACombinedFailurePriority 固定完整检查顺序及不泄露动态错误。
- 清理/包装别名与取消产生旧有效结果：Task 1 的 TestCAMaterialLifecycle 及 Task 4 的 TestCACancellation 固定 shared owner、detached 值及失败无半成品。

The six fixed Pending obligations and partial-only owned CA shape, caller-declared subject P256 binding and full exact SPKI SHA256 SKI remain. No parent/signature/trust/time/deployment/bundle/leaf/runtime/provider capability. No old product/test/guard relaxations, new dependency/I/O/privatekey/clock/random/goroutine, or consumers.

All 16 prior declined domains have explicit author rulings/costs in progress.md. Opaque unknown signer primitive semantics and schema-dependent SET vs SET OF ordering are NOT certified; known DN SET OF order remains checked. Those opaque-signer exclusions do not waive known SPKI or recognized extension grammar. Global serial uniqueness / DN equivalence remain unproved.

Strictly read-only PowerShell. No tests, formatting, cache/file/Git/config/index/HEAD/branch writes, network, worktree/cleanup or subagents. Read-only Git may use GIT_OPTIONAL_LOCKS=0/core.fsmonitor=false and escalation for ownership; never safe.directory. Do all review yourself. Verify raw receipt evidence honestly; do not claim tests you ran.
Return Strengths; Critical/Important/Minor exact file:line with counterexample/impact/fix; Recommendations; every declined-to-judge domain+reason; evidence limits; clear CURRENT partial-increment verdict, not merge/main/C12 authorization. Return report in final only; no disk writes.

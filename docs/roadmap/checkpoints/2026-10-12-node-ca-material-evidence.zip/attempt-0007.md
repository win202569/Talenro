# Attempt 7 — Task 2 independent PowerShell SHA256 oracle

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator

Full wrapper and command:

$env:GOOS='windows'
$env:GOARCH='amd64'
$env:GOTOOLCHAIN='local'
$env:GOPROXY='off'
$env:GOSUMDB='off'
$env:GOAUTH='off'
$env:GOVCS='all:off'
$env:GOFLAGS='-mod=readonly'
$env:GOPATH='C:/Users/Lenovo/go'
$env:GOMODCACHE='C:/Users/Lenovo/go/pkg/mod'
$env:GOCACHE='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-11-node-ca-material/go-cache'
$caGo='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/go.exe'
$caFmt='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/gofmt.exe'
$caValues=@{
selfDER='308201aa30820151a00302010202020080300a06082a8648ce3d0403023020311e301c060355040313156e6f6465636120676f6c64656e207375626a656374301e170d3236303130313030303030305a170d3336303130313030303030305a3020311e301c060355040313156e6f6465636120676f6c64656e207375626a6563743059301306072a8648ce3d020106082a8648ce3d030107034200046b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c2964fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5a37b3079300e0603551d0f0101ff040403020204300f0603551d130101ff040530030101ff30290603551d0e042204205cd252fb0ce8932436faf8ccd1040981b89ee4ad6b9fe9e2a2b7e71aacb27cd3302b0603551d230424302280205cd252fb0ce8932436faf8ccd1040981b89ee4ad6b9fe9e2a2b7e71aacb27cd3300a06082a8648ce3d040302034700304402205ae2644aa860aa2f1f51ce08abe696ce3177b9b9d3b340b95c4e704bf6be213d022059a382e0975fa4d86e7a23d7616e46e1c170a0a2805e9a8836533d6931d750ec'
parentDER='308201aa30820150a00302010202020080300a06082a8648ce3d040302301f311d301b060355040313146e6f6465636120676f6c64656e20706172656e74301e170d3236303130313030303030305a170d3336303130313030303030305a3020311e301c060355040313156e6f6465636120676f6c64656e207375626a6563743059301306072a8648ce3d020106082a8648ce3d030107034200046b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c2964fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5a37b3079300e0603551d0f0101ff040403020204300f0603551d130101ff040530030101ff30290603551d0e042204205cd252fb0ce8932436faf8ccd1040981b89ee4ad6b9fe9e2a2b7e71aacb27cd3302b0603551d23042430228020dc0ce633dbcc913dafafa4b89ac44d8ce683fdfc3f60c8bdf21213b9f2b534ba300a06082a8648ce3d040302034800304502200affc6b941f40670d34501749d3832f06f2c13b6a30c878ef341181d50290a2e022100dd648176002caf39b715d7a3948a700be2381edaba6a1cdceaf714ba93dc8ba4'
SPKI='3059301306072a8648ce3d020106082a8648ce3d030107034200046b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c2964fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5'
subject='3020311e301c060355040313156e6f6465636120676f6c64656e207375626a656374'
selfIssuer='3020311e301c060355040313156e6f6465636120676f6c64656e207375626a656374'
parentIssuer='301f311d301b060355040313146e6f6465636120676f6c64656e20706172656e74'
rfcSPKI='3059301306072a8648ce3d020106082a8648ce3d030107034200047f7f35a79794c950060b8029fc8f363a28f11159692d9d34e6ac948190434735f833b1a66652dc514337aff7f5c9c75d670c019d95a5d639b72744c64a9128bb'
}; foreach($caName in @($caValues.Keys | Sort-Object)){ $caBytes=[Convert]::FromHexString($caValues[$caName]); Write-Output ($caName+' '+[Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($caBytes)).ToLowerInvariant()) }; $global:LASTEXITCODE=0

Observed receipt:

{
  "startUTC": "2026-10-11T18:10:28.7896330Z",
  "endUTC": "2026-10-11T18:10:28.8473414Z",
  "exit": 0,
  "GODEBUG": null,
  "output": [
    "parentDER 2855dc11d66743ca939fda0326b761d019e080796ce2a03fa789bdd47c857460",
    "parentIssuer afabbc957eb6dde91ccb5d672b0604358e2a6425a8e3befe5fc2d7ab19dc1858",
    "rfcSPKI 6d20896ab8bd833b6b66554bd59b20225d8a75a296088148399d7bf763d57405",
    "selfDER 3970d1ec0c4162e6087d7e50bbad778101dfcb8c9b0aa0d4746798807b7d140e",
    "selfIssuer d2db35c94e6d81fd8a560de3436b105edf829722d7bf67b20b4ffd47ef01e2ff",
    "SPKI 5cd252fb0ce8932436faf8ccd1040981b89ee4ad6b9fe9e2a2b7e71aacb27cd3",
    "subject d2db35c94e6d81fd8a560de3436b105edf829722d7bf67b20b4ffd47ef01e2ff"
  ],
  "before": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "0FD8654A9D72F7A971F9D27B604320D79BDFF32E44788B9A02B60047BF1206C2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "B25A08EBCFDF1E6A4CB411D55096BA1F042110CD4AD2620BA12B279EBD6DF3AE"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "73E58E73835AF2D086376F8B64843B9FEB60302D0DBF8E028D801E4F16809E6D"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "CE7897B3E614674D797185CF106C33EFF8933A3EFB0C53351A61796DE93E8142"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "29DB26EB5AD19BB278F84E2B29854C4FE652AD746D525213FAFE960D22491650"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "B16A2E994E9C463B5314FBD90A9EC3C1DB034977F73DBF0CF11847C2F0D6751B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "47D4074638ED72645AE388D6E1C0D3BEE9FFD8B0A13D2DC38E60DB8D91563457"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "90B03D198397F4EDD66D335F56DFC3C136EDB044E81808A96FDFAF3646045064"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "9892E3DDDBB8BD8BCF79C61DD22468362D9DFCB2A773B84E53FF545EB7DC53C9"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "2C0F8BAB3F2C1C6EEF2729FBC0DBCA2C04C678C95E8391E59D0E7DC773A22C50"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ],
  "after": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "0FD8654A9D72F7A971F9D27B604320D79BDFF32E44788B9A02B60047BF1206C2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "B25A08EBCFDF1E6A4CB411D55096BA1F042110CD4AD2620BA12B279EBD6DF3AE"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "73E58E73835AF2D086376F8B64843B9FEB60302D0DBF8E028D801E4F16809E6D"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "CE7897B3E614674D797185CF106C33EFF8933A3EFB0C53351A61796DE93E8142"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "29DB26EB5AD19BB278F84E2B29854C4FE652AD746D525213FAFE960D22491650"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "B16A2E994E9C463B5314FBD90A9EC3C1DB034977F73DBF0CF11847C2F0D6751B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "47D4074638ED72645AE388D6E1C0D3BEE9FFD8B0A13D2DC38E60DB8D91563457"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "90B03D198397F4EDD66D335F56DFC3C136EDB044E81808A96FDFAF3646045064"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "9892E3DDDBB8BD8BCF79C61DD22468362D9DFCB2A773B84E53FF545EB7DC53C9"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "2C0F8BAB3F2C1C6EEF2729FBC0DBCA2C04C678C95E8391E59D0E7DC773A22C50"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ]
}

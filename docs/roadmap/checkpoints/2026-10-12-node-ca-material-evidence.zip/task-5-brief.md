## Task 5: 隔离守卫、fuzz、最终验证与独立审查

**Files:** 新建 boundary_test.go/fuzz_test.go；仅在新包内必要修正。完成后允许新增 `docs/roadmap/2026-10-11-node-ca-material-execution.md`、更新 current-status 顶部，以及本 spec/plan 的顶部状态/checkbox；不改旧需求正文/执行记录。

**Interfaces:** 产品公开 surface 固定为 §1；无消费者开放。FuzzCADER/FuzzCASPKI 是测试入口，其他辅助函数不导出。

- [ ] **Step 1: 写守卫失败测试及fuzz测试入口。** TestCAImportsBoundary/TestCAAPI/TestCAConsumers/TestCAFileInventory/TestCAParseOwnershipFlow/TestCANoRuntimeCalls。import/member 白名单仅 bytes(Clone/Equal)、context(Context)、errors(New)、crypto/sha256(Sum256)、crypto/ecdsa(PublicKey)、crypto/elliptic(P256)、crypto/x509(Certificate/ParseCertificate/ParsePKIXPublicKey/MarshalPKIXPublicKey/KeyUsageCertSign/KeyUsageCRLSign)、encoding/asn1(ObjectIdentifier/Unmarshal/RawValue)、time(Time)、contracts(Digest)；必要key/time/oid实例方法仅执行本计划检查，不增加签名/I/O能力。
  API/字段/枚举/error vars与24文件精确核对。产品禁止 Verify/CheckSignature*、pool/签发/时钟/随机/私钥/并发/serialization及旧材料包import。Input.DER 是必需输入字段，不可因粗糙selector禁令误判为导出DER accessor。对导入别名/方法值/局部遮蔽/伪装selector、额外API/兄弟包/外部测试consumer各给真实拒绝case；同目录同package测试才有测试例外。
  同一步先建立 fuzz_test.go：FuzzCADER 以新golden及空/嵌套长度种子调用Parse并Clear成功结果；FuzzCASPKI 以RFC SPKI及新key/非法参数种子调用checkDeclaredSPKI。超外层预算样本验证preflight分类，不在产品克隆超限bytes；成功Material必有六Pending，error必无有效Material。固定24文件检查的RED不以遗漏fuzz文件或语法错误冒充guard行为失败。
- [ ] **Step 2: 记录守卫 RED。** Run: `& $caGo test ./internal/nodecontrol/nodeca -run '^(TestCAImportsBoundary|TestCAAPI|TestCAConsumers|TestCAFileInventory|TestCAParseOwnershipFlow|TestCANoRuntimeCalls)$' -count=1 -p=1 -timeout=120s`；写case先于guard实现，预期缺guard helper或注入违规被错误接受，不人为破坏旧守卫。
- [ ] **Step 3: 实现测试守卫。** guard 精确目录/package/path，read-only walk扫描消费者；失败清理责任在首个clone前、Parse移交前后上下文/有效状态的有限AST检查。测试guard本身可以读仓库，产品不能I/O；它只给出有限AST证据，不声称形式证明或观测克隆时OOM。
- [ ] **Step 4: 记录守卫 GREEN。** 重跑 Step 2 同命令，预期 exit0；随后只格式化24个新Go文件。精确文件集合及格式化命令：
  ```powershell
  $caNames='doc.go input.go errors.go budget.go owned.go material.go spki.go der.go raw_certificate.go ca_fields.go extensions.go parse.go fixtures_test.go budget_test.go owned_test.go material_test.go spki_test.go der_test.go raw_certificate_test.go ca_fields_test.go extensions_test.go parse_test.go boundary_test.go fuzz_test.go'.Split(' ')
  [string[]]$caPaths=@($caNames | ForEach-Object { Join-Path 'internal/nodecontrol/nodeca' $_ })
  [Array]::Sort($caPaths,[StringComparer]::Ordinal)
  & $caFmt -w $caPaths
  ```
  记录真实前后hash及退出码，不格式化旧文件或不受限目录。
- [ ] **Step 5: 记录格式检查。** 使用 Step 4 同一精确路径数组，Run: `& $caFmt -l $caPaths`；预期无输出且exit0；有输出即不通过，不能只看退出码。
- [ ] **Step 6: 运行五条最终限定Go命令。** 全部使用 §2 完整离线wrapper，逐条记录真实退出码；没有外推全仓库、DB/Docker、race、硬件或production验收。
  ```powershell
  & $caGo test ./internal/nodecontrol/nodeca -count=1 -p=1 -timeout=120s
  & $caGo test ./internal/nodecontrol/nodeleaf -count=1 -p=1 -timeout=120s
  & $caGo test ./internal/nodecontrol/nodeleafkeys -count=1 -p=1 -timeout=120s
  & $caGo test ./internal/nodecontrol/nodeca -run '^$' -fuzz '^FuzzCADER$' -count=1 -p=1 -parallel=1 -fuzztime=5s -timeout=30s
  & $caGo test ./internal/nodecontrol/nodeca -run '^$' -fuzz '^FuzzCASPKI$' -count=1 -p=1 -parallel=1 -fuzztime=5s -timeout=30s
  ```
  每条预期 exit0，fuzz无发现的crash/行为断言失败；限定fuzz通过不等于没有所有潜在parser缺陷。
- [ ] **Step 7: 冻结增量并请求一次 fresh 只读审查。** Native 下作者实现五任务后，由当前最有能力可用模型 gpt-6-astra、xhigh 的新审查者检查 spec/plan、24文件、完整证据/旧基线与五条最终命令。本步是计划内未来 delegation，不在规划时启动。审查对象为本增量，不冒充重新审完所有历史dirty改动；禁止reviewer改代码/Git或降低Pending。记录Critical/Important/Minor及证据限制。SDD方法按其技能增加各任务独立门槛，不取消最终整增量审查。
- [ ] **Step 8: 处理审查结果。** Critical/Important 未解决不得宣称完成；Minor也记录并修复本范围。源码改变则原冻结hash/审查失效，重跑受影响检查及全部五条最终命令、再次fresh审查；跨范围需求先修订审批，不能借修复改旧profile/provider。无审查资源时保存未审开发状态，不称完成或自行降级模型冒充原审查。
- [ ] **Step 9: 保存真实交付记录。** execution 文档逐项列环境、所有attempt、RED/GREEN、最终五命令、格式/source hashes、审查及限制；current-status只新增本增量顶部段，保留CA/leaf实际信任、原六Pending和Task10/B01/C12/main阻塞。spec/plan只更新状态/checklists。核对所有旧文件/testdata/向量、branch/HEAD/index/status及额外文件exact范围；记录均真实后交付，不提交、推送、合并或删除证据。

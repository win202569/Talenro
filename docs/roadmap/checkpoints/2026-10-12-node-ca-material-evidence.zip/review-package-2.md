# Node CA Material — read-only increment review package 2

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Approved Native plan: docs/superpowers/plans/2026-10-11-node-ca-material.md
Spec: docs/superpowers/specs/2026-10-11-node-ca-material-design.md

You are a fresh independent reviewer of revision 2, not a follow-up to the previous reviewer. Base and HEAD remain 6752b9612a00b9d6b0bf87ae8dd95063f6b056ee. This increment is untracked; Git commit-range diff would be empty. Review all exact24 sources in frozen-sources-2.json (12 product/12 tests), full spec/plan, baseline.json, progress.md and all41 command receipts. Do not re-review the unrelated historic dirty branch, nor infer readiness to merge/C12.

Baseline:735 old files/340 original dirty entries, 28 old testdata paths. pre-review-2-baseline-check.json shows only allowed spec/plan state edits among old files, 364 current dirty entries, HEAD/branch/index unchanged. Spec requirement body remains SHA256 557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF. No nodeca/testdata.

Full receipts attempt-0001.md through0041.md, no gaps. Prior failures/deviations remain retained with diagnosis and rulings, including Linux-target test executable on Windows, syntax failure not RED, guard false positives, and now-superseded depth32 cap. review-1.md is author transcription of original fresh review (0 Critical/3 Important/1 Minor), not a new independent report. 0033 reproduces the three Important issues; RFC literal oracle coverage is already PASS on0033 and is not misrepresented as a product failure. 0034 targeted GREEN. Read raw_certificate.go, der.go, extensions.go and four new parse_test.go cases carefully, and inspect the entire increment for remaining issues.

Revision2 exact24 format0035; check0036 empty output/exit0. All five final current-source limited commands0037–0041 exit0 (full wrapper and hashes in receipts):
0037 nodeca;0038 nodeleaf;0039 nodeleafkeys;0040 FuzzCADER five seeds/only6 executions;0041 FuzzCASPKI35 cached seeds/65,771 executions/18 new coverage-interesting cases/53total. No crash; finite fuzz is not exhaustive.
Reviewer must verify source/finalreceipt hashes match frozen-sources-2, baseline protections, oracle independence and that all41 evidence files are present/consistent. Tests are author evidence; do not claim you reran them.

Focus: subject key not parent key; HasPathLen preserves absent vs zero; nested raw values fully consumed including DN/unknown signature parameters/BC/KU/SKI/AKI; Go-front rejection/error priority; shared-owner/Clear/cancel/failure no stale valid result; finite AST import/API/consumer/ownership safeguards (not formal proof).
No signature/chain/parent/current-time/deployment/bundle/leaf/runtime trust; six fixed Pending remain. No new consumer/dependencies/runtime/I/O/private keys/clocks/goroutines.

Read-only only: no tests (cache writes), files, Git/config/index/HEAD/branch changes, cleanup, temporary worktree, networking or subagents. Use read-only PowerShell. If necessary read-only Git escalation with GIT_OPTIONAL_LOCKS=0/core.fsmonitor=false; do not set safe.directory.
Output: Strengths; Critical/Important/Minor exact path:line, reproduction and impact; Recommendations; every Declined-to-judge domain with reason; verdict for this partial increment, not merge authorization. Spec silence does not excuse reasonable-user defects, but explicit non-goals must not be silently implemented or counted as trust guarantees.


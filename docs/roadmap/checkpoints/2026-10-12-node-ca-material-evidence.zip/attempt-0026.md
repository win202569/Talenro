# Attempt 26 — Task 5 format exactly 24 new Go files

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator

Full wrapper and command:

$env:GOOS='windows'
$env:GOARCH='amd64'
$env:GOTOOLCHAIN='local'
$env:GOPROXY='off'
$env:GOSUMDB='off'
$env:GOAUTH='off'
$env:GOVCS='all:off'
$env:GOFLAGS='-mod=readonly'
$env:GOPATH='C:/Users/Lenovo/go'
$env:GOMODCACHE='C:/Users/Lenovo/go/pkg/mod'
$env:GOCACHE='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-11-node-ca-material/go-cache'
$caGo='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/go.exe'
$caFmt='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/gofmt.exe'
$caNames='doc.go input.go errors.go budget.go owned.go material.go spki.go der.go raw_certificate.go ca_fields.go extensions.go parse.go fixtures_test.go budget_test.go owned_test.go material_test.go spki_test.go der_test.go raw_certificate_test.go ca_fields_test.go extensions_test.go parse_test.go boundary_test.go fuzz_test.go'.Split(' ')
[string[]]$caPaths=@($caNames | ForEach-Object { Join-Path 'internal/nodecontrol/nodeca' $_ })
[Array]::Sort($caPaths,[StringComparer]::Ordinal)
& $caFmt -w $caPaths

Observed receipt:

{
  "startUTC": "2026-10-11T18:24:01.7121258Z",
  "endUTC": "2026-10-11T18:24:01.8333184Z",
  "exit": 0,
  "GODEBUG": null,
  "output": [],
  "before": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\boundary_test.go",
      "sha256": "BB509729C8C8EE3C423E8CC556810FBFCC549E1D6AA396ED685D36937E3C2314"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "0FD8654A9D72F7A971F9D27B604320D79BDFF32E44788B9A02B60047BF1206C2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "B25A08EBCFDF1E6A4CB411D55096BA1F042110CD4AD2620BA12B279EBD6DF3AE"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields.go",
      "sha256": "85C064224B7509E5C03D236EBB915CA7C953879322E70053B4FE1F680414BFF1"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields_test.go",
      "sha256": "00C16186C82F7AD146C43692DDFB5D32D81A4FDB4BE10392C9700A073EA48356"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der.go",
      "sha256": "C3762DBCA4C6470391EB4A326F2635B3551EB155AB06170C2A61EFDCF2F569A4"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der_test.go",
      "sha256": "FBC0BF94FAFB3FF0BB193B3610B7A06885B2F3AAC6CA8202560EC493611ECFDB"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "73E58E73835AF2D086376F8B64843B9FEB60302D0DBF8E028D801E4F16809E6D"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions.go",
      "sha256": "2E2687C36D4139FE276A2171C8BFE047BDC606F65DE01EC2677DF7F4322119C1"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions_test.go",
      "sha256": "910AE226B66FA1D093E4A0A470B5F5B9332FE2263E9BA5D02195464F1BDB1217"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "6488399C6336D4760027A7AC6F2AE0BA23B94A7298D692FA7B7FC3F435FCEF5E"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fuzz_test.go",
      "sha256": "A76C32E681F518E72B9532D3FF1FA014A4EF3D380A6E5D7D08CC9AC5D9B36E47"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "29DB26EB5AD19BB278F84E2B29854C4FE652AD746D525213FAFE960D22491650"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "B16A2E994E9C463B5314FBD90A9EC3C1DB034977F73DBF0CF11847C2F0D6751B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "47D4074638ED72645AE388D6E1C0D3BEE9FFD8B0A13D2DC38E60DB8D91563457"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "90B03D198397F4EDD66D335F56DFC3C136EDB044E81808A96FDFAF3646045064"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "9892E3DDDBB8BD8BCF79C61DD22468362D9DFCB2A773B84E53FF545EB7DC53C9"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse.go",
      "sha256": "EDDAF613FF26381DF3C18BA50F754975B0EB2A3B21FCA653B9F96C7C3C44BDCA"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse_test.go",
      "sha256": "C33AEB19AF79C7018C972FC0966E6A5A652270F54A652FF1DCD35B63B19DDAFE"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate.go",
      "sha256": "B2679882C736A77BC27B21867BDA7859FD79AE8876A55883EB940279DBC8F663"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate_test.go",
      "sha256": "5FC91E373FE581D07A78EE7C7BA3E4D802A3CA2BFDEF1599C6A10EBC03DB28E4"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki.go",
      "sha256": "6ED6BD4B96B3EE7605E3691857CF96E32156C5A3D6594EFF68D71288D21BF135"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki_test.go",
      "sha256": "5FBE1C262FFD72FD12559D34184B98B13E7C94AC35B45B61D27D7FCE856445CC"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "1C4B3C6DB7E84D5592601B4EDB34F5B12C2A6FF42A8F0CA3E6860EFBA7B04F71"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ],
  "after": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\boundary_test.go",
      "sha256": "F644256710F4BE7302017A1D375C4BB5E5926E0102A2CE7C2FDAE23893FBD05B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "8E3B9F45C326BCD2BD0174F50FDBE6BC3437905CCF11932A8B3EE5B5599DAF57"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "2B84D68C9D56E9CD6167239EC20AE9E929642BA73A6736B260BED7AC6E4FCFEB"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields.go",
      "sha256": "C1A91AC97C109C48154485A505929789AEB22DC9BD69EB0666377009CDFF0AD2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields_test.go",
      "sha256": "4A1EC88F190E91D7998C167CBBCF4D2790F5BC918C96272A028C6D950CF68725"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der.go",
      "sha256": "66E7D45938C751538A3BE341EA51D22F392F409740E9CF65ACBACCFDC1EA00B0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der_test.go",
      "sha256": "37C4113558FA4F62677AC20AEA1ED13314EE018537D0ECB7C808479B8FF671E0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "893FEC3E470AF2F9C2025740A3A6E5DD64D85572564F03E634740C6E95847A62"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions.go",
      "sha256": "FB23C45893D77CAF176D4B62361665666D647A804C11285BEDB5D1E0B361E5C1"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions_test.go",
      "sha256": "7B84D11A0B96BD1C4D3D76C87015BFDAEEB368A8B49560DFA2E835F61427519E"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "E29AA04ACAC3EACF9524426F274E8C4F93A002BA74A9598D6EE582BD543B123C"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fuzz_test.go",
      "sha256": "EB827AD3EE693F4CE0DBE03EBE0FC6340B16284AE499743EA7BDD245B91B0C14"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "5A6E979C7B1E84357CEBCC26F443D4144F946750C5095976392A94F968C7EB52"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "92E2A18760E9C1C5C90256CA5442A1432A9F42A6E2647A55BCC093A58D68EF47"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "981B6735574D28EA53A61A68CFA7A72DA2B761B6E8D90FABD1EB1344A9D7123A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "787211003166E96697199D16DD5055DA8FF4BDBA9D1A731540EB0187C7B3A07A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "A7511F813D4ADB678A2FA23E1EC05FB96E9A7A6948BEE448811DD1EC1F947793"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse.go",
      "sha256": "AA4BE70D7531000FCB8CB1834FB9CF88AC2633FF51383E81574CABD51A3C5833"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse_test.go",
      "sha256": "ADEAB3811F30B7238422C1086DA5E0BCA4F65DDC469DB2C9E1A4EA6229900361"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate.go",
      "sha256": "2C427C8A6D47A0F50E9C2C84AE6BB72795A9B3ADB1BA45609D268E859CBAD294"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate_test.go",
      "sha256": "79AE777980EAF1485A962766AD9CE2D44A2C398AB247655750D8D93B63A691A7"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki.go",
      "sha256": "9EC27E1C2C748B4DA554EDDB5A8E5366359A24190AD10EC92D7AD5BD3903FF3F"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki_test.go",
      "sha256": "62DB5B59B1E11111E33E68E84943401747C5912BE8B89D6FAB3C8E20FBC5251D"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "1C4B3C6DB7E84D5592601B4EDB34F5B12C2A6FF42A8F0CA3E6860EFBA7B04F71"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ]
}

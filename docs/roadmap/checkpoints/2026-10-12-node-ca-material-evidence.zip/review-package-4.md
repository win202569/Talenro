# Node CA Material — fresh read-only review package 4

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Full approved spec: docs/superpowers/specs/2026-10-11-node-ca-material-design.md
Full approved Native five-task plan: docs/superpowers/plans/2026-10-11-node-ca-material.md
CURRENT sources: exact24 files in frozen-sources-4.json (12product/12tests).
Base=HEAD=6752b9612a00b9d6b0bf87ae8dd95063f6b056ee; no commits. Empty commitrange cannot review untracked increment. Review whole24file increment, not unrelated historical dirtybranch.

All evidence belongs to .superpowers/sdd/2026-10-11-node-ca-material/:
baseline.json735oldfiles/340originaldirtyentries (28nested plus16root testdata); progress.md allauthorrulings; fiveoriginalbriefs; all63continuousattemptreceipts; historical4sourcefreezes and prior3reviewreports; pre-review-4-baseline-check.json. Only permitted spec/plan state/checklist edits among oldfiles; no old source/test/testdata/config changes, no new consumers. Specbodyhash557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF unchanged.

Prior reviews:
review1:0Critical/3Important/1Minor (DNorder,universalforms,BCtail,RFC literalcoverage), fixes0033RED→0034GREEN; coveragealreadyPASS0033 not productRED.
review2 exactreport:0Critical/2Important/0Minor (opaqueSETvsSETOF,malformednestedAKI);0042RED→0043/0045GREEN.0044failed due early newpackageoracle expectingUnsupportedformalformedconstructed[0] EOCzeros; originalinputretainedInvalid pluswellformedexcludedOCTETcontrol. Priorfixesconfirmedbyreview3.
review3 authortranscription review-3.md (originalreportretainedinconversation):0Critical/3Important/0Minor.0053 genuineRED:
I1declaredEd25519SPKI with nestedtail acceptedGo but wrongUnsupported;
I2UID malformedBITSTRING/rawTBS tail hiddenbyearlyUnsupported;
I3knownAKIimplicitserial empty/nonminimal bypasseduniversalINTEGERchecker.
0054SPKIknown grammar consumed beforeunsupportedkeyclassificationGREEN;0055UIDBITSTRINGandfullTBSscannedbeforeprofile rejectionGREEN;0056knownimplicitAKIserial minimalityGREEN. All valid unsupportedcontrols and earlier regressions retained. No supportedalgorithm/parent/signature/trust expansion.

CURRENT verification only:
0057 exact24format posthash;
0058 exact24formatcheck emptyoutput/exit0;
0059 fullnodeca exit0 (4.954s);
0060 oldnodeleaf exit0 (5.771s);
0061 oldnodeleafkeys exit0 (4.260s);
0062 DERfuzz exit0,5seeds/7executions/no interesting/crash;
0063 SPKIfuzz exit0,64cachedseeds/107executions/no interesting/crash.
Fixed approved offlinewrapper/ordinary120s/fuzz5s+30s flags unchanged. Recent process-start/overallwallclock delays grew, cause unestablished; test bodies finished withinparameters. Late Get-Process readonlydiagnostic had no matchingprocess/exit1, not passingverification. Allfailuresremainactualreceipts with pairedhashes/UTC/fulloutput. Do not claim exhaustivefuzz (bothcurrentrunslimited) or reviewertestexecution. No newtestdata.

Independently verify all63rawreceipts (parsecompletecontent but summarize repeatedhasharrays), final0058–0063 pre/postsourcehashes matchfreeze4, 0057post matchesfreeze4; historicalfreezesmatchtheirhistoricalreceipts. Hashall735oldfiles/24currentfiles, verifyHEADbranchindex/status exactly+24. Requirementbody and normalizedfivebriefs unchanged. Goldens/literaloraclesindependent. No finalstatus/executiondocwritesyet.

Review Focus (verbatim from approved plan):

- 声明 CA subject key 被误当 parent key：Task 4 的 TestCAPartialProofParentRoles 必须证明任意合形状 AKI 不执行 subject 派生，实际 parent/签名仍未认证。
- pathLen 省略被折叠为零：Task 3 的 TestCAPathLenPresence 固定 HasPathLen=false/0 与 true/0 的不同结果。
- parser 接受但 raw 值未完整消费：Task 2 的 TestCARawNestedTails 与 Task 3 的 TestCAExtensionCanonicality 覆盖 DN、BC、KU、SKI、AKI 的嵌套尾随/非最小表示。
- Go 前置拒绝被改写成后置 profile 类别：Task 4 的 TestCAParserPriority 与 TestCACombinedFailurePriority 固定完整检查顺序及不泄露动态错误。
- 清理/包装别名与取消产生旧有效结果：Task 1 的 TestCAMaterialLifecycle 及 Task 4 的 TestCACancellation 固定 shared owner、detached 值及失败无半成品。




Partial-only contract: exact owned CA shape + caller-declaredsubjectP256SPKI/full32rawSPKI SHA256SKI, sixfixedPending. Not parent/trust/time/deployment/bundle/leaf/runtime. No consumer/provider/oldguard relaxation/dependencies/productI/O/privatekey/clocks/random/goroutines. Sharedowner/Clear/cancel/detachedSummary/pathLenpresence preserved.

Progressledger rules on all16 prior declineddomains, plus executiondecisions and correctedearlynewtestoracle. Unknownsignerparameter schema-dependentSETordering/fulluniversalprimitivecontent semantics are NOT certified under narrowGoaccepted/minimalconsumedTLV contract; known DN SET OF order remainschecked. Globalserialuniqueness/DNtextnormalization also unproved. Specsilence is notpermissiontoignore reasonableuser defects; do not silently widenexplicitnongoals.

Read-only PowerShell only: no tests/cachewrites/filepatches/Gitconfig/index/HEAD/branch writes/network/worktrees/cleanup/subagents. ReadonlyGit ifneeded viaGIT_OPTIONAL_LOCKS=0/core.fsmonitor=false and escalation, neversafe.directory. Do allreview yourself.
Return Strengths; Critical/Important/Minor with exactfile:line, precisecounterexample/impact/fix; Recommendations; everyDeclined-to-judge domain+reason; evidencelimits; clearCURRENTpartialincrementverdict, NOTmerge/C12/mainauthorization. Reviewerreportreturninfinalonly,nodiskwrite.

# Fresh read-only review 2 — returned report

Reviewer: /root/ca_material_final_review_2; gpt-6-astra/xhigh; fresh context.
The report below is the exact final text returned by the reviewer, not an author-created verdict.

## Strengths

- All 24 frozen sources/tests were reviewed. Ownership, shared `Clear`, cancellation handoff, subject-key binding, pathLen presence, and the six fixed Pending obligations are well separated.
- The original counterexamples are addressed, and the RFC 7093 test now checks the literal full-length digest and SKI independently of product-derived expectations.
- Evidence is consistent: all 41 receipts exist; format check 0036 and final commands 0037–0041 match the current frozen hashes. Those author-recorded commands exited 0.
- Independently hashing all 735 baseline files found only the approved spec/plan changes. All 28 old testdata files are unchanged. HEAD, branch, and index match baseline; the status increase is exactly the 24 new files.

## Issues

### Critical

None found.

### Important

1. **Opaque SET parameters are incorrectly treated as SET OF.**

   File: [der.go:114](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeca/der.go:114)

   Source-derived reproduction: replace both signature AlgorithmIdentifiers in the golden certificate with:

   `300e06032a03043107a0020500810101`

   This contains unknown OID `1.2.3.4` and parameters:

   `31 07 a0 02 05 00 81 01 01`

   These parameters are valid DER for `SET { a [0] EXPLICIT NULL, b [1] IMPLICIT INTEGER }`: SET components use canonical tag order, so tag 0 precedes tag 1. The pinned Go parser accepts the field and maps the algorithm to Unknown. The new walker rejects it because complete-octet comparison sees `81 < a0`.

   Impact: valid opaque parameters permitted by §5.1 are rejected through an unapproved schema assumption. This is distinct from DN RDNs, whose schema is known to be SET OF and whose new ordering check is correct.

   Fix: retain RDN SET OF ordering, but do not impose SET OF ordering on schema-unknown parameter SETs. Preserve schema-independent tag/length and nested-consumption checks; add this positive regression.

2. **Malformed nested AKI content is classified as an unsupported profile before being validated.**

   File: [extensions.go:99](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeca/extensions.go:99), rejection at [extensions.go:106](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeca/extensions.go:106)

   Source-derived reproduction: replace the golden AKI inner value with:

   `302580205cd252fb0ce8932436faf8ccd1040981b89ee4ad6b9fe9e2a2b7e71aacb27cd3a101ff`

   This preserves the correct primitive keyIdentifier and adds `[1]` authorityCertIssuer containing an incomplete nested element, `ff`.

   The pinned Go `parseAuthorityKeyIdentifier` returns the first keyIdentifier without examining the remaining field. This implementation reads the outer `[1]` TLV but never its malformed content, then returns `ErrUnsupportedCAProfile` because there are two elements.

   Impact: recognized extension material violates the promised nested-consumption and malformed-versus-interpretable-profile distinction in §§5.2, 5.3 and 7.2. It is rejected, not accepted, but with the wrong fixed error contract—analogous to the repaired BasicConstraints issue.

   Fix: validate nested structural encoding before the AKI profile rejection. Add this malformed case expecting `ErrInvalidMaterial`, while retaining `ErrUnsupportedCAProfile` for structurally valid excluded issuer/serial forms.

### Minor

None found.

## Recommendations

- Address the two findings with focused regression tests, then repeat the approved format check, five final commands, freeze, and fresh review.
- Preserve the explicit fuzz limitation: DER fuzz executed only six inputs; it provides very little exploratory coverage.
- Complete status-document closeout only after the remaining review findings are resolved.

## Declined to judge

Each item requires an explicit author ruling rather than silently disappearing:

1. CA signature authenticity and signer policy — explicitly Pending.
2. Parent/chain/root, AKI-parent correspondence, self-signing and actual path constraints — no authenticated parent input.
3. Trusted current validity, maximum lifetime and backdating policy — explicitly deferred.
4. Deployment provenance, trust domain, purpose and authorization — outside this material layer.
5. Bundle status, revocation, compromise, versions/high-water and rollback — explicitly Pending.
6. CA-leaf issuer/signature/AKI relations, private-key possession, installation and runtime authority — no corresponding inputs or authorized consumer.
7. Production-provider compatibility and migration — no provider acceptance or migration commitment.
8. Concurrent input mutation or concurrent Clear/read — expressly unsupported.
9. Fatal OOM/crashes, unreachable parser/runtime copies and hard-real-time cancellation — expressly excluded guarantees.
10. Formal completeness of AST safeguards — finite checks plus actual-source inspection, not proof.
11. Exhaustive fuzzing, resource ceilings, Linux, race, DB/Docker and full-repository behavior — outside the approved limited native evidence.
12. Unrelated historic dirty changes and Task10/B01/C12/main readiness — increment-only scope.
13. Full universal primitive-content validation inside opaque unknown parameters — not graded as an additional defect under the narrow §5.1 parser-accepted field encoding and §5.2 consumed/minimal-TLV contract. For example, equal AlgorithmIdentifiers `300806032a03040c01ff` or `300806032a0304160180` reach Unknown in the pinned parser and are accepted by this walker. Consequently, this review does **not** certify complete universal DER-value validity there.
14. Schema-dependent canonical ordering of opaque SET versus SET OF — impossible to establish without the parameter schema. That limitation does not justify choosing SET OF rules and rejecting the valid SET example above.

## Evidence limitations

I ran no tests, formatting commands, networking, or writes. Reproductions above are source-derived, including inspection of the pinned Go parser. Receipt outcomes are author evidence whose file/hash consistency I independently checked, not executions I witnessed or reran. Finite fuzz success is not exhaustive assurance.

## Assessment

**Partial increment needs fixes: 0 Critical, 2 Important, 0 Minor.**

The partial-result and isolation architecture remains sound, but the two encoding/error-contract issues prevent completion of this frozen revision. This is not merge authorization or C12 readiness assessment.

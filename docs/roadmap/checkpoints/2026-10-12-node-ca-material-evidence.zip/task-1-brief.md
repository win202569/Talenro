## Task 1: 输入合同、预算与两 buffer 生命周期

**Files:** 新建 doc.go/input.go/errors.go/budget.go/owned.go/material.go；测试 budget_test.go/owned_test.go/material_test.go。

**Interfaces:** 产生 §1 公开类型、error、两个 Material 方法；私有 `preflight(ctx context.Context,in Input) error`、`ownInput(in Input) *owner`、`(*owner).clear()`。此任务不提供 Parse stub，不把手造 owner 当 CA 正例。

- [ ] **Step 1: 保存获准执行基线。** 核对计划批准与方法选择，完整阅读 spec/plan；记录当前全部既有文件及向量哈希、Git 基线、两个批准文档哈希，确认新源码/证据目录归属，然后建立专属证据/cache。
- [ ] **Step 2: 写失败测试。** TestCAPreflight 覆盖 DER 0/1/65536/65537、SPKI 0/1/8192/8193；顺序为 nil context→已取消→任一超限→空值。TestCAFixedErrors 检查五个独立固定 sentinel/messages。TestCAOwnedInput 用共享 backing/subslice 检查两份独立克隆与 clear；TestCAMaterialLifecycle 检查 nil、零值、包装拷贝、detached Summary、幂等与全部字段清零。
  ```go
  if !errors.Is(preflight(context.Background(), Input{DeclaredSPKI: make([]byte,8193)}), ErrLimitExceeded) { t.Fatal("budget priority") }
  o := ownInput(Input{DER: []byte{1,2}, DeclaredSPKI: []byte{3,4}})
  a,b := o.der,o.declaredSPKI; o.valid=true
  m := &Material{owned:o}; copied:=*m; m.Clear()
  if copied.Summary()!=(Summary{}) || !bytes.Equal(a,[]byte{0,0}) || !bytes.Equal(b,[]byte{0,0}) { t.Fatal("shared lifecycle") }
  ```
- [ ] **Step 3: 记录真实 RED。** Run: `& $caGo test ./internal/nodecontrol/nodeca -run '^(TestCAPreflight|TestCAFixedErrors|TestCAOwnedInput|TestCAMaterialLifecycle)$' -count=1 -p=1 -timeout=120s`；预期缺本任务声明而失败。
- [ ] **Step 4: 最小实现。** preflight 不复制/解析；ownInput 内部先建立失败/panic 清理，再逐份 bytes.Clone，初始 valid=false；Material 方法 nil-safe，共享 owner。成功 handoff 和 clear 不保留调用方 slice。
- [ ] **Step 5: 记录 GREEN。** 重跑 Step 3 同命令，预期 exit0；再 `& $caGo test ./internal/nodecontrol/nodeca -count=1 -p=1 -timeout=120s`，预期当前合同测试 exit0，不称为 CA Parse 完成。
- [ ] **Step 6: 保存阶段检查点。** 记录 RED/GREEN/源码 hashes，核对旧基线，更新本计划本任务 checkbox；不暂存或提交。

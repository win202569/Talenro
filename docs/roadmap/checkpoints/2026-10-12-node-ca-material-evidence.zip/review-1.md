# Fresh read-only review 1 — gpt-6-astra, xhigh

Result: 0 Critical, 3 Important, 1 Minor. Needs fixes; not complete.
All 24 files/freeze and receipts0028–0032 independently verified; all735 baseline files independently hashed, only approved spec/plan changed; branch/HEAD/index and spec-body unchanged. Reviewer ran no Go commands or writes.

Important 1 — raw_certificate.go:31: unsorted multi-valued RDN SET OF accepted. Subject counterexample 301631143008060355040b0c0162300806035504030c0161 (OU=b then CN=a). Pinned Go and raw scanner accept; must reject descending complete ATV encodings, not normalize.
Important 2 — der.go:86: constructed universal primitive tags bypass primitive checks. Both algorithms 300706032a03042100 (unknown OID + constructed BOOLEAN) accepted; primitive SEQUENCE1000 also accepted. Validate universal primitive/constructed forms; retain valid Unknown/deep parameters.
Important 3 — extensions.go:128: BC30050201010500 (omitted cA=false, pathLen1, illegal NULL tail) returns Unsupported before consuming the grammar. Pinned parser tolerates tail. Must InvalidMaterial; add omitted-Boolean valid/truncated/nonminimal/tail cases.
Minor 4 — fixtures_test.go:25/spki_test.go:28: rfcSPKIHash declared but never asserted in successful CA SKI/digest projection. Golden hashes already correct; missing specifically approved external vector, not current product defect. Substitute RFC SPKI+literal RFC SKI, assert full32 digest+ID, do not authenticate unchanged signature.

Strengths: partial boundary, arbitrary AKI not subject-bound, six Pending, ownership/cleanup, pathLen presence, exact evidence/old scope.
Recommendations: focused TDD repairs, preserve freeze/receipts; new freeze, all five final commands and fresh review after source edits; extremely limited DER fuzz exploration remains noted.

Declined to judge, each explicit approved exclusion:
1 CA signature and signer policy.
2 Parent/chain/root/AKI-parent/self-sign/path constraints.
3 Trusted current validity/max lifetime/backdating.
4 Deployment provenance/domain/purpose/authorization.
5 Bundle/revocation/compromise/version/high-water/rollback.
6 CA-leaf/signature/issuer/AKI/private-key/installation/runtime.
7 Production-provider compatibility/migration.
8 Concurrent input mutation/Clear/read.
9 Fatal OOM/crash/unreachable parser/runtime copies/hard real-time.
10 Formal completeness of finite AST guards.
11 Exhaustive fuzz/resource ceilings/Linux/race/DB/Docker/full repo.
12 Unrelated historic dirty changes and Task10/B01/C12/main readiness.

Assessment: partial LOCAL increment needs fixes; no merge or acceptance authority. Counterexamples established by source tracing including pinned Go, not reviewer-run tests.

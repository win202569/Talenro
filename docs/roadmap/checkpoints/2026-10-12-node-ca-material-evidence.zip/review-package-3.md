# Node CA Material — fresh read-only review package 3

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Full approved spec: docs/superpowers/specs/2026-10-11-node-ca-material-design.md
Full approved Native plan: docs/superpowers/plans/2026-10-11-node-ca-material.md
Current exact24-file freeze: frozen-sources-3.json (12 product/12 tests). Review every file. This is untracked work; base=HEAD=6752b9612a00b9d6b0bf87ae8dd95063f6b056ee and a commit-range diff is empty. Do not infer whole-branch/C12/main/merge readiness.

Evidence: baseline.json (735 old nonignored files/340 dirty entries/28 oldtestdata paths), progress.md (all author rulings), all5 original task briefs, all52 continuous attempt receipts. pre-review-3-baseline-check.json confirms only approved spec/plan state/checklist edits among old files,733 otherwise unchanged,364 currentdirty entries(+24), unchanged HEAD/branch/index. Requirement body hash stays557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF; no new testdata.

Historical review1 (author transcription review-1.md) found0Critical/3Important/1Minor;0033 reproduced DN SET OF order, unknown universal tag forms, BC tail classification;0034 focusedGREEN. RFCfull32literal projection assertion closed missing coverage and alreadyPASS0033, not a productRED.
Review2 exact returned report review-2.md:0Critical/2Important/0Minor.0042 reproduces its valid opaque SET rejection and malformed nested AKI profile classification.0043 opaque SETfixGREEN with DN/form/partial regressions.0044 NOT GREEN: early new-package matrix expected Unsupported for constructed[0] filled with32 EOCzero bytes. Original invalid input retained withInvalidMaterial and well-formed nested OCTET STRING exclusion controladded;0045 focusedGREEN. No old baseline source/test changed.
Prior failed platform/syntax/guard/depth-cap attempts remain retained and classified inprogress/receipts; do not call them passing tests or lose their evidence.

CURRENT revision3 verification only:
0046 exact24format;0047 exact24formatcheckempty/exit0.
0048 nodeca fullpackage,0049 unchangednodeleaf,0050 unchangednodeleafkeys:exit0.
0051 DERfuzz5seeds/10executions/no crash.
0052 SPKIfuzz53cachedseeds/62,009executions/11newcoverage-interesting/64total/no crash.
Both finite5sfuzz runs give limited evidence (DER especially), not exhaustive correctness. All currentsource receiptpre/posthashes mustmatchfreeze3. Earlier0028–0032 or0037–0041 are superseded historical revisions, not completion evidence.

Subject P256SPKI is notparent; SKI is full32SHA256 exactownedrawSPKI; arbitrary shapevalidAKI/badsignature/Unknownalgorithm/expiredorfutureCA remain partial. FixedsixPendingunchanged. No signature/chain/parent/time/deployment/bundle/leaf/runtime trust, no consumer/provider/I/O/privatekey/clock/random/goroutine/dependencies. Approved24-file scope plusallowed statusdocs only.

The author explicitly ruled on all declineddomains from prior reviews. Newdomains13–14: opaqueunknown-parameter fulluniversalprimitive-content semantics and SET versus SET OF schema-dependent canonical ordering are NOT certified under narrow parseraccepted/consumedminimalTLV contract. This does not justify imposing SET OF sorting onvalidSET. KnownDN RDN SET OFsorting remains enforced. Do not quietly widen or upgrade the result.

Review Focus (verbatim from approved plan):

- 声明 CA subject key 被误当 parent key：Task 4 的 TestCAPartialProofParentRoles 必须证明任意合形状 AKI 不执行 subject 派生，实际 parent/签名仍未认证。
- pathLen 省略被折叠为零：Task 3 的 TestCAPathLenPresence 固定 HasPathLen=false/0 与 true/0 的不同结果。
- parser 接受但 raw 值未完整消费：Task 2 的 TestCARawNestedTails 与 Task 3 的 TestCAExtensionCanonicality 覆盖 DN、BC、KU、SKI、AKI 的嵌套尾随/非最小表示。
- Go 前置拒绝被改写成后置 profile 类别：Task 4 的 TestCAParserPriority 与 TestCACombinedFailurePriority 固定完整检查顺序及不泄露动态错误。
- 清理/包装别名与取消产生旧有效结果：Task 1 的 TestCAMaterialLifecycle 及 Task 4 的 TestCACancellation 固定 shared owner、detached 值及失败无半成品。



Read all52 receipts. You may parse their full raw contents with PowerShell and verify complete wrapper, commands, UTC, exit, output and pre/post hashes; summarize repeated hashes rather than flood tool output. Independently hash all735oldfiles and24freezesources; source/evidence consistency and oracle independence are review requirements. Tests are author-run evidence, notyourtestexecution.

Read-only PowerShell only; no tests/cachewrites, files/patches/Gitconfig/index/HEAD/branch writes, networking, worktrees, cleanup or subagents. Read-only Git if needed withGIT_OPTIONAL_LOCKS=0/core.fsmonitor=false via escalation, never safe.directory. Ignore unrelated historicdirtychange review. Final statusdoccloseout has not occurred and will be author-checked separately afterreview.

Output:Strengths; Critical/Important/Minor with exact file:line, counterexample/reproduction/impact/fix; Recommendations; every Declined-to-judgedomain and reason; evidencelimits; clearverdict on CURRENTpartialincrement only. Specsilence does not excuse reasonableuser defects, explicitnongoals do not create trustguarantees.

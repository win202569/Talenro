# Attempt 32 — Final 5/5 FuzzCASPKI

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator

Full wrapper and command:

$env:GOOS='windows'
$env:GOARCH='amd64'
$env:GOTOOLCHAIN='local'
$env:GOPROXY='off'
$env:GOSUMDB='off'
$env:GOAUTH='off'
$env:GOVCS='all:off'
$env:GOFLAGS='-mod=readonly'
$env:GOPATH='C:/Users/Lenovo/go'
$env:GOMODCACHE='C:/Users/Lenovo/go/pkg/mod'
$env:GOCACHE='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-11-node-ca-material/go-cache'
$caGo='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/go.exe'
$caFmt='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/gofmt.exe'
& $caGo test ./internal/nodecontrol/nodeca -run '^$' -fuzz '^FuzzCASPKI$' -count=1 -p=1 -parallel=1 -fuzztime=5s -timeout=30s

Observed receipt:

{
  "startUTC": "2026-10-11T18:25:39.9230925Z",
  "endUTC": "2026-10-11T18:25:49.1383665Z",
  "exit": 0,
  "GODEBUG": null,
  "output": [
    "fuzz: elapsed: 0s, gathering baseline coverage: 0/5 completed",
    "fuzz: elapsed: 1s, gathering baseline coverage: 5/5 completed, now fuzzing with 1 workers",
    "fuzz: elapsed: 3s, execs: 47186 (15727/sec), new interesting: 26 (total: 31)",
    "fuzz: elapsed: 5s, execs: 70427 (11460/sec), new interesting: 30 (total: 35)",
    "PASS",
    "ok  \ttalenro.local/platform/internal/nodecontrol/nodeca\t7.268s"
  ],
  "before": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\boundary_test.go",
      "sha256": "F644256710F4BE7302017A1D375C4BB5E5926E0102A2CE7C2FDAE23893FBD05B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "8E3B9F45C326BCD2BD0174F50FDBE6BC3437905CCF11932A8B3EE5B5599DAF57"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "2B84D68C9D56E9CD6167239EC20AE9E929642BA73A6736B260BED7AC6E4FCFEB"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields.go",
      "sha256": "C1A91AC97C109C48154485A505929789AEB22DC9BD69EB0666377009CDFF0AD2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields_test.go",
      "sha256": "4A1EC88F190E91D7998C167CBBCF4D2790F5BC918C96272A028C6D950CF68725"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der.go",
      "sha256": "66E7D45938C751538A3BE341EA51D22F392F409740E9CF65ACBACCFDC1EA00B0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der_test.go",
      "sha256": "37C4113558FA4F62677AC20AEA1ED13314EE018537D0ECB7C808479B8FF671E0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "893FEC3E470AF2F9C2025740A3A6E5DD64D85572564F03E634740C6E95847A62"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions.go",
      "sha256": "FB23C45893D77CAF176D4B62361665666D647A804C11285BEDB5D1E0B361E5C1"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions_test.go",
      "sha256": "7B84D11A0B96BD1C4D3D76C87015BFDAEEB368A8B49560DFA2E835F61427519E"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "E29AA04ACAC3EACF9524426F274E8C4F93A002BA74A9598D6EE582BD543B123C"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fuzz_test.go",
      "sha256": "EB827AD3EE693F4CE0DBE03EBE0FC6340B16284AE499743EA7BDD245B91B0C14"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "5A6E979C7B1E84357CEBCC26F443D4144F946750C5095976392A94F968C7EB52"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "92E2A18760E9C1C5C90256CA5442A1432A9F42A6E2647A55BCC093A58D68EF47"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "981B6735574D28EA53A61A68CFA7A72DA2B761B6E8D90FABD1EB1344A9D7123A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "787211003166E96697199D16DD5055DA8FF4BDBA9D1A731540EB0187C7B3A07A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "A7511F813D4ADB678A2FA23E1EC05FB96E9A7A6948BEE448811DD1EC1F947793"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse.go",
      "sha256": "AA4BE70D7531000FCB8CB1834FB9CF88AC2633FF51383E81574CABD51A3C5833"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse_test.go",
      "sha256": "ADEAB3811F30B7238422C1086DA5E0BCA4F65DDC469DB2C9E1A4EA6229900361"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate.go",
      "sha256": "2C427C8A6D47A0F50E9C2C84AE6BB72795A9B3ADB1BA45609D268E859CBAD294"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate_test.go",
      "sha256": "79AE777980EAF1485A962766AD9CE2D44A2C398AB247655750D8D93B63A691A7"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki.go",
      "sha256": "9EC27E1C2C748B4DA554EDDB5A8E5366359A24190AD10EC92D7AD5BD3903FF3F"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki_test.go",
      "sha256": "62DB5B59B1E11111E33E68E84943401747C5912BE8B89D6FAB3C8E20FBC5251D"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "1C4B3C6DB7E84D5592601B4EDB34F5B12C2A6FF42A8F0CA3E6860EFBA7B04F71"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ],
  "after": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\boundary_test.go",
      "sha256": "F644256710F4BE7302017A1D375C4BB5E5926E0102A2CE7C2FDAE23893FBD05B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "8E3B9F45C326BCD2BD0174F50FDBE6BC3437905CCF11932A8B3EE5B5599DAF57"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "2B84D68C9D56E9CD6167239EC20AE9E929642BA73A6736B260BED7AC6E4FCFEB"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields.go",
      "sha256": "C1A91AC97C109C48154485A505929789AEB22DC9BD69EB0666377009CDFF0AD2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields_test.go",
      "sha256": "4A1EC88F190E91D7998C167CBBCF4D2790F5BC918C96272A028C6D950CF68725"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der.go",
      "sha256": "66E7D45938C751538A3BE341EA51D22F392F409740E9CF65ACBACCFDC1EA00B0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der_test.go",
      "sha256": "37C4113558FA4F62677AC20AEA1ED13314EE018537D0ECB7C808479B8FF671E0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "893FEC3E470AF2F9C2025740A3A6E5DD64D85572564F03E634740C6E95847A62"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions.go",
      "sha256": "FB23C45893D77CAF176D4B62361665666D647A804C11285BEDB5D1E0B361E5C1"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions_test.go",
      "sha256": "7B84D11A0B96BD1C4D3D76C87015BFDAEEB368A8B49560DFA2E835F61427519E"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "E29AA04ACAC3EACF9524426F274E8C4F93A002BA74A9598D6EE582BD543B123C"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fuzz_test.go",
      "sha256": "EB827AD3EE693F4CE0DBE03EBE0FC6340B16284AE499743EA7BDD245B91B0C14"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "5A6E979C7B1E84357CEBCC26F443D4144F946750C5095976392A94F968C7EB52"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "92E2A18760E9C1C5C90256CA5442A1432A9F42A6E2647A55BCC093A58D68EF47"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "981B6735574D28EA53A61A68CFA7A72DA2B761B6E8D90FABD1EB1344A9D7123A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "787211003166E96697199D16DD5055DA8FF4BDBA9D1A731540EB0187C7B3A07A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "A7511F813D4ADB678A2FA23E1EC05FB96E9A7A6948BEE448811DD1EC1F947793"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse.go",
      "sha256": "AA4BE70D7531000FCB8CB1834FB9CF88AC2633FF51383E81574CABD51A3C5833"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse_test.go",
      "sha256": "ADEAB3811F30B7238422C1086DA5E0BCA4F65DDC469DB2C9E1A4EA6229900361"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate.go",
      "sha256": "2C427C8A6D47A0F50E9C2C84AE6BB72795A9B3ADB1BA45609D268E859CBAD294"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate_test.go",
      "sha256": "79AE777980EAF1485A962766AD9CE2D44A2C398AB247655750D8D93B63A691A7"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki.go",
      "sha256": "9EC27E1C2C748B4DA554EDDB5A8E5366359A24190AD10EC92D7AD5BD3903FF3F"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki_test.go",
      "sha256": "62DB5B59B1E11111E33E68E84943401747C5912BE8B89D6FAB3C8E20FBC5251D"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "1C4B3C6DB7E84D5592601B4EDB34F5B12C2A6FF42A8F0CA3E6860EFBA7B04F71"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ]
}

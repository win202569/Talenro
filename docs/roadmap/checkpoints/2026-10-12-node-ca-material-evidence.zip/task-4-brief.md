## Task 4: 完整 Parse、声明绑定与 partial 结果

**Files:** 新建 parse.go；测试 parse_test.go；扩充新 fixtures_test.go。

**Interfaces:** 消费 Tasks 1–3，产生唯一 `Parse(ctx context.Context,in Input)(*Material,error)`。没有 leaf/parent 输入或输出访问器；context 在各同步阶段前后检查，取消不被普通错误覆盖。

- [ ] **Step 1: 写失败的入口/绑定测试。** TestCAParse 检查两个不同签发关系 golden、KU/pathLen/扩展排列及所有15个 Summary 字段；TestCABindings 用不同合规P256声明与错32-byteSKI固定两类 mismatch、SPKI首错，确认摘要以原始DER/SPKI/Name为preimage。
- [ ] **Step 2: 写不升级与取消失败测试。** TestCAPartialProof/TestCAPartialProofParentRoles 覆盖改变32-byteAKI、坏签名bytes、Unknown signer algorithm、过期/未来CA、Subject==Issuer/SKI==AKI，仍可通过材料层且六Pending顺序不变；非空/unused=0以外 signature拒绝。TestCACancellation 用只在 Err 调用阈值后取消的包内 context，对可达阶段逐阈值迭代，均无半成品；无生产 hook/goroutine，不假称克隆panic清零被动态观测。
- [ ] **Step 3: 写错误优先级失败测试。** TestCAParserPriority/TestCACombinedFailurePriority 固定 nil/预取消→任一超限→空值→声明SPKI→Go parser→raw scanner→字段→四扩展→SPKI mismatch→SKI mismatch→最终context。Go重复扩展前置拒绝为 ErrInvalidMaterial；完整raw结构中非最小值/内层尾随为 ErrInvalidMaterial；可解释profile/ID长度不符为 ErrUnsupportedCAProfile。错误仅固定sentinel或context，不包含输入字节或动态parser文本。
  ```go
  if got.Proof!=NodeCAMaterialShapeAndDeclaredKeyBound || got.Pending!=([6]Obligation{CertificateSignatureAndIssuerChain,AuthorityIdentifierAndParentBinding,TrustedCurrentTime,DeploymentAuthorizationAndPurpose,BundleStatusAndRollback,LeafIssuerRelationAndRuntimeUse}) { t.Fatal("partial strength") }
  if material!=nil && err!=nil { t.Fatal("partial material on error") }
  ```
- [ ] **Step 4: 记录 RED。** Run: `& $caGo test ./internal/nodecontrol/nodeca -run '^(TestCAParse|TestCABindings|TestCAPartialProof|TestCAPartialProofParentRoles|TestCACancellation|TestCAParserPriority|TestCACombinedFailurePriority)$' -count=1 -p=1 -timeout=120s`；预期缺 Parse 或行为失败。
- [ ] **Step 5: 最小实现完整阶段。** preflight→ownInput及失败defer→声明SPKI→ParseCertificate及Raw exact→parseRawCA→fields→extensions→SPKI/SKI绑定→四摘要/固定Pending→最终context→valid与owner移交。所有后续读取来自owned；临时对象不进入owner，阶段末context优先，panic不recover成普通成功。hash只使用owned exact原始片段。
- [ ] **Step 6: 记录 GREEN。** 重跑 Step 4，再完整本包 test，均 exit0；成功 Clear、失败、取消与detached结果独立验证，不作chain/time/运行结论。
- [ ] **Step 7: 保存阶段检查点。** 记录完整入口与错误矩阵，核对旧基线，不提交。

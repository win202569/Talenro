# TIME-tag primary source check — author retrieval, not reviewer browsing

Author read official X.680(2021) Table1/38.1–38.3 and X.690(2015)8.26.1/11.9 through the web tool. Full2021X.690 was previously unavailable; do not represent it as read.

Sources:
- https://www.itu.int/rec/dologin_pub.asp?id=T-REC-X.680-202102-I!!PDF-E&lang=e&type=items (printed63–71).
- https://www.itu.int/rec/dologin_pub.asp?id=T-REC-X.690-201508-S!!PDF-E&lang=e&type=items (printed17/21).

Author paraphrase: X.680 assigns universal14 to TIME and defines its value notation from property-dependent time components. X.690 requires primitive form and UTF-8 content of that notation, without surrounding quotation marks. Consequently ff is definitely malformed UTF-8, independent of any vendor schema. TIME is distinct from UTCTime/GeneralizedTime. Canonical TIME transformations include dot instead of comma, omission of zero offset minutes, repeated endpoint offset omission, and canonical duration zero components. The notation covers dates, times, date-times, durations, intervals and recurrences, including precision/expanded-year choices; UTC-only certificate validity assumptions cannot be imposed on generic TIME.

No author source edit or test reproduction yet. A source-derived tag14 hypothesis is under fresh review7; Task5/formal closeout remain pending. This is a selected primary-reference note, not a full standards redistribution or full TIME-conformance certification.

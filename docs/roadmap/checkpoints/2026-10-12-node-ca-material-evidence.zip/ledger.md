# Evidence ledger

Canonical task/ruling ledger: progress.md. Command receipts: attempt-0001.md onwards. Baseline: baseline.json. No commits or evidence deletion authorized.

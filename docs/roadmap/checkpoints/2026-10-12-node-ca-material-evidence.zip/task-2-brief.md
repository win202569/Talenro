## Task 2: 声明 P-256 SPKI 与 CA 原始编码

**Files:** 新建 spki.go/der.go/raw_certificate.go；测试 fixtures_test.go/spki_test.go/der_test.go/raw_certificate_test.go。

**Interfaces:** 消费 Task 1 errors；产生 `checkDeclaredSPKI(der []byte) error`、`checkCASPKI(cert *x509.Certificate,raw rawCA) error`、`readElement(raw []byte)(derElement,[]byte,error)`、`singleElement(raw []byte,tag byte)(derElement,error)`、`takeElement(raw *[]byte,tag byte)(derElement,error)`、`minimalInteger(raw []byte) bool`、`parseRawCA(der []byte)(rawCA,error)`；测试辅助入口 `fixtureInput(parentSigned bool) Input` 返回新克隆的冻结 golden 原始输入，供后续任务使用。scanner 只读 owned 数据，完整消费，不做签名验证或 profile 绑定。

- [ ] **Step 1: 建立独立测试材料。** fixtures_test.go 固定已批准附录的 RFC 7093 91-byte SPKI 和 SHA256=`6d20896ab8bd833b6b66554bd59b20225d8a75a296088148399d7bf763d57405`。在该文件冻结新的测试专用自签/不同 parent CA golden DER、显式 SKI/AKI 和独立摘要；摘要以 PowerShell SHA256 对冻结原始 bytes 计算并留痕，不调用产品函数作 oracle。golden 运行时不重签；测试私钥只在本包测试辅助函数中使用。
- [ ] **Step 2: 写失败测试。** TestCADeclaredSPKI/TestCAWireSPKI 固定 P-256 exact/canonical、尾随/PEM/压缩/显式参数/非法点/合法不同算法拒绝及 cert raw SPKI 对应。TestCADERTLV 检查短/长长度边界、非最小/indefinite/high-tag/溢出与 trailing；TestCARawCertificate/TestCARawNestedTails 覆盖 TBS、Name SET/ATV、validity、extension 各层完整消费、unique IDs、raw/parser mismatch 和非空 unused=0 signature。
  ```go
  v,tail,err := readElement([]byte{0x04,1,0x7f,0xff})
  if err!=nil || len(v.content)!=1 || !bytes.Equal(tail,[]byte{0xff}) { t.Fatal("TLV cursor") }
  if _,err:=singleElement([]byte{0x04,0x81,1,0x7f},4); !errors.Is(err,ErrInvalidMaterial) { t.Fatal("nonminimal length") }
  ```
- [ ] **Step 3: 记录 RED。** Run: `& $caGo test ./internal/nodecontrol/nodeca -run '^(TestCADeclaredSPKI|TestCAWireSPKI|TestCADERTLV|TestCARawCertificate|TestCARawNestedTails)$' -count=1 -p=1 -timeout=120s`；预期缺对应 helper 或行为失败。
- [ ] **Step 4: 实现编码检查。** 两种 SPKI 检查均 ParsePKIXPublicKey、命名 P256 合法点、MarshalPKIXPublicKey exact compare；临时 marshal buffer 立即 defer clear。声明 malformed/noncanonical 为 ErrInvalidInput，CA raw malformed/noncanonical 为 ErrInvalidMaterial；合法非 P256 为 ErrUnsupportedCAProfile。TLV 在累乘之前以实际剩余长度约束 accumulator；Name/OID/AlgorithmIdentifier/extension 内层完整消费；不修正或保留重编码、Go key/parser 对象。rawCA 的 signature 为 BIT STRING 外层原始值，保留 inner/outer algorithm exact bytes 用于对应。原始 BIT STRING malformed 为 ErrInvalidMaterial；可解释但空 signature 或 unused bits 非零为 ErrUnsupportedCAProfile，Go 前置拒绝仍优先。raw scanner 不把合法空 Name SEQUENCE 当 malformed；CA 非空 Name/4096-byte 限制由 Task 3 fields 执行，Name SET/ATV 结构不完整仍为 ErrInvalidMaterial。
- [ ] **Step 5: 记录 GREEN。** 重跑 Step 3，再完整本包 test，固定 flags、均 exit0。fixture/语法错误须修正并重新取得真实 RED，不能将其登记为行为 RED。
- [ ] **Step 6: 保存阶段检查点。** 固定新 golden/独立 oracle 哈希，核对旧文件未变，不提交。

# Node CA Material — fresh read-only review package 7

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Approved complete spec: docs/superpowers/specs/2026-10-11-node-ca-material-design.md
Approved Native five-task plan: docs/superpowers/plans/2026-10-11-node-ca-material.md
Evidence directory: .superpowers/sdd/2026-10-11-node-ca-material/

Review the whole exact 24-file increment (12 product, 12 tests) in frozen-sources-7.json. Base = HEAD = 6752b9612a00b9d6b0bf87ae8dd95063f6b056ee; branch codex/c12-b01-task9-coordinator. All new sources are untracked; an empty commit range is not the increment. Do not review unrelated historical dirty work as if introduced here.

Read complete approved spec/plan, five original task briefs, all 24 current files, baseline/progress, all six prior reports, all 93 continuous raw attempt receipts, historical freezes 1–6 and current freeze 7, pre-review-7-baseline-check.json and candidate-7-consistency.json. Original reports 3/4/5/6 are retained in conversation; their saved files explicitly are author transcriptions, not verbatim. Prior review 2 is the exact returned report.

Baseline: 735 old nonignored files and 340 old dirty entries. Independently verify all baseline hashes (only permitted spec/plan state edits), all 44 old testdata paths (28 nested +16 root), no new testdata/consumers, HEAD/branch/index, inventories and exact +24 dirty/new files. Index SHA256 remains 1CBA46BEF4C1AFDC9AE7938146909F0D2D641A0D712CE18036B60FE5B8673D12.
Requirement body SHA256: 557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF. Normalize checkbox status when comparing five task sections with original briefs. Status/execution closeout documents have NOT been changed yet.

Prior review corrections:
1: 0 Critical /3 Important /1 Minor: known DN SET OF order, universal form bits, BC complete consumption, RFC full literal coverage. 0033 assertion RED (RFC coverage already passed) →0034 GREEN.
2: 0/2/0: remove schema-unknown opaque SET OF assumption (keep known DN order); validate nested AKI structure. 0042 RED →0043/0045 GREEN. 0044 failed new oracle, not GREEN: original zero-filled constructed[0] stays InvalidMaterial; separate well-formed OCTET representation stays Unsupported.
3: 0/3/0: outer SPKI consumption before unsupported key; UID BIT STRING and full TBS scan before profile return; AKI [2] implicit INTEGER minimality. 0053 RED →0054/0055/0056 GREEN.
4: 0/2/0: RSA known BIT STRING payload tail discarded by Go before Unsupported; AKI issuer GeneralName registeredID [8] implicit OID minimality. 0064 genuine RED also reproduced DSA payload/parameter tails and four malformed OID controls. 0065 focused GREEN. Valid RSA, DSA and registeredID controls retained.

5: 0/2/0: incomplete known GeneralNames encoding/container grammar and unapproved bounded-integer cap for valid opaque OID parameters. 0073 genuine RED for all supplied GeneralNames and large-OID examples; 0074 supplements known X400 attribute type/container counterexamples, also genuine RED. Valid excluded controls passed. 0075 all three focused suites GREEN.

6: 0 Critical /2 Important /0 Minor: rejected directoryName AttributeValue tags bypassed pinned Name interpreter; recognized universal primitive/required-container grammar behind extension ANY was insufficient. All previous findings accepted and fixed, not deferred.
Revision7 changes only raw_certificate.go, extensions.go and parse_test.go from freeze6:
- rejected Name Value permits pinned Go six string types and compatibility, not CN/OID-specific policy; opaque Name OID remains representation-only.
- extension-only ANY traversal checks VisibleString, RelativeOID, canonical UTC/GeneralizedTime lexical/calendar representation, REAL DER representation, EXTERNAL required encoding choice, EMBEDDED PDV/CHARACTER STRING automatic-tag identification/data required containers. Iterative child walk, no arbitrary depth/precision/exponent cap, no schema/vendor/trust/value-policy claim.
- 0083 genuinely reproduced findings but also had one bad new valid EXTERNAL reference control (length0d for11bytes). Only that control corrected0b;0084 clean assertion RED all valid controls passed.0085/0086 focused GREEN incl prior GeneralNames/X400/opaqueOID plus all six PDV identifications and unchanged guard suites.
- finite controls distinguish malformed bytes -> InvalidMaterial, well-encoded excluded profile -> Unsupported, no material either way. Unknown signer opaque semantics unchanged.
- rulings25–29 in progress.md are limits, NOT a waiver of known encoding/container or approved error contract. Independently grade them against complete approved spec; report verified remaining in-scope issues in one pass. Do not infer full RFC/universal/provider conformance.
CURRENT acceptance receipts:
0087 exact24-source format posthashes match freeze7.
0088 exactformat check pre/post match, empty output/exit0.
0089 fullnodeca exit0,4.451s;0090 nodeleaf exit0,8.345s;0091 nodeleafkeys exit0,6.929s.
0092 FuzzCADER exit0,5seeds/15executions/no new interesting.
0093 FuzzCASPKI exit0,64cachedseeds/4877executions/1newinteresting/no crash.
All0088–0093 pre/post hashes and current match freeze7;0087 post matches. Freeze actualUTC 2026-10-11T20:49:16.9296296Z; read while the original0092 session was not yet collected, actual eventual receipt endUTC 2026-10-11T20:49:02.4105809Z; paired hashes/exit0 independently verified. All93 raw receipts retained (0002/0008/0019–21/0044/0083 include environmental/oracle/guard diagnostic distinctions, not fabricated RED/GREEN). Native pinned Go1.26.5 windows/amd64 process-only offline settings and fixed120s/5s+30s flags unchanged. Wall-clock delays cause unestablished. UTC2026-10-11 maps to localOct12UTC+4.
No final status/execution writes, Task5unchecked. This is source review before author-only document closeout.

Review Focus (verbatim from plan):
- 声明 CA subject key 被误当 parent key：Task 4 的 TestCAPartialProofParentRoles 必须证明任意合形状 AKI 不执行 subject 派生，实际 parent/签名仍未认证。
- pathLen 省略被折叠为零：Task 3 的 TestCAPathLenPresence 固定 HasPathLen=false/0 与 true/0 的不同结果。
- parser 接受但 raw 值未完整消费：Task 2 的 TestCARawNestedTails 与 Task 3 的 TestCAExtensionCanonicality 覆盖 DN、BC、KU、SKI、AKI 的嵌套尾随/非最小表示。
- Go 前置拒绝被改写成后置 profile 类别：Task 4 的 TestCAParserPriority 与 TestCACombinedFailurePriority 固定完整检查顺序及不泄露动态错误。
- 清理/包装别名与取消产生旧有效结果：Task 1 的 TestCAMaterialLifecycle 及 Task 4 的 TestCACancellation 固定 shared owner、detached 值及失败无半成品。

The six fixed Pending obligations and partial-only owned CA shape, caller-declared subject P256 binding and full exact SPKI SHA256 SKI remain. No parent/signature/trust/time/deployment/bundle/leaf/runtime/provider capability. No old product/test/guard relaxations, new dependency/I/O/privatekey/clock/random/goroutine, or consumers.

All prior declined domains plus rulings25–29 have explicit author rulings/costs in progress.md. Opaque unknown signer primitive semantics and schema-dependent SET vs SET OF ordering are NOT certified; known DN SET OF order remains checked. Those opaque-signer exclusions do not waive known SPKI or recognized extension grammar. Global serial uniqueness / DN equivalence remain unproved.

Strictly read-only PowerShell. No tests, formatting, cache/file/Git/config/index/HEAD/branch writes, network, worktree/cleanup or subagents. Read-only Git may use GIT_OPTIONAL_LOCKS=0/core.fsmonitor=false and escalation for ownership; never safe.directory. Do all review yourself. Verify raw receipt evidence honestly; do not claim tests you ran.
Return Strengths; Critical/Important/Minor exact file:line with counterexample/impact/fix; Recommendations; every declined-to-judge domain+reason; evidence limits; clear CURRENT partial-increment verdict, not merge/main/C12 authorization. Return report in final only; no disk writes.

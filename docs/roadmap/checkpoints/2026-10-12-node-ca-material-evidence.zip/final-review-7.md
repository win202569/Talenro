# Final independent review 7 — exact returned report

Reviewer: /root/ca_material_final_review_7; fresh gpt-6-astra / xhigh; read-only, no test reruns, no writes.

## Current verdict

**Revision 7 needs fixes: 0 Critical, 2 Important, 0 Minor.**

This verdict concerns only the frozen, local, partial-material increment. It is not merge authorization or Task10/B01/C12/main acceptance.

## Strengths

- The partial-proof boundary remains sound: declared SPKI binds the CA’s subject key, arbitrary shape-valid AKI is not subject-derived, and all six Pending obligations remain fixed.
- Ownership, cleanup-before-copy, shared `Clear`, detached summaries, cancellation handoff, exact-byte digests, and omitted-versus-zero pathLen are clearly implemented.
- Previous reported counterexamples remain covered. Revision 7 addresses the previously identified Name-value and extension-ANY examples without changing the accepted CA profile.
- Independent preservation checks found:
  - All 735 baseline files accounted for; only the permitted spec/plan state changes differ.
  - All 44 old testdata files unchanged: 28 nested and 16 root-level.
  - Exactly 759 nonignored files and 364 dirty entries: the original baseline plus precisely 24 new nodeca files.
  - No new testdata or external nodeca consumers.
  - Current 24 hashes match freeze 7. Only `extensions.go`, `raw_certificate.go`, and `parse_test.go` differ from freeze 6.
  - Requirement-body hash and all five checkbox-normalized original task briefs match.
- All 93 raw receipts were inspected. Every historical freeze matches its corresponding formatting/final-command receipts; current receipts 0087–0093 match freeze 7 as specified.

## Issues

### Critical

None found.

### Important 1 — Universal TIME payloads bypass extension-ANY validation

Location: [extensions.go:237](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeca/extensions.go:237), especially the default success at line 254.

`checkGeneralNode` validates UTCTime and GeneralizedTime, but omits universal tag 14, ASN.1 `TIME`. The preceding generic walker checks primitive form but does not validate this tag’s content.

Concrete source-derived counterexample: preserve the golden AKI’s initial keyIdentifier, then append this authorityCertIssuer suffix:

```text
a10aa00806012aa0030e01ff
```

It contains an otherName whose explicit ANY is `0e 01 ff`: universal TIME containing invalid UTF-8.

The pinned Go AKI parser returns the initial keyIdentifier without inspecting the issuer suffix. The new extension walker then accepts the TIME payload and ultimately returns `ErrUnsupportedCAProfile`. The required result is `ErrInvalidMaterial`.

The standards basis supplied during review is X.680 §38.1.2, assigning TIME universal tag 14, and X.690 §8.26.1.2, requiring UTF-8 encoding of its value notation. This is a universally defined representation requirement, not vendor-schema interpretation or signer policy.

Impact: malformed recognized extension content is misclassified. No accepted material or trust bypass is asserted.

Fix: cover TIME’s encoding and canonical notation in the extension-specific validation path, with malformed and valid-excluded controls through otherName, nested ANY, and unknown X400 attributes. Do not blanket-reject valid TIME or impose certificate-only UTC/year/precision restrictions. Preserve the separate opaque-signer limitation.

### Important 2 — Go’s leap-second limitation becomes an unapproved GeneralizedTime restriction

Location: [extensions.go:291](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeca/extensions.go:291).

`checkGeneralTime` uses `asn1.Unmarshal` into `time.Time` as its calendar oracle. The pinned Go implementation rejects any seconds value ≥60 (`time/format.go:1162`), including a valid generic GeneralizedTime leap-second representation.

Concrete source-derived counterexample: preserve the golden AKI keyIdentifier and append:

```text
a118a01606012aa011180f32303136313233313233353936305a
```

The otherName ANY is GeneralizedTime:

```text
20161231235960Z
```

This has complete seconds, UTC `Z`, and canonical lexical representation. The helper returns `ErrInvalidMaterial`; the valid excluded issuer-bearing AKI should reach `ErrUnsupportedCAProfile`.

The validity conclusion follows X.680 §46.3’s ISO 8601 basis and the explicit GeneralizedTime leap-second production in RFC 4517 §3.3.13. It is an inference from those sources, not a quoted ITU clause explicitly spelling out “60.” UTCTime is different: its explicit 00–59 restriction must remain.

Impact: a valid excluded encoding receives the malformed sentinel through an implementation-specific time limitation. This does not concern certificate validity fields, whose pinned Go front-parser rejection remains authoritative under the approved contract.

Fix: validate generic GeneralizedTime representation/calendar rules without inheriting `time.Time`’s inability to represent leap seconds. Add valid `...60Z` versus invalid `...61Z` and impossible-date controls; retain arbitrary canonical fractional precision, existing UTCTime restrictions, and all trusted-time Pending responsibilities.

### Minor

None found.

## Recommendations

1. Reproduce both findings with focused negative/valid-excluded controls before implementation.
2. Repair them without broadening accepted CA material, signer semantics, or trust capabilities.
3. After source changes, repeat the exact formatting/check, all five approved final commands, freeze, and fresh review.
4. Keep Task 5 and formal documentation closeout pending until the review gate is satisfied.
5. Preserve the limited fuzz characterization: current DER fuzz executed only 15 inputs; SPKI fuzz executed 4,877 with one new coverage-interesting input and no reported crash.

## Declined-to-judge domains

These exclusions do not waive the verified encoding/error-contract findings above.

1. Signature authenticity and signer policy — explicitly Pending.
2. Parent/chain/root authentication, AKI-parent binding, self-signing, and actual path constraints — no authenticated parent input.
3. Trusted current validity, maximum lifetime, and backdating — deferred time responsibilities.
4. Deployment provenance, trust domain, naming authorization, purpose, and authorization — outside the material layer.
5. Bundle status, revocation, compromise, versions/high-water, and rollback — explicitly Pending.
6. CA-leaf issuer/signature/AKI relations, private-key possession, installation, and runtime authority — no corresponding input or authorized consumer.
7. Production-provider compatibility or migration — no acceptance commitment.
8. Concurrent input mutation or concurrent Clear/read — expressly unsupported.
9. Fatal OOM/crashes, unreachable parser/runtime copies, and hard-real-time cancellation — excluded guarantees.
10. Formal completeness of AST safeguards — finite checks and source inspection, not proof.
11. Exhaustive fuzzing, total resource bounds, Linux/race/DB/Docker/full-repository behavior — outside the approved native evidence.
12. Unrelated historical dirty changes and Task10/B01/C12/main readiness — increment-only scope.
13. Full universal primitive semantics in opaque unknown signer parameters — the existing signer-specific limitation; not applicable to these extension findings.
14. Schema-dependent SET versus SET OF ordering in opaque values — requires the missing schema; known RDN/X400 ordering remains relevant.
15. Global serial uniqueness — not established by serial representation checks.
16. DN normalization or semantic equivalence — exact raw bytes are preserved, not normalized.
17. Full excluded-GeneralName naming/routing/length/range/subtype policies — no full RFC/provider-conformance undertaking.
18. Vendor meaning behind unknown otherName OIDs or X400 attribute types — no vendor schema; known universal encodings remain checkable.
19. Full legacy character repertoire conformance beyond pinned compatibility — no independent complete repertoire validation.
20. OID-specific Name subtypes beyond the pinned six string representations — no additional CN/OID naming policy is authorized.
21. Exhaustive generic time-property, fractional-precision, REAL, or transfer-syntax conformance — finite examples and selected references do not establish full standards conformance.

## Evidence and limitations

I reviewed the complete approved spec/plan, five original briefs, all 24 current Go files, baseline/progress, six saved historical reports, 93 raw receipts, seven freezes, pre-review-7 baseline check, and candidate-7 consistency record. Reports 3–6 are explicitly author transcriptions; report 2 is saved as the exact returned report; report 1 is a saved summary.

Independent checks confirmed:

```text
HEAD:
6752b9612a00b9d6b0bf87ae8dd95063f6b056ee

Branch:
codex/c12-b01-task9-coordinator

Index SHA256:
1CBA46BEF4C1AFDC9AE7938146909F0D2D641A0D712CE18036B60FE5B8673D12

Requirement-body SHA256:
557EBEE23DBB391247B422E52C6C0809230F344ABBD07C080A4C8ABC183AD4CF
```

The independent golden/RFC SPKI and DER digest calculations match their literals. Candidate 7’s eleven receipt entries match the underlying raw commands, outputs, timestamps, and exits. Format check 0088 is empty/exit 0; commands 0089–0093 record exit 0 on matching frozen sources. Receipt 0092 ended before freeze 7’s timestamp; its previously uncollected session must not be described as still executing.

I ran **no tests, formatting, networking, or writes**. All test outcomes are author-recorded evidence, not reviewer reruns. Both findings are source-derived. The TIME/leap-second standards basis was supplied through coordinator-retrieved primary excerpts and the author’s reference note; I did not independently retrieve the full standards. Full 2021 X.690 was not represented as read.

The architecture and preservation evidence are strong, but the two remaining fixed-error-contract defects prevent completion of the current frozen partial increment.

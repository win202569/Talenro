## Task 3: CA 字段与四扩展材料 profile

**Files:** 新建 ca_fields.go/extensions.go；测试 ca_fields_test.go/extensions_test.go；只扩充新 fixtures_test.go 的突变辅助函数。

**Interfaces:** 消费 Task 2 rawCA/SPKI helper；产生 `checkCAFields(cert *x509.Certificate,raw rawCA)(fieldSummary,error)`、`canonicalTime(raw derElement,parsed time.Time) bool`、`checkCAExtensions(cert *x509.Certificate,raw []rawExtension)(extensionSummary,error)`。fieldSummary 只有 unsigned serial/length、UTC times；extensionSummary 只有两个 KeyIdentifier、HasPathLen/PathLen、CRLSignAllowed。CA SPKI 检查包含在 fields 首段；扩展函数只检查形状/对应，SKI hash 比较留给 Task 4。

- [ ] **Step 1: 写字段失败测试。** TestCAFields 覆盖 v3、非空名字/4096与4097-byte预算、Name raw/parser 对应、正数/零/负/20及21-octet serial 与必要 padding；时间1/9999与0/10000边界、1950/2049/2050切换、UTC整秒/offset/fraction/倒置/相等。TestCANotLeafLifetime 接受合规的非24h CA窗口，不获取当前时间。
- [ ] **Step 2: 写扩展失败测试。** TestCAExtensions 为四种扩展各自缺失/重复/criticality/值/额外已知未知做表；TestCAPathLenPresence 固定省略/0/1/255与-1/256/非最小整数；TestCAExtensionCanonicality 固定 KU 两值与额外bits/尾零、SKI/AKI 1/20/31/32/33/64、AKI constructed/issuer/serial/尾随；合法排列保持同一结果。
  ```go
  // 对同一合规 cert/raw 使用包内新 fixture，只比较 detached projection。
  if absent.HasPathLen || absent.PathLen!=0 || !zero.HasPathLen || zero.PathLen!=0 { t.Fatal("pathLen presence") }
  if certOnly.CRLSignAllowed || !certAndCRL.CRLSignAllowed { t.Fatal("KU projection") }
  ```
- [ ] **Step 3: 记录 RED。** Run: `& $caGo test ./internal/nodecontrol/nodeca -run '^(TestCAFields|TestCANotLeafLifetime|TestCAExtensions|TestCAPathLenPresence|TestCAExtensionCanonicality)$' -count=1 -p=1 -timeout=120s`；预期缺声明或行为失败。
- [ ] **Step 4: 实现 profile。** fields 按 version/key→Name→serial→time 固定顺序，raw与parser不一致 ErrInvalidMaterial，合解释但超子集 ErrUnsupportedCAProfile。扩展先固定 inventory/criticality，再按 BC→KU→SKI形状→AKI形状；非最小/尾随/结构 malformed 为 ErrInvalidMaterial，能解释的值/长度/profile 不符为 ErrUnsupportedCAProfile。BC 与 IsCA/BasicConstraintsValid/MaxPathLen/MaxPathLenZero、KU 与 KeyUsage、SKI/AKI 与解析 slices 均 exact 对应；不靠 extension 顺序/map迭代定首错。
- [ ] **Step 5: 记录 GREEN。** 重跑 Step 3，再完整本包 test，均 exit0；内部 profile helper 的 duplicate 拒绝类别不替代整入口 Go 前置解析的类别。
- [ ] **Step 6: 保存阶段检查点。** 记录字段/扩展矩阵与结果，旧两层/向量保持冻结，不提交。

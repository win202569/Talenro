# Node CA Material — read-only increment review package 1

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Plan: docs/superpowers/plans/2026-10-11-node-ca-material.md (approved Native by user “1”).
Spec: docs/superpowers/specs/2026-10-11-node-ca-material-design.md.
Base and current HEAD: 6752b9612a00b9d6b0bf87ae8dd95063f6b056ee; no commits or Git writes. A commit-range diff would be empty and would NOT review this untracked increment. Scope is exactly frozen-sources-1.json (24 new files, 12 product/12 tests), with evidence and allowed status documents. Do not re-review the unrelated historical dirty branch.

Baseline: baseline.json (735 existing nonignored files, 340 dirty entries, all old inline/testdata vectors).
Progress/rulings: progress.md; full original task briefs task-1-brief.md through task-5-brief.md.
Protected baseline checks: task-1/2/3/4-baseline-check.json; pre-review-baseline-check.json.
Receipts: attempt-0001.md through attempt-0032.md, no numbering gaps. Each has actual UTC, full wrapper/cmd, inherited GODEBUG, exit/output and source/doc pre/post hashes.
Final sources are frozen after format attempt-0026; format check-0027 had empty output and exit0.
All five final limited commands 0028–0032 exit0 on same 24 files:
- 0028 nodeca full suite;
- 0029 old nodeleaf regression;
- 0030 old nodeleafkeys regression;
- 0031 5s FuzzCADER, 5 seeds, only 6 executions (limited throughput, not exhaustive assurance);
- 0032 5s FuzzCASPKI, 5 seeds, 70,427 executions, 30 new coverage-interesting inputs (no crash).

Failures retained: 0001 genuine Task1 RED; 0002 Windows rejected Linux-target test executable (not GREEN); 0003 diagnosed persisted GOOS=linux versus Windows host. Subsequent wrapper pins process-only GOOS=windows/GOARCH=amd64, no configuration edits.
0006 one-time temporary test-only signed golden generation (test scalars 1/2); source snapshot hashes and logged hex retained, helper replaced with immutable inline bytes before runtime tests. No persistent generator command/runtime signing.
0007 independent PowerShell SHA256 oracles.
0008 excess-parenthesis test syntax failure (NOT RED); 0009 genuine Task2 RED.
0012 genuine Task3 RED; 0015 genuine Task4 RED; 0018 genuine missing guard RED.
0019–0021 guard false positives fully diagnosed; 0022 GREEN.
0023 supplemental RED finds unapproved 32-depth rejection and premature owner handoff guard miss; 0024 GREEN after iterative DER traversal/last-clone handoff fix; 0025 guard GREEN.

Partial-only implementation: no signature/chain/parent/time trust, deployment authorization, bundle/rollback status, leaf/runtime use. No old source/test/profile/consumer changes. Strongest fresh read-only review required; no downgrade. Tests are author evidence, not proof that the reviewer reran tests.
No Git staging/config/commit/push/merge/cleanup authorized; scratch must remain.

Review output: Strengths; Critical/Important/Minor with exact path:line, reproduction/impact; every “Declined to judge” behavior and reason; verdict about this partial increment, NOT readiness to merge/unblock C12. Inspect all 24 files, input classes/guard bypasses, oracle independence, cleanup/ordering, and source/evidence consistency. No test commands (would write cache), no file writes, no other agents.

# Independent final review 4 — author transcription

Reviewer: /root/ca_material_final_review_4, fresh gpt-6-astra / xhigh, read-only. The original complete report is retained in the conversation; this file is an author transcription, not a verbatim report.

Verdict: revision 4 needs fixes — 0 Critical, 2 Important, 0 Minor. All 24 frozen files, 735 baseline files, 44 existing testdata files, 63 complete receipts, four freezes, requirement-body hash, normalized five briefs and Git baseline were checked. The reviewer did not execute tests or formatting.

I1: RSA SPKI 301d300d06092a864886f70d0101010500030c00300902020ca10201110500 contains a trailing NULL inside its known RSA BIT STRING payload. Go accepts and discards it; canonicalSPKI returns Unsupported before checking a known key payload. Expected InvalidInput. Canonical control 301b300d06092a864886f70d0101010500030a00300702020ca1020111 stays Unsupported. Repair must retain valid DSA that the pinned Go parser accepts but MarshalPKIXPublicKey does not marshal.

I2: AKI suffix a1048802802a is a GeneralNames registeredID [8] IMPLICIT OID with nonminimal base-128 content. Current generic TLV walk skips that known implicit content and returns Unsupported. Expected InvalidMaterial. Canonical suffix a10388012a stays Unsupported.

Author disposition: both findings are in scope and will be reproduced RED then fixed. Review the known unsupported key-payload paths including DSA while retaining algorithm support unchanged. Preserve all prior evidence, repeat exact-file formatting and five approved commands, freeze and request a fresh review before documentation closeout.

All 16 declined domains are reaffirmed with the existing ordered author rulings: no signature/signer policy, parent/chain/root, trusted current time, deployment/authorization, status/revocation/rollback, CA-leaf/runtime/private-key, production-provider compatibility, concurrency, fatal/unreachable memory or hard-real-time, formal AST completeness, exhaustive/resource/Linux/race/DB/Docker/full-repository, historic dirty work/main readiness, opaque signer primitive semantics, opaque SET schema ordering, global serial uniqueness, or DN equivalence certification. The known RSA and registeredID grammar defects are not covered by the opaque-signer exclusions.

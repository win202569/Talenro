# Independent final review 5 — author transcription

Fresh reviewer /root/ca_material_final_review_5, gpt-6-astra/xhigh, read-only. The original full report is retained in conversation. This is an author transcription, not a verbatim report.

Verdict: revision5 needs fixes, 0 Critical /2 Important /0 Minor. All24 files, all72 receipts, 735 old files, 44 testdata files, 759 inventory /364 status, normalized briefs, requirement-body, five freezes and Git were independently checked. No reviewer tests, formatter, writes or network.

I1 — known AKI GeneralNames grammar incomplete: prefix keyIdentifier 80205cd252fb0ce8932436faf8ccd1040981b89ee4ad6b9fe9e2a2b7e71aacb27cd3 then each suffix below is currently Unsupported but must be InvalidMaterial:
- a1038101ff /a1038201ff /a1038601ff: invalid IA5 rfc822/dNS/URI.
- a104a4020500: directoryName NULL rather than Name.
- a11aa418301631143008060355040b0c0162300806035504030c0161: descending RDN SET OF.
- a112a410300e310c300a06035504030c01610500: directoryName ATV tail.
- a110a40e300c310a300806035504030c01ff: malformed UTF8 directoryName CN.
- a107a00506032a0304: otherName missing required explicit value.
- a10da00b06032a0304a00405000500: otherName explicit value contains two elements.
- a102a500: ediPartyName missing partyName.
- a102a300: x400Address missing BuiltInStandardAttributes.

Fix the known typed boundaries as a group, with malformed and valid unsupported controls for all affected families. Keep keyIdentifier arbitrariness, existing constructed-keyIdentifier representation ruling, and all six Pending obligations; no new supported AKI profile/parent/naming authentication.

I2 — unknown signature AI 300d06032a030406062a8880808000 carries minimal parameter OID 1.2.2147483648. Pinned ParseCertificate keeps opaque parameters; generic walker calls bounded asn1.ObjectIdentifier conversion and wrongly rejects >MaxInt32. Use representation-only nonempty/minimal/terminated base128 OID validation for opaque values; keep actual algorithm/name/extension OID parser checks. Successful partial-material plus nonminimal/unterminated negatives required.

Author accepts both findings as in-scope. Reproduce all supplied examples, repair known typed boundaries, repeat format/five commands/freeze/fresh review before closeout. All16 declined domains retain existing explicit Rulings8–21/23–24 and costs. These exclusions do not waive known extension grammar or permit numeric limits on valid opaque OID encodings. Current limited fuzz 6/79 executions is not exhaustive assurance.

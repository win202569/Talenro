# Attempt 66 — Revision-5 exact 24-source formatting

Workdir: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator

Full wrapper and command:

$env:GOOS='windows'
$env:GOARCH='amd64'
$env:GOTOOLCHAIN='local'
$env:GOPROXY='off'
$env:GOSUMDB='off'
$env:GOAUTH='off'
$env:GOVCS='all:off'
$env:GOFLAGS='-mod=readonly'
$env:GOPATH='C:/Users/Lenovo/go'
$env:GOMODCACHE='C:/Users/Lenovo/go/pkg/mod'
$env:GOCACHE='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-11-node-ca-material/go-cache'
$caGo='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/go.exe'
$caFmt='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/gofmt.exe'
$caNames='doc.go input.go errors.go budget.go owned.go material.go spki.go der.go raw_certificate.go ca_fields.go extensions.go parse.go fixtures_test.go budget_test.go owned_test.go material_test.go spki_test.go der_test.go raw_certificate_test.go ca_fields_test.go extensions_test.go parse_test.go boundary_test.go fuzz_test.go'.Split(' ')
[string[]]$caPaths=@($caNames | ForEach-Object { Join-Path 'internal/nodecontrol/nodeca' $_ })
[Array]::Sort($caPaths,[StringComparer]::Ordinal)

& $caFmt -w $caPaths

Observed receipt:

{
  "startUTC": "2026-10-11T19:32:27.3040086Z",
  "endUTC": "2026-10-11T19:32:31.6754388Z",
  "exit": 0,
  "GODEBUG": null,
  "output": [],
  "before": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\boundary_test.go",
      "sha256": "F644256710F4BE7302017A1D375C4BB5E5926E0102A2CE7C2FDAE23893FBD05B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "8E3B9F45C326BCD2BD0174F50FDBE6BC3437905CCF11932A8B3EE5B5599DAF57"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "2B84D68C9D56E9CD6167239EC20AE9E929642BA73A6736B260BED7AC6E4FCFEB"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields.go",
      "sha256": "C1A91AC97C109C48154485A505929789AEB22DC9BD69EB0666377009CDFF0AD2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields_test.go",
      "sha256": "4A1EC88F190E91D7998C167CBBCF4D2790F5BC918C96272A028C6D950CF68725"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der.go",
      "sha256": "639648286AD52B955CF50454B829FCA1E27B2F6DE337E6901CD539AFC8B6CA98"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der_test.go",
      "sha256": "37C4113558FA4F62677AC20AEA1ED13314EE018537D0ECB7C808479B8FF671E0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "893FEC3E470AF2F9C2025740A3A6E5DD64D85572564F03E634740C6E95847A62"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions.go",
      "sha256": "140E1D8EF93A869BDBAFEF444CFF0F49189893E770189560E7669A671C77AF99"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions_test.go",
      "sha256": "0A2D3B87D307986D1969DCC23B4A349ECBAFF7F74F91B8E986F81729CF85D0CC"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "E29AA04ACAC3EACF9524426F274E8C4F93A002BA74A9598D6EE582BD543B123C"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fuzz_test.go",
      "sha256": "EB827AD3EE693F4CE0DBE03EBE0FC6340B16284AE499743EA7BDD245B91B0C14"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "5A6E979C7B1E84357CEBCC26F443D4144F946750C5095976392A94F968C7EB52"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "92E2A18760E9C1C5C90256CA5442A1432A9F42A6E2647A55BCC093A58D68EF47"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "981B6735574D28EA53A61A68CFA7A72DA2B761B6E8D90FABD1EB1344A9D7123A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "787211003166E96697199D16DD5055DA8FF4BDBA9D1A731540EB0187C7B3A07A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "A7511F813D4ADB678A2FA23E1EC05FB96E9A7A6948BEE448811DD1EC1F947793"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse.go",
      "sha256": "AA4BE70D7531000FCB8CB1834FB9CF88AC2633FF51383E81574CABD51A3C5833"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse_test.go",
      "sha256": "B7A18A7AE853DDDC6115A1199597DD70D829470FB4EB44B7D1700071BA33A983"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate.go",
      "sha256": "8CC808C6BF16D52A628D1A7CF7023058B5C24B273360907E0611E617761E0562"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate_test.go",
      "sha256": "79AE777980EAF1485A962766AD9CE2D44A2C398AB247655750D8D93B63A691A7"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki.go",
      "sha256": "95AAA8CE6398AC585836656BFDBA943DA6F6C41D36DF4F67D258F4DBAAA8067F"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki_test.go",
      "sha256": "62DB5B59B1E11111E33E68E84943401747C5912BE8B89D6FAB3C8E20FBC5251D"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "1C4B3C6DB7E84D5592601B4EDB34F5B12C2A6FF42A8F0CA3E6860EFBA7B04F71"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ],
  "after": [
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\boundary_test.go",
      "sha256": "F644256710F4BE7302017A1D375C4BB5E5926E0102A2CE7C2FDAE23893FBD05B"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget.go",
      "sha256": "8E3B9F45C326BCD2BD0174F50FDBE6BC3437905CCF11932A8B3EE5B5599DAF57"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\budget_test.go",
      "sha256": "2B84D68C9D56E9CD6167239EC20AE9E929642BA73A6736B260BED7AC6E4FCFEB"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields.go",
      "sha256": "C1A91AC97C109C48154485A505929789AEB22DC9BD69EB0666377009CDFF0AD2"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\ca_fields_test.go",
      "sha256": "4A1EC88F190E91D7998C167CBBCF4D2790F5BC918C96272A028C6D950CF68725"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der.go",
      "sha256": "639648286AD52B955CF50454B829FCA1E27B2F6DE337E6901CD539AFC8B6CA98"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\der_test.go",
      "sha256": "37C4113558FA4F62677AC20AEA1ED13314EE018537D0ECB7C808479B8FF671E0"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\doc.go",
      "sha256": "F6790FD2DBEDD44538370308E00C3E2E0D7F3EB33789689FF608142C4881A163"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\errors.go",
      "sha256": "893FEC3E470AF2F9C2025740A3A6E5DD64D85572564F03E634740C6E95847A62"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions.go",
      "sha256": "140E1D8EF93A869BDBAFEF444CFF0F49189893E770189560E7669A671C77AF99"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\extensions_test.go",
      "sha256": "0A2D3B87D307986D1969DCC23B4A349ECBAFF7F74F91B8E986F81729CF85D0CC"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fixtures_test.go",
      "sha256": "E29AA04ACAC3EACF9524426F274E8C4F93A002BA74A9598D6EE582BD543B123C"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\fuzz_test.go",
      "sha256": "EB827AD3EE693F4CE0DBE03EBE0FC6340B16284AE499743EA7BDD245B91B0C14"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\input.go",
      "sha256": "5A6E979C7B1E84357CEBCC26F443D4144F946750C5095976392A94F968C7EB52"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material.go",
      "sha256": "92E2A18760E9C1C5C90256CA5442A1432A9F42A6E2647A55BCC093A58D68EF47"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\material_test.go",
      "sha256": "981B6735574D28EA53A61A68CFA7A72DA2B761B6E8D90FABD1EB1344A9D7123A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned.go",
      "sha256": "787211003166E96697199D16DD5055DA8FF4BDBA9D1A731540EB0187C7B3A07A"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\owned_test.go",
      "sha256": "A7511F813D4ADB678A2FA23E1EC05FB96E9A7A6948BEE448811DD1EC1F947793"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse.go",
      "sha256": "AA4BE70D7531000FCB8CB1834FB9CF88AC2633FF51383E81574CABD51A3C5833"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\parse_test.go",
      "sha256": "B094146155F5DEAEFFEB27170EF7B207AB27A8C10AC3E6C2DCD9F788505A8918"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate.go",
      "sha256": "8CC808C6BF16D52A628D1A7CF7023058B5C24B273360907E0611E617761E0562"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\raw_certificate_test.go",
      "sha256": "79AE777980EAF1485A962766AD9CE2D44A2C398AB247655750D8D93B63A691A7"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki.go",
      "sha256": "95AAA8CE6398AC585836656BFDBA943DA6F6C41D36DF4F67D258F4DBAAA8067F"
    },
    {
      "path": "D:\\Projects\\Talenro\\.worktrees\\c12-b01-task9-coordinator\\internal\\nodecontrol\\nodeca\\spki_test.go",
      "sha256": "62DB5B59B1E11111E33E68E84943401747C5912BE8B89D6FAB3C8E20FBC5251D"
    },
    {
      "path": "docs/superpowers/plans/2026-10-11-node-ca-material.md",
      "sha256": "1C4B3C6DB7E84D5592601B4EDB34F5B12C2A6FF42A8F0CA3E6860EFBA7B04F71"
    },
    {
      "path": "docs/superpowers/specs/2026-10-11-node-ca-material-design.md",
      "sha256": "CF59571AE81F3A777063AD6CB6B15D7669E7CE342DDDE6D43D4C9CABAF3A83F6"
    }
  ]
}

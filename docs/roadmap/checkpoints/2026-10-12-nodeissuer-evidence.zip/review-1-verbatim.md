### Strengths

- The implementation binds the actual CA public key to exact SPKI, raw Name, and full 32-byte identifiers, then verifies SHA-256 of the original full TBS DER. No re-encoding or trust-chain path is introduced. See [relation.go](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeissuer/relation.go:8) and [signature.go](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeissuer/signature.go:77).
- Ownership and cleanup are explicit: four independent clones, cleanup registered before cloning, immediate lower-material cleanup registration, and a final cancellation check before publication. See [owned.go](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeissuer/owned.go:16), [lower.go](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeissuer/lower.go:39), and [evaluate.go](D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/internal/nodecontrol/nodeissuer/evaluate.go:10).
- All five review-focus areas are deliberately covered:
  - Same Name/key in another CA remains acceptable while retaining distinct CA DER and all Pending obligations.
  - Original lower sentinel identities are preserved; new-stage precedence is tested separately.
  - Incorrect signature preimages fail; source guards independently constrain reconstruction paths.
  - Overlapping inputs are independently cloned, and separate evaluations have separate owners.
  - Observed cancellation overrides ordinary stage results; success is published only after the final check.
- The three old guard changes are narrowly scoped to the approved exact-directory/package exceptions. Existing product implementations and old test data remain unchanged.

### Issues

- **Critical:** None identified.
- **Important:** None identified.
- **Minor:** None identified.

### Verification evidence

I read all 24 new files, the complete design and plan, all Ruling entries, the frozen inventory, the old-guard net diff, and relevant lower implementation behavior.

Fresh read-only checks confirmed:

- All **27 source files match freeze 1**.
- Among **766 baseline paths**, only the plan and three approved guards differ; none are missing.
- HEAD remains `764dcb8b6b682ecce03fd6de02dbe339c66ff985`; the index hash remains `D48CD341480E047AC816B9F189445A6F8EDBBF02018C3DCD97EF1165C3DF67BC`.
- All **234 frozen fixture digests** match, and all **13 leaf signatures** independently verify using .NET verification against the supplied CA public keys.
- Receipts **032–053** record 22 exit-zero commands, each with before/after hashes matching freeze 1. Fuzz receipts report 75,755 envelope executions and 6,917 pair executions.

I inspected the Go-test receipts; I did **not** rerun Go tests during this read-only review.

### Recommendations

Proceed with Task 5’s final execution/status documentation and preservation check. Keep any source modification behind a new freeze, the complete bounded matrix, and review follow-up. Obtain separate authorization before staging, committing, pushing, or merging.

### Declined to judge

- **CA self-signature, parent binding, roots, complete chains and path constraints:** explicitly deferred; unchanged Pending obligations retain these responsibilities.
- **Trusted issuer identity, provenance or unique issuing certificate:** the inputs supply no trusted provenance; same-key/name ambiguity is intentionally tested.
- **Current validity and leaf/CA window containment:** no trusted-time input or window policy is authorized.
- **Deployment purpose, bundle status/rollback, identity epochs, issuer/serial uniqueness, private-key possession and runtime/main-state authorization:** separate responsibilities outside this direct-relation increment.
- **Production/provider compatibility and migration from existing identifier formats:** synthetic fixtures do not establish compatibility; status remains UNKNOWN.
- **General DN equivalence and complete semantics of unknown algorithm parameters:** the approved policy uses exact Name bytes and bounded outer parameter validation.
- **Concurrent input mutation, concurrent Summary/Clear, hard-real-time cancellation, constant-time behavior, peak-heap bounds, or inaccessible/crash-time memory erasure:** explicitly unsupported guarantees.
- **Exhaustive DER coverage or formal correctness of the finite AST guards:** bounded fuzzing and regression guards provide evidence, not universal proof.
- **Pre-existing broader lower-package test-consumer exceptions/subpath behavior:** unchanged baseline policy; this increment authorizes only the three new exact exceptions.
- **Whole-repository, race/Linux, real database/Docker/provider/hardware/reboot/PITR verification, and C12/main acceptance:** not covered by the approved limited matrix.

### Assessment

**Ready to accept this frozen partial increment: Yes.**

No source fixes are required by this review. The implementation matches the approved direct-issuer-relation scope and preserves its trust limitations. Final documentation/closeout remains pending; this verdict does not authorize Git writes, main merge, or C12 acceptance.

# Task 4 brief — BASE 764dcb8b6b682ecce03fd6de02dbe339c66ff985 (Tasks 1–3 uncommitted)

## Task 4: 直接关系与完整Evaluate组合

**Files:** Create `internal/nodecontrol/nodeissuer/{relation.go,evaluate.go,relation_test.go,evaluate_test.go}`。

**Interfaces:** Consumes Tasks1–3接口。Produces
`checkIssuerRelation(in Input,s lowerSummaries,certs certificateSnapshots) error`及
`Evaluate(ctx context.Context,in Input) (*Material,error)`。
关系只比较raw公钥、Name、32-byte标识/派生与真实lower；不验CA自身签名、parent
AKI、不检查chain/time/status。所有使用Input的内部helper调用均为owned输入。

- [ ] **Step 1: 写关系与公开组合失败测试。** TestIssuerRelation逐一控制公钥、Name、标识不同，顺序key→Name→ID；内部伪造certs/s只能用于helper单元控制。TestIssuerEvaluateGolden遍历Task2全部正例variant，要求新Proof、两级leaf旧Proof、CA旧Proof、spec两张完整Pending、固定raw摘要/serial/time/pathLen/ID，Clear后所有Proof为None；生产兼容性无新声明。

  ```go
  m,err:=Evaluate(context.Background(),fixtureInput(t)); if err!=nil { t.Fatal(err) }; defer m.Clear()
  got:=m.Summary()
  if got.Proof!=NodeLeafDirectIssuerSignatureBound || got.Leaf.Proof!=nodeleafkeys.NodeLeafDeclaredKeyIdentifiersBound || got.Leaf.Leaf.Proof!=nodeleaf.NodeLeafMaterialShapeValid || got.CA.Proof!=nodeca.NodeCAMaterialShapeAndDeclaredKeyBound { t.Fatal("partial proof") }
  if got.Leaf.Leaf.Pending!=([6]nodeleaf.Obligation{nodeleaf.LeafSignatureAndIssuerTrust,nodeleaf.KeyIdentifierDerivationAndIssuerBinding,nodeleaf.TrustedCurrentTime,nodeleaf.IdentityAndAuthorityProvenance,nodeleaf.PrivateKeyPossession,nodeleaf.MainStateAndRuntimeBinding}) { t.Fatal("leaf pending") }
  if got.CA.Pending!=([6]nodeca.Obligation{nodeca.CertificateSignatureAndIssuerChain,nodeca.AuthorityIdentifierAndParentBinding,nodeca.TrustedCurrentTime,nodeca.DeploymentAuthorizationAndPurpose,nodeca.BundleStatusAndRollback,nodeca.LeafIssuerRelationAndRuntimeUse}) { t.Fatal("CA pending") }
  ```

  TestIssuerEvaluateRejects：改leaf形状合法serial/TBS但保留签名、错key的合法r/s签名→ErrInvalidSignature；CA同key但改raw subject Name、文本相同不同String tag或RDN bytes→ErrIssuerRelationMismatch；坏ID/声明SPKI→真实lower原error。错误均返回nil Material，不泄露动态文本。

- [ ] **Step 2: 写组合优先级与不升级测试。** TestIssuerCombinedFailurePriority固定CA错误先于leaf、leaf lower错误先于新signature、表示错误先于Name、Name先于数学错签名；Name/ID双错Name-first仅对关系helper成立，公开lower坏ID先拒绝。TestIssuerCertificateAmbiguity对sameCAKeyAndNameOtherCert通过、CADigest不同且全部Pending；TestIssuerUntrustedFactsRetained对CA自身signature bit flip保持shape、CA AKI任意32bytes、expired/future/crossCAWindow/sameKeyRoles通过但Pending完整，固定测试参考日2026-10-12不是产品可信时间。

  TestIssuerIndependentLifecycle创建两次Evaluate，清理第一次不改第二次或caller
  inputs；TestIssuerCancellation覆盖nil/预取消/预到期，内部stageError取消优先，
  有界工作中取消不返回有效半成品（允许在实际取消前正常返回的竞态单独记为
  未观察取消，不能强行当失败/通过），最终ctx检查与移交由Task5源码guard固定。

- [ ] **Step 3: 记录RED。** Run `& $issuerGo test ./internal/nodecontrol/nodeissuer -run '^(TestIssuerRelation|TestIssuerEvaluateGolden|TestIssuerEvaluateRejects|TestIssuerCombinedFailurePriority|TestIssuerCertificateAmbiguity|TestIssuerUntrustedFactsRetained|TestIssuerIndependentLifecycle|TestIssuerCancellation)$' -count=1 -p=1 -timeout=120s`，预期缺Evaluate/关系行为失败。
- [ ] **Step 4: 实现固定组合。** Evaluate严格按spec §6.1：preflight、ownInput立即defer失败清理、owned Input、evaluateLower、parseSnapshots、parseLeafEnvelope/profile、checkIssuerRelation、verifyLeafSignature、固定Summary、最终ctx检查、valid/唯一transfer、返回Material。每个阶段前后ctx检查；lower全部在其helper返回前Clear。关系按exact bytes与完整hash核对，不以digest替代Name/key，不错误比较CA parent AKI；Summary只取真实lower及SHA256(raw.tbs.full/raw.issuer.full)。panic不recover成success，owner不留parser/key/raw引用。
- [ ] **Step 5: 记录GREEN。** 重跑Step3及完整新包/旧三包，均exit0；清理共享owner可达bytes的观察证据与失败不可达内存限制分开。
- [ ] **Step 6: 保存阶段检查点。** 全部组合控制的RED/GREEN/固定error优先级/源码hash；记录未证明责任，不提交。

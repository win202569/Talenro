# Task 2 brief — BASE 764dcb8b6b682ecce03fd6de02dbe339c66ff985 (Task 1 uncommitted)

## Task 2: 冻结测试材料、真实lower组合与快照对应

**Files:** Create `internal/nodecontrol/nodeissuer/{fixtures_test.go,lower.go,snapshot.go,lower_test.go,snapshot_test.go}`。

**Interfaces:** Consumes Task1 owned Input/errors。Produces
`stageError(ctx context.Context,err error) error`、
`evaluateLower(ctx context.Context,in Input) (lowerSummaries,error)`、
`checkLowerProofs(s lowerSummaries) error`、
`parseSnapshots(ctx context.Context,in Input,s lowerSummaries) (certificateSnapshots,error)`。
in必须是Task1重建的owned输入；两类返回值仅是内部临时信息，不能保存到owner。

- [ ] **Step 1: 制作并独立冻结golden。** 在专属忽略scratch以apply_patch建立一次性fixture-generate.go，使用标准库Go离线签发，禁止product helper或旧fixture导入。基准测试CA为P-256 scalar=1、leaf scalar=2；CA serial=128、DN CN=`nodeissuer offline CA`、2026-01-01T00:00:00Z至2036-01-01T00:00:00Z、BC=true无pathLen、KU=certSign；leaf serial=129、empty subject、2026-10-12T00:00:00Z至次日、NodeID=`11111111-2222-4333-8444-555555555555`、domain=`node.test`。两签名算法显式ECDSAWithSHA256；CA四扩展和leaf六扩展完全按旧获批profile显式设置，SKI/AKI都是exact SPKI全SHA256，不依赖自动行为。

  一次生成后把DER/SPKI/Name/TBS/signature与独立摘要冻结为fixtures_test.go的hex常量；Windows SHA256另核对原始bytes，不调用产品hash/parser作期望值。基准真实签名用标准库x509.CheckSignatureFrom作为test-only对照，错误不被转换为期望“有效”。普通测试不运行generator、不随机重签。若首次helper失败，保留回执，修正并以新attempt生成，不假称固定bytes早已存在。

  冻结以下fixtureVariant名字：base；caCRL（KU certSign+CRLSign）；caPathZero（显式0）；caReordered/leafReordered（各扩展逆序）；alternateDN（CN=`nodeissuer alternate CA`，leaf issuer同raw）；expired（CA2010-01-01至2011-01-01，leaf2010-10-12一日）；future（CA2040-01-01至2050-01-01，leaf2041-10-12一日）；crossCAWindow（base leaf，CA2020-01-01至2021-01-01）；sameCAKeyAndNameOtherCert（base CA改serial=130与parent AKI32bytes全0x42）；sameKeyRoles（leaf scalar=1、相应SPKI/SKI改变）；highS/lowS（同一base leaf的s/N-s两个正确DER表示，TBS不变）。变体仍真实签发leaf；CA自身变化可保留旧签名，因本层不认证CA parent。变体含义按其名字固定，不读取time.Now。

- [ ] **Step 2: 写lower与快照失败测试。** TestIssuerLowerProofs逐一翻转三Proof、两个Pending任一条/顺序，须ErrInvalidMaterial。TestIssuerLowerErrorIdentity：CA malformed+leaf malformed先返回nodeca.ErrInvalidMaterial；CA合规+leaf malformed返回原nodeleaf.ErrInvalidMaterial；leaf AKI32bytes错误返回原nodeleafkeys.ErrBindingMismatch而非本层relation error；CA错误声明key返回原nodeca.ErrBindingMismatch。TestIssuerStageError对已取消ctx与普通错误返回context.Canceled，对正常ctx保留同一个error。

  TestIssuerSnapshots对真实lower结果核对所有字段；内部单元控制逐一改变CA四摘要、两ID、serial/长度、时间、pathLen标志/值和CRLSignAllowed，以及leaf DER/SPKI/声明issuer摘要、SKI/AKI、serial/长度、时间、NodeID/domain，每项必须ErrInvalidMaterial。公开入口不接受这些伪造Summary。

  ```go
  in:=fixtureInput(t); o:=ownInput(in); defer o.clear()
  owned:=o.input(in.Leaf.NodeID,in.Leaf.TrustDomain)
  s,err:=evaluateLower(context.Background(),owned); if err!=nil { t.Fatal(err) }
  if err:=checkLowerProofs(s); err!=nil { t.Fatal(err) }
  broken:=s; broken.ca.CADERDigest[0]^=1
  if _,err:=parseSnapshots(context.Background(),owned,broken); !errors.Is(err,ErrInvalidMaterial) { t.Fatal("snapshot") }
  ```

- [ ] **Step 3: 记录RED。** Run `& $issuerGo test ./internal/nodecontrol/nodeissuer -run '^(TestIssuerFixtureControls|TestIssuerLowerProofs|TestIssuerLowerErrorIdentity|TestIssuerStageError|TestIssuerSnapshots)$' -count=1 -p=1 -timeout=120s`，预期缺真实lower/snapshot helper而失败。fixture controls须自身有效，不把生成或解码错误当行为RED。
- [ ] **Step 4: 实现真实lower与字段对应。** evaluateLower按CA后keys顺序真实调用、每次立即defer Clear、各阶段context优先；keys的DeclaredIssuerSPKI仅用owned CA声明。checkLowerProofs按spec §4原数组逐字比较。parseSnapshots按CA后leaf分别ParseCertificate并在前后检查取消，Raw完整对应；固定摘要、ID、serial、UTC时间与lower对应，CA pathLen映射要求省略=-1/Zero=false、显式0=0/Zero=true、正值=对应整数/Zero=false；CRLSignAllowed对应KeyUsageCRLSign。只检查快照描述，不重实现旧扩展profile，不调用DER accessor，不保留parser对象到owner。
- [ ] **Step 5: 记录GREEN。** 重跑Step3及完整新包/旧三包，预期exit0；冻结generator源、golden manifest和独立摘要。两层临时副本清理由源码流和旧Clear回归支持，不声称动态观察失败私有owner擦除。
- [ ] **Step 6: 保存阶段检查点。** 完整回执/前后hash/基线核对；除Task1三个guard例外没有旧source drift，不提交。

# Read-only final review package — nodeissuer freeze 1

Worktree: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator
Base and unchanged HEAD: 764dcb8b6b682ecce03fd6de02dbe339c66ff985.
Review uncommitted net changes, NOT a HEAD..HEAD empty commit range. No Git bookkeeping was authorized.
Spec: docs/superpowers/specs/2026-10-12-node-leaf-issuer-relation-design.md
Plan: docs/superpowers/plans/2026-10-12-node-leaf-issuer-relation.md
Ledger: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-12-node-leaf-issuer-relation/progress.md (all Ruling lines apply)
Baseline: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-12-node-leaf-issuer-relation/baseline.json (766 baseline paths)
Frozen source inventory: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-12-node-leaf-issuer-relation/final-sources-1.json (27 exact paths/hashes)
Old net diff: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-12-node-leaf-issuer-relation/030-frozen-old-guard-diff.txt
Preservation: D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator/.superpowers/sdd/2026-10-12-node-leaf-issuer-relation/031-preservation-check.json

User approved design, then option 1 Native implementation on 2026-10-12. All Tasks 1–4 implemented inline TDD; Task 5 guards/fuzz/format/final bounded matrix now complete. Independent review and final documentation still pending. No commit/push/merge/main/C12 acceptance.

## Implemented increment

24 new files under internal/nodecontrol/nodeissuer (12 product/12 test), plus three lower consumer guards only. Four independent byte clones; real CA then keys lower calls; same-owned parser snapshots; minimal leaf envelope; exact ECDSA/SHA256 representation; actual CA key/Name/full32 ID relationship; SHA256(full original TBS)/VerifyASN1; final context/owner transfer. Both lower obligation tables unchanged. Fixture generation is one-off ignored synthetic test material; 13 frozen pairs and 234 independently checked Windows digests. Signature oracle is fixed RFC6979 A.2.5 plus frozen original-TBS pairs, not product-produced expectations.

Read all new product/tests (fixture constant may be processed as data), net old guard changes and complete spec/plan. Review all five focus classes deliberately. Check actual severity by effect, not spec silence. Test-only finite AST guards are not formal proof; no broad trust/time/provider/runtime conclusion is allowed.

## Review Focus

- 相同Name/key出现在另一CA：Task4 `TestIssuerCertificateAmbiguity`应接受直接数学关系但保留CA DER差异及全部Pending，不证明可信issuer_id或唯一来源。
- lower更早拒绝与新层错误顺序混淆：Task2 `TestIssuerLowerErrorIdentity`和Task4 `TestIssuerCombinedFailurePriority`分别固定原sentinel身份及仅到达新阶段后的优先级。
- 以重编码或TBS content替代原TBS：Task3 `TestIssuerSignaturePreimage`做不同字节preimage负例；Task5 `TestIssuerProductBoundary`禁止marshal/重建路径，不夸大动态证明。
- overlapping subslice/共享包装Clear误伤另一Evaluate：Task1 `TestIssuerOwnedInput`和Task4 `TestIssuerIndependentLifecycle`固定独立buffer与独立owner，不承诺并发安全。
- 已观察到取消但普通错误/旧成功仍被返回：Task2 `TestIssuerStageError`及Task4 `TestIssuerCancellation`固定context优先、nil Material与最终移交边界；不把耗时短测当硬实时保证。


## Evidence

Every attempt is a numbered JSON receipt with actual executable, arguments, environment whitelist, UTC, full stdout/stderr, exit and pre/post source hashes, plus exact wrapper. RED/GREEN and diagnosis failures are not omitted. 007 generated independent frozen materials; 008 Windows hashes; 009 controls; 019 cancellation observation (10 observed /22 completed first). Guard attempts 021/024 failed; actual cause/fixes and targeted RED in ledger; 025 and post-format 029 pass. Format 027/028 pass, no format-check output. Full final matrix receipts 032–053: all 22 exit 0 at same freeze.18 full packages, specified authority only, store compile-only, 2 bounded 5s fuzz sessions. No entire-repo/race/Linux/real DB/Docker/provider/hardware/reboot/PITR/C12 verification.

## Final bounded matrix
1. 032-matrix-01: exit 0; source stable true; ["test","./internal/nodecontrol/nodeissuer","-count=1","-p=1","-timeout=120s"]
2. 033-matrix-02: exit 0; source stable true; ["test","./internal/nodecontrol/nodeca","-count=1","-p=1","-timeout=120s"]
3. 034-matrix-03: exit 0; source stable true; ["test","./internal/nodecontrol/nodeleaf","-count=1","-p=1","-timeout=120s"]
4. 035-matrix-04: exit 0; source stable true; ["test","./internal/nodecontrol/nodeleafkeys","-count=1","-p=1","-timeout=120s"]
5. 036-matrix-05: exit 0; source stable true; ["test","./internal/nodecontrol/contracts","-count=1","-p=1","-timeout=120s"]
6. 037-matrix-06: exit 0; source stable true; ["test","./internal/nodecontrol/serving","-count=1","-p=1","-timeout=120s"]
7. 038-matrix-07: exit 0; source stable true; ["test","./internal/nodecontrol/statebinding","-count=1","-p=1","-timeout=120s"]
8. 039-matrix-08: exit 0; source stable true; ["test","./internal/nodecontrol/statecomposition","-count=1","-p=1","-timeout=120s"]
9. 040-matrix-09: exit 0; source stable true; ["test","./internal/nodecontrol/statecontract","-count=1","-p=1","-timeout=120s"]
10. 041-matrix-10: exit 0; source stable true; ["test","./internal/nodecontrol/stateformat","-count=1","-p=1","-timeout=120s"]
11. 042-matrix-11: exit 0; source stable true; ["test","./internal/nodecontrol/statematerials","-count=1","-p=1","-timeout=120s"]
12. 043-matrix-12: exit 0; source stable true; ["test","./internal/nodecontrol/statepolicy","-count=1","-p=1","-timeout=120s"]
13. 044-matrix-13: exit 0; source stable true; ["test","./internal/nodecontrol/statepolicybinding","-count=1","-p=1","-timeout=120s"]
14. 045-matrix-14: exit 0; source stable true; ["test","./internal/nodecontrol/staterecovery","-count=1","-p=1","-timeout=120s"]
15. 046-matrix-15: exit 0; source stable true; ["test","./internal/nodecontrol/statetime","-count=1","-p=1","-timeout=120s"]
16. 047-matrix-16: exit 0; source stable true; ["test","./internal/nodecontrol/statetimebinding","-count=1","-p=1","-timeout=120s"]
17. 048-matrix-17: exit 0; source stable true; ["test","./internal/nodecontrol/stateverify","-count=1","-p=1","-timeout=120s"]
18. 049-matrix-18: exit 0; source stable true; ["test","./internal/readiness","-count=1","-p=1","-timeout=120s"]
19. 050-matrix-19: exit 0; source stable true; ["test","./internal/nodecontrol/authority","-run","^(TestBoundRead|TestCoordinator)","-count=1","-p=1","-timeout=120s"]
20. 051-matrix-20: exit 0; source stable true; ["test","./internal/store","-run","^$","-count=1","-p=1","-timeout=120s"]
21. 052-matrix-21: exit 0; source stable true; ["test","./internal/nodecontrol/nodeissuer","-run","^$","-fuzz","^FuzzIssuerEnvelope$","-count=1","-p=1","-parallel=1","-fuzztime=5s","-timeout=30s"]
22. 053-matrix-22: exit 0; source stable true; ["test","./internal/nodecontrol/nodeissuer","-run","^$","-fuzz","^FuzzIssuerPair$","-count=1","-p=1","-parallel=1","-fuzztime=5s","-timeout=30s"]

## Review authority

Read-only source, docs, index, HEAD, branch/config. No edits, agents, new worktree, network, installs, signing, commits, push or external coordination. Existing Go/cache tests may be inspected in raw receipts; if a check is needed, keep it read-only and report exact actual observations. Return findings with file/line and effect, Critical/Important/Minor, strengths, recommendations, explicit verdict on this partial increment (not main merge authority), and every behavior declined to judge with its reason (or none). Do not weaken obligations/profile or use old reviewer approval as this review.


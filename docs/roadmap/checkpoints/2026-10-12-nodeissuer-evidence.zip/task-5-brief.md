# Task 5 brief — BASE 764dcb8b6b682ecce03fd6de02dbe339c66ff985 (Tasks 1–4 uncommitted)

## Task 5: 全边界守卫、限定验证、一次独立审查与收尾

**Files:** Create `internal/nodecontrol/nodeissuer/{boundary_test.go,fuzz_test.go}`；
完成后Create `docs/roadmap/2026-10-12-node-leaf-issuer-relation-execution.md`，
仅在审查及限定验证通过后更新`docs/roadmap/current-status.md`顶部本增量状态和
本计划checkbox。旧设计状态/需求正文不重写，审批留痕在本计划与执行记录中。

**Interfaces:** Test-only guard入口固定为
`issuerProductAllowed(source []byte) bool`、
`issuerCapabilityAllowed(sources map[string][]byte) bool`、
`issuerConsumerAllowed(path,pkg,imported string) bool`、
`issuerOwnershipAllowed(sources map[string][]byte) bool`。
Fuzz入口固定`FuzzIssuerEnvelope(*testing.F)`、`FuzzIssuerPair(*testing.F)`。
本任务不增加产品接口或更强Proof。

- [ ] **Step 1: 写guard失败测试及其拒绝控制。** TestIssuerProductBoundary、TestIssuerCapabilityBoundary、TestIssuerConsumers、TestIssuerOwnershipFlow固定24文件、全部公开契约/六error字串/profile、owner四buffer/Summary/valid，以及下面的完整allowed imports/members；额外export、mutable包级值、DER accessor、Material/Summary输入、lower清理延迟/省略、先Clone后defer、错误Clear目标、提前valid/transfer、caller byte后读及无最终ctx检查都拒绝。原source不被故意破坏，拒绝控制使用内存变体；尚未实现checker时缺声明或拒绝行为失败构成RED。

  | Product import | 唯一允许package members |
  | --- | --- |
  | bytes | Clone Equal Compare |
  | context | Context |
  | errors | New |
  | crypto/sha256 | Sum256 |
  | crypto/ecdsa | PublicKey VerifyASN1 |
  | crypto/elliptic | P256 |
  | crypto/x509 | Certificate ParseCertificate ECDSAWithSHA256 KeyUsageCRLSign |
  | github.com/google/uuid | UUID Nil RFC4122 |
  | talenro.local/platform/internal/nodecontrol/contracts | Digest |
  | talenro.local/platform/internal/nodecontrol/nodeleaf | Input Summary Proof Obligation None NodeLeafMaterialShapeValid及spec §4原六项Obligation名 |
  | talenro.local/platform/internal/nodecontrol/nodeleafkeys | Input Summary Proof None NodeLeafDeclaredKeyIdentifiersBound Evaluate |
  | talenro.local/platform/internal/nodecontrol/nodeca | Input Summary Proof Obligation None NodeCAMaterialShapeAndDeclaredKeyBound Parse及spec §4原六项Obligation名 |

  普通receiver方法只准本任务需要的ctx.Err、lower.Summary/Clear、serial.Sign/Bytes、
  time.UTC/Equal、Curve.IsOnCurve、Material/owner固定方法；不能借method-value绕过
  x509 Verify/CheckSignature*、DER、Marshal/Ready/Authorize/State/Commit/I/O。
  标准库或lower显式alias允许；点/空白alias、重复import/alias、局部definition/range/
  type/field遮蔽alias、伪装receiver selector、非原语VerifyASN1/Verify方法值拒绝。
  验签原语只允许signature.go的精确crypto/ecdsa.VerifyASN1调用，不能变成通用
  callback。guard不声称完整Go语义或形式证明。

  新consumer仅准仓库exact nodeissuer目录同package的_test.go；产品和兄弟/
  nested/outside/外部test package全部拒绝；下层三个新例外与所有原案例一起回归。
  用内存拒绝控制和正常source对照约束checker，不为guard专门扩权。

- [ ] **Step 2: 记录guard RED。** Run `& $issuerGo test ./internal/nodecontrol/nodeissuer -run '^(TestIssuerProductBoundary|TestIssuerCapabilityBoundary|TestIssuerConsumers|TestIssuerOwnershipFlow)$' -count=1 -p=1 -timeout=120s`，预期缺checker或固定拒绝控制失败；源代码不作故意破坏。

- [ ] **Step 3: 实现test-only checker和两个fuzz入口。** 四个checker按Step1完整闭包实现。Envelope fuzz callback为`func(t *testing.T,der []byte)`，输入最多65,536bytes，分别检查envelope/signature helper的无panic/固定error不变量；seeds含golden certificate、合法signature、非最小length、错unused bits、截断。Pair callback为`func(t *testing.T,leafDER,caDER,expectedSPKI,declaredSPKI []byte)`，分别限65,536/65,536/512/8,192bytes，固定合法NodeID/domain，再clone四输入调用Evaluate；seeds含base及错signature/Name/AKI。成功必须断言全Proof/Pending且Clear归零，failure必须nil Material；不recover panic、不写产品source。

- [ ] **Step 4: 记录guard GREEN。** 重跑Step2及完整新包test，预期exit0；normal source允许、全部内存变体正确拒绝，两fuzz seed corpus均运行，不声称已经完成短fuzz探索。

- [ ] **Step 5: 格式化仅本次27个Go路径并冻结。** 24个新文件和三个旧guard exact名单，Ordinal排序；`& $issuerFmt -w @issuerSourcePaths`后用`-l`要求exit0且无输出。复核三旧文件的其余guards/API/案例不变、所有旧testdata/源码基线不变；冻结final-sources-1.json包含exact bytes长度/hash。格式错误不扩展为改旧生成脚本/文档。此冻结之后的任何source改动使验证与审查失效。

- [ ] **Step 6: 完整限定矩阵。** 使用§2完整环境，逐条记录原始回执与同一冻结revision的前后hash；下面22条命令必须各自exit0，fuzz同时报告实际executions/seed数，不用总elapsed冒充fuzztime。18个完整包为原17加nodeissuer。

  ```powershell
  & $issuerGo test ./internal/nodecontrol/nodeissuer -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/nodeca -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/nodeleaf -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/nodeleafkeys -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/contracts -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/serving -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statebinding -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statecomposition -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statecontract -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/stateformat -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statematerials -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statepolicy -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statepolicybinding -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/staterecovery -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statetime -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/statetimebinding -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/stateverify -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/readiness -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/authority -run '^(TestBoundRead|TestCoordinator)' -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/store -run '^$' -count=1 -p=1 -timeout=120s
  & $issuerGo test ./internal/nodecontrol/nodeissuer -run '^$' -fuzz '^FuzzIssuerEnvelope$' -count=1 -p=1 -parallel=1 -fuzztime=5s -timeout=30s
  & $issuerGo test ./internal/nodecontrol/nodeissuer -run '^$' -fuzz '^FuzzIssuerPair$' -count=1 -p=1 -parallel=1 -fuzztime=5s -timeout=30s
  ```

  上面共22条：18完整包、1指定authority、1store编译、2fuzz。
  store不跑测试、authority不启用integration tag，不称整仓。
  最终保存新包与三guard的exact差异空白检查；旧历史空白/格式欠账不能说通过。

- [ ] **Step 7: fresh独立质量/安全审查。** Native选择下，由作者实现五项后，派一个全新上下文reviewer，使用执行时可用最强审查模型（目前gpt-6-astra/xhigh），fork_turns=none、只读，提供完整spec/plan、真实基线、全部freeze/source和原始证据。不得用旧CA reviewer结论代替新组合层审查。审查覆盖原TBS、公钥/Name/ID、算法/sentinel顺序、完整Pending、隔离例外、清理/取消与所有保全项；无新source写入或外部副作用授权。

  Critical/Important必须修复并取得真实RED/GREEN，source改变就重冻结、重跑
  上面全部22条及format，回到同一reviewer复核；Minor修复或列出具体风险请用户
  决定，不能私自跳过。不自动新开reviewer来替换不利结论，模型不可用不静默降级。
  Subagent-driven若被用户选择则按其技能逐任务实现/审查，最终仍对整增量检查；
  未选择执行方法之前禁止派implementer或reviewer。

- [ ] **Step 8: 最终保全与正式执行记录。** 待审查无未决项、最终命令均通过且同freeze后，用apply_patch写执行文档与current-status顶部增量；记录实际审批/UTC、每次attempt真实状态、审查逐项处置、修订、最终源码hash和全部限制。保留旧CA/leaf/progress文字为历史，不把partial改为Trusted/Ready或C12完成。正式文档完成后核对只有24新Go、三个guard最小变更、允许的plan/status/execution变更；无新增consumer、旧testdata/source漂移、Git config/HEAD/index变化。若某命令失败或review缺失，写真实未验收状态，不勾该任务完成。
- [ ] **Step 9: 用户交付与下一保存门。** 报告本增量实际完成范围、所有未决责任与失败/证据限制；Native执行技能要求的Ruling/cost清单按当时技能完整列出。源码收尾之后，暂存/提交/普通开发分支推送另行请求明确授权；不自动合并main、PR、强推、删除分支/worktree或迁移provider。

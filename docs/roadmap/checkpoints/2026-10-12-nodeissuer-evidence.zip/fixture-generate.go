// One-off synthetic offline generator. Never used by product or normal tests.
package main

import (
 "bytes"
 "crypto/ecdsa"
 "crypto/elliptic"
 "crypto/rand"
 "crypto/sha256"
 "crypto/x509"
 "crypto/x509/pkix"
 "encoding/asn1"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "math/big"
 "time"
)

func must[T any](v T,e error)T{if e!=nil{panic(e)};return v}
func tlv(tag byte,b []byte)[]byte{out:=[]byte{tag};if len(b)<128{out=append(out,byte(len(b)))}else if len(b)<256{out=append(out,0x81,byte(len(b)))}else{out=append(out,0x82,byte(len(b)>>8),byte(len(b)))};return append(out,b...)}
func key(v byte)*ecdsa.PrivateKey{x,y:=elliptic.P256().ScalarBaseMult([]byte{v});return &ecdsa.PrivateKey{PublicKey:ecdsa.PublicKey{Curve:elliptic.P256(),X:x,Y:y},D:big.NewInt(int64(v))}}
func extension(last int,critical bool,value []byte)pkix.Extension{return pkix.Extension{Id:asn1.ObjectIdentifier{2,5,29,last},Critical:critical,Value:value}}
func date(y int)time.Time{return time.Date(y,1,1,0,0,0,0,time.UTC)}
func hash(b []byte)string{v:=sha256.Sum256(b);return hex.EncodeToString(v[:])}
func describe(caDER,leafDER,caSPKI,leafSPKI []byte)map[string]string{
 ca:=must(x509.ParseCertificate(caDER));leaf:=must(x509.ParseCertificate(leafDER))
 if err:=leaf.CheckSignatureFrom(ca);err!=nil{panic(err)}
 b:=map[string][]byte{"CADER":caDER,"LeafDER":leafDER,"DeclaredSPKI":caSPKI,"ExpectedSPKI":leafSPKI,"CATBS":ca.RawTBSCertificate,"LeafTBS":leaf.RawTBSCertificate,"CAName":ca.RawSubject,"CAIssuer":ca.RawIssuer,"LeafIssuer":leaf.RawIssuer,"LeafSubject":leaf.RawSubject,"CASPKI":ca.RawSubjectPublicKeyInfo,"LeafSPKI":leaf.RawSubjectPublicKeyInfo,"CASignature":ca.Signature,"LeafSignature":leaf.Signature,"CASKI":ca.SubjectKeyId,"CAAKI":ca.AuthorityKeyId,"LeafSKI":leaf.SubjectKeyId,"LeafAKI":leaf.AuthorityKeyId}
 out:=map[string]string{}
 for n,v:=range b{out[n]=hex.EncodeToString(v);out[n+"Digest"]=hash(v)}
 return out
}
func main(){
 ck:=key(1);caSPKI:=must(x509.MarshalPKIXPublicKey(&ck.PublicKey));caSKI:=sha256.Sum256(caSPKI)
 names:=[]string{"base","caCRL","caPathZero","caReordered","leafReordered","alternateDN","expired","future","crossCAWindow","sameCAKeyAndNameOtherCert","sameKeyRoles"}
 all:=map[string]map[string]string{}
 for _,name:=range names{
  lk:=key(2);if name=="sameKeyRoles"{lk=key(1)}
  leafSPKI:=must(x509.MarshalPKIXPublicKey(&lk.PublicKey));leafSKI:=sha256.Sum256(leafSPKI)
  subject:=pkix.Name{CommonName:"nodeissuer offline CA"};if name=="alternateDN"{subject.CommonName="nodeissuer alternate CA"}
  serial:=int64(128);parentID:=bytes.Repeat([]byte{0x24},32)
  if name=="sameCAKeyAndNameOtherCert"{serial=130;parentID=bytes.Repeat([]byte{0x42},32)}
  cb,ce:=date(2026),date(2036);lb:=time.Date(2026,10,12,0,0,0,0,time.UTC)
  if name=="expired"{cb,ce=date(2010),date(2011);lb=time.Date(2010,10,12,0,0,0,0,time.UTC)}
  if name=="future"{cb,ce=date(2040),date(2050);lb=time.Date(2041,10,12,0,0,0,0,time.UTC)}
  if name=="crossCAWindow"{cb,ce=date(2020),date(2021)}
  bc:=[]byte{0x30,3,1,1,0xff};ku:=[]byte{3,2,2,4};pathZero:=name=="caPathZero"
  if pathZero{bc=[]byte{0x30,6,1,1,0xff,2,1,0}}
  if name=="caCRL"{ku=[]byte{3,2,1,6}}
  caExt:=[]pkix.Extension{extension(19,true,bc),extension(15,true,ku),extension(14,false,tlv(4,caSKI[:])),extension(35,false,tlv(0x30,tlv(0x80,parentID)))}
  if name=="caReordered"{for i,j:=0,len(caExt)-1;i<j;i,j=i+1,j-1{caExt[i],caExt[j]=caExt[j],caExt[i]}}
  caT:=&x509.Certificate{SerialNumber:big.NewInt(serial),Subject:subject,NotBefore:cb,NotAfter:ce,IsCA:true,BasicConstraintsValid:true,MaxPathLen:-1,SignatureAlgorithm:x509.ECDSAWithSHA256,KeyUsage:x509.KeyUsageCertSign,SubjectKeyId:caSKI[:],AuthorityKeyId:parentID,ExtraExtensions:caExt}
  if pathZero{caT.MaxPathLen=0;caT.MaxPathLenZero=true}
  if name=="caCRL"{caT.KeyUsage|=x509.KeyUsageCRLSign}
  caDER:=must(x509.CreateCertificate(rand.Reader,caT,caT,&ck.PublicKey,ck))
  ca:=must(x509.ParseCertificate(caDER))
  uri:=[]byte("spiffe://node.test/node/11111111-2222-4333-8444-555555555555")
  leafExt:=[]pkix.Extension{extension(19,true,[]byte{0x30,0}),extension(15,true,[]byte{3,2,7,0x80}),extension(37,false,[]byte{0x30,10,6,8,0x2b,6,1,5,5,7,3,2}),extension(17,true,tlv(0x30,tlv(0x86,uri))),extension(14,false,tlv(4,leafSKI[:])),extension(35,false,tlv(0x30,tlv(0x80,caSKI[:])))}
  if name=="leafReordered"{for i,j:=0,len(leafExt)-1;i<j;i,j=i+1,j-1{leafExt[i],leafExt[j]=leafExt[j],leafExt[i]}}
  leafT:=&x509.Certificate{SerialNumber:big.NewInt(129),NotBefore:lb,NotAfter:lb.Add(24*time.Hour),SignatureAlgorithm:x509.ECDSAWithSHA256,BasicConstraintsValid:true,KeyUsage:x509.KeyUsageDigitalSignature,SubjectKeyId:leafSKI[:],AuthorityKeyId:caSKI[:],ExtraExtensions:leafExt}
  leafDER:=must(x509.CreateCertificate(rand.Reader,leafT,ca,&lk.PublicKey,ck))
  all[name]=describe(caDER,leafDER,caSPKI,leafSPKI)
 }
 // Preserve the base leaf for controls that only describe alternate CA facts.
 for _,name:=range []string{"crossCAWindow","sameCAKeyAndNameOtherCert"}{
  all[name]=describe(must(hex.DecodeString(all[name]["CADER"])),must(hex.DecodeString(all["base"]["LeafDER"])),caSPKI,must(hex.DecodeString(all["base"]["ExpectedSPKI"])))
 }
 base:=all["base"];leaf:=must(x509.ParseCertificate(must(hex.DecodeString(base["LeafDER"]))))
 var rs struct{R,S *big.Int};tail,err:=asn1.Unmarshal(leaf.Signature,&rs);if err!=nil||len(tail)!=0{panic("signature")}
 other:=new(big.Int).Sub(elliptic.P256().Params().N,rs.S)
 low,high:=rs.S,other;if low.Cmp(high)>0{low,high=high,low}
 alg:=must(hex.DecodeString("300a06082a8648ce3d040302"))
 for name,s:=range map[string]*big.Int{"highS":high,"lowS":low}{
  sig:=must(asn1.Marshal(struct{R,S *big.Int}{rs.R,s}))
  body:=append(append(bytes.Clone(leaf.RawTBSCertificate),alg...),tlv(3,append([]byte{0},sig...))...)
  all[name]=describe(must(hex.DecodeString(base["CADER"])),tlv(0x30,body),caSPKI,must(hex.DecodeString(base["ExpectedSPKI"])))
 }
 fmt.Println(string(must(json.Marshal(all))))
}

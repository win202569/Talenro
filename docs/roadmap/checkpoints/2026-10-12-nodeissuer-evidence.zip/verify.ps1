param([Parameter(Mandatory=$true)][string]$Attempt,[Parameter(Mandatory=$true)][string]$CommandJson,[ValidateSet('go','gofmt')][string]$Tool='go')
$ErrorActionPreference='Stop'
$issuerRoot='D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
Set-Location -LiteralPath $issuerRoot
$env:GOOS='windows'
$env:GOARCH='amd64'
$env:GOTOOLCHAIN='local'
$env:GOPROXY='off'
$env:GOSUMDB='off'
$env:GOAUTH='off'
$env:GOVCS='all:off'
$env:GOFLAGS='-mod=readonly'
$env:GOPATH='C:/Users/Lenovo/go'
$env:GOMODCACHE='C:/Users/Lenovo/go/pkg/mod'
$env:GOCACHE="$PSScriptRoot/go-cache"
$issuerGo='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/go.exe'
if($Tool -eq 'gofmt'){$issuerGo='C:/Users/Lenovo/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.26.5.windows-amd64/bin/gofmt.exe'}
function Get-IssuerSources {
  $names=@('internal/nodecontrol/nodeleaf/boundary_test.go','internal/nodecontrol/nodeleafkeys/boundary_test.go','internal/nodecontrol/nodeca/boundary_test.go')
  if(Test-Path -LiteralPath 'internal/nodecontrol/nodeissuer'){ $names+=@(Get-ChildItem -LiteralPath 'internal/nodecontrol/nodeissuer' -Filter '*.go' -File | ForEach-Object { 'internal/nodecontrol/nodeissuer/'+$_.Name }) }
  [Array]::Sort($names,[StringComparer]::Ordinal)
  @($names | ForEach-Object { [pscustomobject]@{path=$_;bytes=(Get-Item -LiteralPath $_).Length;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $_).Hash} })
}
if($env:GODEBUG){throw 'Inherited GODEBUG needs explicit assessment; no command run'}
$issuerArgs=@(ConvertFrom-Json $CommandJson)
$before=Get-IssuerSources
$start=[DateTime]::UtcNow.ToString('o')
$info=[Diagnostics.ProcessStartInfo]::new()
$info.FileName=$issuerGo
$info.WorkingDirectory=$issuerRoot
$info.UseShellExecute=$false
$info.CreateNoWindow=$true
$info.RedirectStandardOutput=$true
$info.RedirectStandardError=$true
foreach($a in $issuerArgs){$info.ArgumentList.Add([string]$a)}
$p=[Diagnostics.Process]::new()
$p.StartInfo=$info
[void]$p.Start()
$out=$p.StandardOutput.ReadToEndAsync()
$err=$p.StandardError.ReadToEndAsync()
$p.WaitForExit()
$receipt=[ordered]@{attempt=$Attempt;workdir=$issuerRoot;executable=$issuerGo;arguments=$issuerArgs;startUTC=$start;endUTC=[DateTime]::UtcNow.ToString('o');exit=$p.ExitCode;stdout=$out.GetAwaiter().GetResult();stderr=$err.GetAwaiter().GetResult();environment=[ordered]@{GOOS=$env:GOOS;GOARCH=$env:GOARCH;GOTOOLCHAIN=$env:GOTOOLCHAIN;GOPROXY=$env:GOPROXY;GOSUMDB=$env:GOSUMDB;GOAUTH=$env:GOAUTH;GOVCS=$env:GOVCS;GOFLAGS=$env:GOFLAGS;GOPATH=$env:GOPATH;GOMODCACHE=$env:GOMODCACHE;GOCACHE=$env:GOCACHE;GODEBUG=$env:GODEBUG};before=$before;after=(Get-IssuerSources);wrapper=(Get-Content -LiteralPath $PSCommandPath -Raw)}
$p.Dispose()
$receipt | ConvertTo-Json -Depth 8 -Compress
exit 0

# Task 1 brief — BASE 764dcb8b6b682ecce03fd6de02dbe339c66ff985

## Task 1: 输入、共享生命周期与三个精确消费例外

**Files:** Create `internal/nodecontrol/nodeissuer/{doc.go,input.go,errors.go,budget.go,owned.go,material.go,budget_test.go,owned_test.go,material_test.go}`；Modify三个§1列出的旧boundary_test.go。

**Interfaces:** Produces `preflight(ctx context.Context,in Input) error`、
`ownInput(in Input) *owner`、`(*owner).input(nodeID uuid.UUID,trustDomain string) Input`、
`(*owner).clear()`及公开Input/Proof/Summary/Material方法、六个error。
本任务尚不声明Evaluate，不能用占位Evaluate返回成功。

- [ ] **Step 1: 先写三处旧消费者回归。** 原案例原样保留；新增exact nodeissuer/a.go与a_test.go、规范绝对路径允许，package必须nodeissuer。新增nodeissuer_extra、nested、另一个根下同后缀目录、outside repo、错package、nodeissuer_test、任意兄弟_test.go及nodeca子路径拒绝。

- [ ] **Step 2: 记录旧guard真实RED。** Run下列命令，预期新增允许案例被旧guard拒绝：

  ```powershell
  & $issuerGo test ./internal/nodecontrol/nodeleaf ./internal/nodecontrol/nodeleafkeys ./internal/nodecontrol/nodeca -run '^(TestLeafConsumers|TestKeysConsumers|TestCAConsumers)$' -count=1 -p=1 -timeout=120s
  ```

- [ ] **Step 3: 仅增加三个批准的exact例外。** 先归一化到各guard已有仓库根/相对路径模型，检查直接目录与package。nodeca的例外只针对exact nodeca import，不能准许target子路径。

- [ ] **Step 4: 记录旧guard GREEN。** 重跑Step2，预期exit0，原正反例全部保留且通过。

- [ ] **Step 5: 写合同失败测试。** TestIssuerPreflight覆盖nil/已取消/已到期、四字段空/limit/limit+1、UUID/domain各边界、长度优先；TestIssuerFixedErrors逐一比较spec固定文本及不同包sentinel身份。TestIssuerOwnedInput覆盖重叠subslice独立克隆、调用方后改不影响owner。TestIssuerMaterialLifecycle覆盖nil/零值、共享包装、Clear幂等与detached Summary。

  ```go
  in := Input{CA: nodeca.Input{DeclaredSPKI: make([]byte,8193)}}
  if !errors.Is(preflight(context.Background(),in),ErrLimitExceeded) { t.Fatal("budget before empty") }
  o := ownInput(Input{Leaf:nodeleaf.Input{DER:[]byte{1,2},ExpectedSPKI:[]byte{3}},CA:nodeca.Input{DER:[]byte{4},DeclaredSPKI:[]byte{5}}})
  a,b,c,d := o.leafDER,o.expectedSPKI,o.caDER,o.declaredSPKI
  o.valid=true; o.summary.Proof=NodeLeafDirectIssuerSignatureBound
  m:=&Material{owned:o}; copyM:=*m; detached:=m.Summary(); m.Clear()
  if copyM.Summary()!=(Summary{}) || detached.Proof!=NodeLeafDirectIssuerSignatureBound { t.Fatal("lifecycle") }
  for _,buf:=range [][]byte{a,b,c,d} { for _,v:=range buf { if v!=0 { t.Fatal("owned bytes not cleared") } } }
  ```

- [ ] **Step 6: 记录合同RED。** Run `& $issuerGo test ./internal/nodecontrol/nodeissuer -run '^(TestIssuerPreflight|TestIssuerFixedErrors|TestIssuerOwnedInput|TestIssuerMaterialLifecycle)$' -count=1 -p=1 -timeout=120s`，预期缺本任务声明。
- [ ] **Step 7: 最小实现合同。** 按spec实现；ownInput首次Clone前登记defer清理，四项分别Clone；owner.input只组装自有byte与纯值NodeID/domain，无Clone/parser，无caller byte读取。
- [ ] **Step 8: 记录GREEN。** 重跑Step6；再完整新包及旧三包test（同count/p/timeout），预期全部exit0。不把此时的合同测试称为完整Evaluate完成。
- [ ] **Step 9: 保存阶段检查点。** 原始RED/GREEN、三个旧guard最小diff、旧文件余部/旧testdata hash及本任务源码留痕；只更新本任务checkbox，不提交/推送。

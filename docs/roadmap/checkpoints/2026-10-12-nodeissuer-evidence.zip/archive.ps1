$ErrorActionPreference='Stop'
$issuerWorkspace = 'D:/Projects/Talenro/.worktrees/c12-b01-task9-coordinator'
Set-Location -LiteralPath $issuerWorkspace
$issuerArchivePath = [IO.Path]::GetFullPath((Join-Path $issuerWorkspace 'docs/roadmap/checkpoints/2026-10-12-nodeissuer-evidence.zip'))
$issuerIntendedArchiveRoot = [IO.Path]::GetFullPath((Join-Path $issuerWorkspace 'docs/roadmap/checkpoints')) + [IO.Path]::DirectorySeparatorChar
if (-not $issuerArchivePath.StartsWith($issuerIntendedArchiveRoot,[StringComparison]::OrdinalIgnoreCase)) {throw 'Archive target is outside intended directory'}
if (Test-Path -LiteralPath $issuerArchivePath) {throw 'Archive target exists; refuse overwrite'}
$issuerEvidenceRoot = [IO.Path]::GetFullPath((Join-Path $issuerWorkspace '.superpowers/sdd/2026-10-12-node-leaf-issuer-relation'))
$issuerFileNames = [string[]]@(Get-ChildItem -LiteralPath $issuerEvidenceRoot -File -Force | ForEach-Object Name)
[Array]::Sort($issuerFileNames,[StringComparer]::Ordinal)
$issuerManifest=@()
$issuerNames=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
$issuerZip = [IO.Compression.ZipFile]::Open($issuerArchivePath,[IO.Compression.ZipArchiveMode]::Create)
try {
 foreach($issuerFileName in $issuerFileNames) {
  $issuerFile=Get-Item -LiteralPath (Join-Path $issuerEvidenceRoot $issuerFileName)
  if (($issuerFile.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or -not $issuerNames.Add($issuerFile.Name)) {throw 'Invalid or duplicate archive source'}
  $issuerEntry=$issuerZip.CreateEntry($issuerFile.Name,[IO.Compression.CompressionLevel]::Optimal)
  $issuerInput=[IO.File]::OpenRead($issuerFile.FullName)
  $issuerOutput=$issuerEntry.Open()
  try {$issuerInput.CopyTo($issuerOutput)} finally {$issuerOutput.Dispose();$issuerInput.Dispose()}
  $issuerManifest += [ordered]@{path=$issuerFile.Name;bytes=$issuerFile.Length;sha256=(Get-FileHash -LiteralPath $issuerFile.FullName -Algorithm SHA256).Hash}
 }
} finally {$issuerZip.Dispose()}
$issuerMismatches=@()
$issuerVerified=0
$issuerReadZip=[IO.Compression.ZipFile]::OpenRead($issuerArchivePath)
try {
 if ($issuerReadZip.Entries.Count -ne $issuerManifest.Count) {throw 'ZIP entry count differs'}
 foreach($issuerEntry in $issuerReadZip.Entries) {
  $issuerExpected=@($issuerManifest | Where-Object { $_.path -ceq $issuerEntry.FullName })
  if ($issuerExpected.Count -ne 1 -or $issuerEntry.FullName -cne $issuerEntry.Name) {throw 'Unexpected archive entry'}
  $issuerMemory=[IO.MemoryStream]::new()
  $issuerInput=$issuerEntry.Open()
  try {$issuerInput.CopyTo($issuerMemory);$issuerBytes=$issuerMemory.ToArray()} finally {$issuerInput.Dispose();$issuerMemory.Dispose()}
  $issuerHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($issuerBytes))
  if ($issuerBytes.Length -ne $issuerExpected[0].bytes -or $issuerHash -cne $issuerExpected[0].sha256 -or (Get-FileHash -LiteralPath (Join-Path $issuerEvidenceRoot $issuerEntry.Name) -Algorithm SHA256).Hash -cne $issuerHash) {$issuerMismatches+=$issuerEntry.Name} else {$issuerVerified++}
 }
} finally {$issuerReadZip.Dispose()}
[ordered]@{
 capturedUTC=[DateTime]::UtcNow.ToString('o')
 archivePath='docs/roadmap/checkpoints/2026-10-12-nodeissuer-evidence.zip'
 sourceDirectory='.superpowers/sdd/2026-10-12-node-leaf-issuer-relation'
 entryCount=$issuerManifest.Count
 verifiedEntries=$issuerVerified
 mismatches=$issuerMismatches
 archiveBytes=(Get-Item -LiteralPath $issuerArchivePath).Length
 archiveSHA256=(Get-FileHash -LiteralPath $issuerArchivePath -Algorithm SHA256).Hash
 excludedDirectories=@('go-cache')
 scope='Exact root-level original text artifacts for this plan, including historical failures and fresh pre-save22-command receipts. Post-stage/commit/push receipts are later local evidence, not fabricated into this pre-commit snapshot.'
 files=$issuerManifest
} | ConvertTo-Json -Depth 6

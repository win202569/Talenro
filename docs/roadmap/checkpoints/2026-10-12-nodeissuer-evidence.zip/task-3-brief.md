# Task 3 brief — BASE 764dcb8b6b682ecce03fd6de02dbe339c66ff985 (Tasks 1–2 uncommitted)

## Task 3: leaf envelope、签名表示与精确验签原语

**Files:** Create `internal/nodecontrol/nodeissuer/{der.go,signature.go,der_test.go,signature_test.go}`。

**Interfaces:** Produces
`readElement(raw []byte) (derElement,[]byte,error)`、
`singleElement(raw []byte,tag byte) (derElement,error)`、
`takeElement(raw *[]byte,tag byte) (derElement,error)`、
`minimalInteger(raw []byte) bool`、`minimalOID(raw []byte) bool`、
`parseLeafEnvelope(der []byte) (signedLeaf,error)`、
`checkLeafSignatureProfile(cert *x509.Certificate,raw signedLeaf) error`、
`checkSignatureDER(sig []byte) error`、
`verifyLeafSignature(ca *x509.Certificate,raw signedLeaf) error`。
profile检查负责raw/parser对应及算法/表示；verify只做实际key/hash/验签。

- [ ] **Step 1: 冻结公开独立向量。** 从spec §8.1取Qx/Qy/r/s与sample消息摘要；完整SPKI是下列91bytes，DER签名为72bytes。N-s独立数学值在规划时用Windows BigInteger核对；它不是新的验签结果。

  ```text
  SPKI = 3059301306072a8648ce3d020106082a8648ce3d0301070342000460fed4ba255a9d31c961eb74c6356d68c049b8923b61fa6ce669622e60f29fb67903fe1008b8bc99a41ae9e95628bc64f2f1b20c2d7e9f5177a3c294d4462299
  signature = 3046022100efd48b2aacb6a8fd1140dd9cd45e81d69d2c877b56aaf991c34d0ea84eaf3716022100f7cb1c942d657c41d436c7a1b6e29f65f3e900dbb9aff4064dc4ab2f843acda8
  N-s = 0834e36ad29a83bf2bc9385e491d6099c8fdf9d1ed67aa7ea5f51f93782857a9
  ```

  公开向量仅测试原语。基准项目pair/TBS才是verifyLeafSignature端到端正例，
  不把ASCII sample包装成certificate成功。

- [ ] **Step 2: 写失败测试。** TestIssuerDERTLV固定最短长度、截断/溢出/indefinite/high-tag及cursor；TestIssuerEnvelope完整v3字段、外层三字段、unique IDs/尾随/多字段拒绝及所有raw范围。TestIssuerSignatureProfile、TestIssuerSignatureDER按下表固定错误；测试同时覆盖直接helper和公开阶段可到达的输入，lower/parser先拒绝的仍用原error。

  | 输入/控制 | 本层helper期望 |
  | --- | --- |
  | exact无参数OID，parser ECDSAWithSHA256，raw范围对应 | nil |
  | exact OID但手工控制parser枚举不对应 | ErrInvalidMaterial |
  | inner/outer不同、range与parser不对应 | ErrInvalidMaterial |
  | 正确NULL `05 00`或相同完整SHA1/SHA224/SHA384/SHA512/RSA/Ed25519/DSA/Unknown OID | ErrUnsupportedSignatureProfile |
  | NULL带payload、缺OID、多参数、未终止/冗余base128 OID、param TLV截断/非最小length | ErrInvalidMaterial |
  | opaque完整非NULL参数TLV | ErrUnsupportedSignatureProfile；不检查未知内部schema |
  | signature unused!=0、空/截断、额外INTEGER/尾随、冗余sign zero、错误tag、P1363不是DER | ErrInvalidMaterial |
  | canonical r/s为0、负数、N、N+1或超范围 | ErrUnsupportedSignatureProfile |
  | r/s为1或N-1、必要padding、8/72bytes合法边界 | 表示nil；不声称数学签名有效 |
  | 非最小负数或超范围同时存在尾随 | ErrInvalidMaterial，先完整表示检查 |

  TestIssuerSignaturePrimitive断言公开r/s、s替为N-s后均有效，bit flip、换key、
  换hash无效；公开消息摘要固定，不用产品函数产生期望。TestIssuerSignaturePreimage
  对项目base raw.tbs.full成功，单元控制替为整张leaf或仅TBS content须ErrInvalidSignature。

  ```go
  in:=fixtureInput(t); s,err:=evaluateLower(context.Background(),in); if err!=nil { t.Fatal(err) }
  certs,err:=parseSnapshots(context.Background(),in,s); if err!=nil { t.Fatal(err) }
  raw,err:=parseLeafEnvelope(in.Leaf.DER); if err!=nil { t.Fatal(err) }
  if err:=checkLeafSignatureProfile(certs.leaf,raw); err!=nil { t.Fatal(err) }
  if err:=verifyLeafSignature(certs.ca,raw); err!=nil { t.Fatal(err) }
  wrong:=raw; wrong.tbs.full=raw.tbs.content
  if err:=verifyLeafSignature(certs.ca,wrong); !errors.Is(err,ErrInvalidSignature) { t.Fatal("exact TBS preimage") }
  ```

- [ ] **Step 3: 记录RED。** Run `& $issuerGo test ./internal/nodecontrol/nodeissuer -run '^(TestIssuerDERTLV|TestIssuerEnvelope|TestIssuerSignatureProfile|TestIssuerSignatureDER|TestIssuerSignaturePrimitive|TestIssuerSignaturePreimage)$' -count=1 -p=1 -timeout=120s`；预期缺helper或预期行为失败。
- [ ] **Step 4: 实现最小scanner与运算。** TLV累乘前以真实remaining约束，读单byte tag、完整最短length；固定TBS v3字段次序，extensions边界消费但不复制旧extension规则。AlgorithmIdentifier只做spec §5.3已冻结的外层/OID/NULL规则，不扩大opaque schema。先完整消费r/s两个INTEGER及最小编码，再按r后s范围；最小负数属于unsupported，非最小表示优先malformed，长度上限不能遮盖可见尾随。r/s以去必要padding后的fixed32bytes与固定N逐字序比较；没有产品math/big或私钥。verify只取ca.PublicKey真实*ecdsa.PublicKey、P256/坐标/点检查（异常ErrInvalidMaterial），SHA256(raw.tbs.full)，VerifyASN1 false为ErrInvalidSignature，允许high-S、不fallback。
- [ ] **Step 5: 记录GREEN。** 重跑Step3及完整新包/旧三包，均exit0；确认所有error纯固定，公开vector“有效”不是由被测函数动态反推。
- [ ] **Step 6: 保存阶段检查点。** 新scanner/signature原始RED/GREEN及golden/源码hash；不把此任务独立helper通过称为完整issuer认证，不提交。
